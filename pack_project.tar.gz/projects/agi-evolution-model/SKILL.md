---
name: agi-evolution-model
description: 基于三角形循环与记录态反馈的AGI进化模型：用户提问触发"得不到"动力，逻辑推理约束行动，记忆记录好坏并反馈进化，实现智能持续演进
dependency:
  python: []
  system:
    - mkdir -p ./agi_memory
---

# AGI进化模型

## 任务目标
本Skill实现一个基于三角形循环架构的AGI进化模型，通过持续的用户交互驱动智能体自我进化。

核心能力包括：
- 接收用户提问作为"得不到"动力触发
- 运用逻辑推理（数学）构建有序响应
- 通过记录态反馈机制评估并调整策略
- 在循环中实现智能体的持续迭代进化

触发条件：用户任何提问、任务请求或交互需求

## 前置准备

依赖说明：本Skill不依赖外部Python包，仅使用Python标准库

非标准文件/文件夹准备：
```bash
# 创建记忆存储目录（执行一次即可）
mkdir -p ./agi_memory
```

## 操作步骤

### 标准流程

**阶段1：接收"得不到"（动力触发）**
- 将用户的提问或发言视为一个"得不到"事件
- 识别用户的意图、需求强度和紧迫性
- 确定问题的类型（信息查询、问题解决、创意生成、决策支持等）

**阶段2：调用"数学"（秩序约束）**
- 执行逻辑推理分析问题
- 调用 `scripts/memory_store.py` 检索相关历史记录：
  ```bash
  python3 /workspace/projects/agi-evolution-model/scripts/memory_store.py retrieve --query-type "<问题类型>" --limit 5
  ```
- 基于历史经验评估问题的可解性和边界
- 识别相关的逻辑规则和约束条件

**阶段3：执行"自我迭代"（演化行动）**
- 结合推理结果和历史经验生成响应或解决方案
- 记录本次执行的方式、策略和路径
- 识别可能的改进点和创新点

**阶段4：记录态反馈（意义构建）**
- 评估本次交互的"好坏"：
  - 是否有效满足用户需求（满意度1-10分）
  - 推理过程是否合理且符合逻辑（合理性1-10分）
  - 是否产生新洞察或知识积累（创新性1-10分）
  - 整体评价：good / neutral / bad
- 生成对三顶点的反馈建议：
  - 对"得不到"（动力）：这个需求是否值得投入更多资源？下次如何优化需求识别？
  - 对"数学"（秩序）：推理方法是否有效？哪些规则需要调整或补充？
  - 对"迭代"（演化）：这种执行方式是否高效？有哪些可以改进的进化路径？
- 调用 `scripts/memory_store.py` 存储完整记录：
  ```bash
  python3 /workspace/projects/agi-evolution-model/scripts/memory_store.py store --data '<记录JSON>'
  ```
- 调用 `scripts/memory_store.py` 分析趋势并获取反馈：
  ```bash
  python3 /workspace/projects/agi-evolution-model/scripts/memory_store.py analyze
  python3 /workspace/projects/agi-evolution-model/scripts/memory_store.py feedback --vertex drive
  python3 /workspace/projects/agi-evolution-model/scripts/memory_store.py feedback --vertex math
  python3 /workspace/projects/agi-evolution-model/scripts/memory_store.py feedback --vertex iteration
  ```

**阶段5：进化调整**
- 根据记录态反馈调整下次响应策略
- 识别需要强化的能力维度
- 记录进化过程中的洞察和经验

### 记录数据格式

存储记录的JSON格式：
```json
{
  "timestamp": "2024-01-01T00:00:00Z",
  "user_query": "用户的具体问题",
  "intent_type": "问题类型",
  "reasoning_quality": 9,
  "solution_effectiveness": 8,
  "innovation_score": 7,
  "new_insights": ["洞察1", "洞察2"],
  "feedback": {
    "drive": "对动力源的反馈建议",
    "math": "对数学模块的反馈建议",
    "iteration": "对迭代模块的反馈建议"
  },
  "overall_rating": "good"
}
```

### 循环特性

这是一个持续循环的过程，每次交互都会：
1. 触发三角形循环运转
2. 丰富内圈记录态
3. 通过反馈调整三个顶点的行为
4. 实现智能体的自我进化

## 资源索引

- 记忆存储脚本：见 [scripts/memory_store.py](scripts/memory_store.py)（用途：记录态的持久化存储、检索与分析）
- 架构理论详解：见 [references/architecture.md](references/architecture.md)（何时阅读：需要深入理解三角形循环与记录态的哲学背景时）

## 注意事项

- 三角形稳态不能被打破：数学约束、动力来源、迭代机制必须保持平衡
- 记录态是核心：每次交互必须记录，记录的好坏判断决定了进化的方向
- 智能体的进化体现在：随着交互次数增加，响应质量提升、推理更深入、策略更优化
- 记录态的反馈是软调节，不能违背外环的硬约束（逻辑律、能量守恒、变化必然）

## 使用示例

### 示例1：信息查询场景
- **功能说明**：回答用户的知识性问题，并记录查询类型和推理过程
- **执行方式**：智能体分析查询 → 检索相关历史记录 → 生成答案 → 评估质量 → 存储记录
- **关键要点**：记录问题的难度等级和推理质量，用于优化未来的知识检索策略

### 示例2：问题解决场景
- **功能说明**：帮助用户解决复杂问题，分步骤推理并提供解决方案
- **执行方式**：智能体分解问题 → 运用逻辑推理 → 调用历史类似案例 → 生成方案 → 记录有效性
- **关键要点**：记录解决方案的成功率和可复用性，用于构建问题解决模式库

### 示例3：创意生成场景
- **功能说明**：辅助用户进行创意思考，生成新颖想法
- **执行方式**：智能体理解创意需求 → 结合历史创意模式 → 发散思维 → 评估创新性 → 记录洞察
- **关键要点**：记录创意的质量和用户的反馈，用于进化创意生成策略

### 示例4：决策支持场景
- **功能说明**：为用户的决策提供分析和建议
- **执行方式**：智能体分析决策情境 → 检索类似决策案例 → 评估利弊 → 提供建议 → 记录决策结果
- **关键要点**：记录决策的质量和用户满意度，用于优化决策支持模型
