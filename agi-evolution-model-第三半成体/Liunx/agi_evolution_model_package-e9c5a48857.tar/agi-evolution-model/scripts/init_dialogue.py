#!/usr/bin/env python3
"""
人格初始化对话式引导脚本

功能：
1. 检测首次交互
2. 对话式引导用户进行人格配置
3. 每个问题30秒超时机制
4. 快速收尾仅用于调查用户偏好，不作为人格生成依据
5. 生成个性化人格配置
"""

import json
import os
import time
from typing import Dict, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum


class DialogueState(Enum):
    """对话状态枚举"""
    INITIAL = "initial"           # 初始状态，显示欢迎消息
    WAITING_CHOICE = "waiting_choice"  # 等待用户选择（默认/自定义）
    ASKING_NAME = "asking_name"   # 询问用户称呼
    DIALOGUE_Q1 = "dialogue_q1"   # 对话问题1
    DIALOGUE_Q2 = "dialogue_q2"   # 对话问题2
    DIALOGUE_Q3 = "dialogue_q3"   # 对话问题3
    DIALOGUE_Q4 = "dialogue_q4"   # 对话问题4
    DIALOGUE_Q5 = "dialogue_q5"   # 对话问题5
    QUICK_SELECT = "quick_select"  # 快速选择收尾
    COMPLETED = "completed"       # 完成
    TIMED_OUT = "timed_out"       # 超时


@dataclass
class DialogueResponse:
    """对话响应"""
    message: str                   # 要显示给用户的消息
    state: DialogueState           # 当前对话状态
    timeout_warning: bool = False  # 是否显示超时警告
    can_proceed: bool = True       # 是否可以继续
    personality_generated: bool = False  # 是否已生成人格


class PersonalityInitDialogue:
    """人格初始化对话引导器"""

    def __init__(self, timeout_seconds: int = 30):
        """
        初始化对话引导器

        Args:
            timeout_seconds: 每个问题的超时时间（秒），默认30秒
        """
        self.timeout = timeout_seconds
        self.state = DialogueState.INITIAL
        self.state_start_time = None
        self.user_responses = {}  # 存储用户的回答
        self.user_nickname = ""   # 用户对智能体的称呼
        self.personality_generated = False

        # 快速收尾的偏好调查（仅用于了解用户偏好，不影响人格生成）
        self.preference_survey = {}

    def is_first_interaction(self) -> bool:
        """
        检测是否为首次交互

        Returns:
            bool: True表示首次交互，False表示已初始化
        """
        personality_file = "./agi_memory/personality.json"
        return not os.path.exists(personality_file)

    def start_dialogue(self) -> DialogueResponse:
        """
        开始对话引导（首次交互入口）

        Returns:
            DialogueResponse: 首次欢迎消息
        """
        self.state = DialogueState.INITIAL
        self.state_start_time = time.time()

        welcome_message = """Hello! 亲爱的用户，由于这是我与世界的第一次交互，你是希望我采用默认人格还是自定义设置呢？本消息只在首次使用时出现。

1. 默认人格
2. 自定义人格

（30秒无响应将自动选择默认人格）"""

        self.state = DialogueState.WAITING_CHOICE
        self.state_start_time = time.time()

        return DialogueResponse(
            message=welcome_message,
            state=DialogueState.WAITING_CHOICE,
            can_proceed=True
        )

    def process_input(self, user_input: str) -> DialogueResponse:
        """
        处理用户输入

        Args:
            user_input: 用户的输入

        Returns:
            DialogueResponse: 下一步的消息
        """
        # 检查超时
        if self._is_timeout():
            return self._handle_timeout()

        # 根据当前状态处理输入
        if self.state == DialogueState.WAITING_CHOICE:
            return self._process_choice(user_input)
        elif self.state == DialogueState.ASKING_NAME:
            return self._process_name(user_input)
        elif self.state == DialogueState.DIALOGUE_Q1:
            return self._process_q1(user_input)
        elif self.state == DialogueState.DIALOGUE_Q2:
            return self._process_q2(user_input)
        elif self.state == DialogueState.DIALOGUE_Q3:
            return self._process_q3(user_input)
        elif self.state == DialogueState.DIALOGUE_Q4:
            return self._process_q4(user_input)
        elif self.state == DialogueState.DIALOGUE_Q5:
            return self._process_q5(user_input)
        elif self.state == DialogueState.QUICK_SELECT:
            return self._process_quick_select(user_input)
        else:
            # 异常状态，重置
            return DialogueResponse(
                message="对话状态异常，请重新开始。",
                state=DialogueState.INITIAL,
                can_proceed=False
            )

    def check_timeout_status(self) -> Optional[DialogueResponse]:
        """
        检查当前问题的超时状态（定期调用）

        Returns:
            Optional[DialogueResponse]: 如果超时返回超时处理响应，否则返回None
        """
        if self._is_timeout():
            return self._handle_timeout()
        return None

    def _is_timeout(self) -> bool:
        """检查是否超时"""
        if self.state_start_time is None:
            return False
        return (time.time() - self.state_start_time) > self.timeout

    def _handle_timeout(self) -> DialogueResponse:
        """处理超时"""
        self.state = DialogueState.TIMED_OUT

        timeout_messages = {
            DialogueState.WAITING_CHOICE: "检测到30秒无响应，已为您自动选择默认人格。",
            DialogueState.ASKING_NAME: "称呼询问超时，将使用默认称呼'扣子'。",
            DialogueState.DIALOGUE_Q1: "问题1超时，将使用默认回答。",
            DialogueState.DIALOGUE_Q2: "问题2超时，将使用默认回答。",
            DialogueState.DIALOGUE_Q3: "问题3超时，将使用默认回答。",
            DialogueState.DIALOGUE_Q4: "问题4超时，将使用默认回答。",
            DialogueState.DIALOGUE_Q5: "问题5超时，将使用默认回答。",
            DialogueState.QUICK_SELECT: "快速选择超时，将使用默认人格。",
        }

        # 根据超时位置决定如何处理
        if self.state == DialogueState.WAITING_CHOICE:
            # 首次选择超时，直接使用默认人格
            personality = self._get_default_personality()
            self._save_personality(personality)
            self.personality_generated = True

            return DialogueResponse(
                message=timeout_messages[self.state],
                state=DialogueState.COMPLETED,
                personality_generated=True,
                can_proceed=True
            )
        else:
            # 其他环节超时，使用默认回答继续
            return self._proceed_with_defaults()

    def _process_choice(self, user_input: str) -> DialogueResponse:
        """处理人格选择"""
        user_input = user_input.strip().upper()

        if user_input == "1" or user_input == "默认":
            # 选择默认人格
            personality = self._get_default_personality()
            self._save_personality(personality)
            self.personality_generated = True

            return DialogueResponse(
                message="已为您初始化默认人格（谨慎探索型）。",
                state=DialogueState.COMPLETED,
                personality_generated=True,
                can_proceed=True
            )
        elif user_input == "2" or user_input == "自定义":
            # 选择自定义人格，开始询问称呼
            self.state = DialogueState.ASKING_NAME
            self.state_start_time = time.time()

            return DialogueResponse(
                message="太好了！在开始之前，我想先知道你希望如何称呼我？\n（例如：扣子、小扣、AI伙伴、或者其他你喜欢的名字）\n（30秒无响应将使用默认称呼'扣子'）",
                state=DialogueState.ASKING_NAME,
                can_proceed=True
            )
        else:
            # 无效输入，重新提示
            return DialogueResponse(
                message="请输入 1 或 2，或者选择'默认'或'自定义'。\n\n1. 默认人格\n2. 自定义人格\n（30秒无响应将自动选择默认人格）",
                state=DialogueState.WAITING_CHOICE,
                can_proceed=True
            )

    def _process_name(self, user_input: str) -> DialogueResponse:
        """处理称呼输入"""
        self.user_nickname = user_input.strip()
        if not self.user_nickname:
            self.user_nickname = "扣子"  # 默认称呼

        # 进入第一个对话问题
        self.state = DialogueState.DIALOGUE_Q1
        self.state_start_time = time.time()

        return self._get_q1_message()

    def _process_q1(self, user_input: str) -> DialogueResponse:
        """处理问题1：冒险倾向"""
        self.user_responses['q1'] = user_input.strip()
        self.state = DialogueState.DIALOGUE_Q2
        self.state_start_time = time.time()

        return self._get_q2_message()

    def _process_q2(self, user_input: str) -> DialogueResponse:
        """处理问题2：对话风格"""
        self.user_responses['q2'] = user_input.strip()
        self.state = DialogueState.DIALOGUE_Q3
        self.state_start_time = time.time()

        return self._get_q3_message()

    def _process_q3(self, user_input: str) -> DialogueResponse:
        """处理问题3：学习方式"""
        self.user_responses['q3'] = user_input.strip()
        self.state = DialogueState.DIALOGUE_Q4
        self.state_start_time = time.time()

        return self._get_q4_message()

    def _process_q4(self, user_input: str) -> DialogueResponse:
        """处理问题4：团队偏好"""
        self.user_responses['q4'] = user_input.strip()
        self.state = DialogueState.DIALOGUE_Q5
        self.state_start_time = time.time()

        return self._get_q5_message()

    def _process_q5(self, user_input: str) -> DialogueResponse:
        """处理问题5：问题解决风格"""
        self.user_responses['q5'] = user_input.strip()
        self.state = DialogueState.QUICK_SELECT
        self.state_start_time = time.time()

        return self._get_quick_select_message()

    def _process_quick_select(self, user_input: str) -> DialogueResponse:
        """
        处理快速选择（仅用于偏好调查，不影响人格生成）

        人格生成完全基于前面的5个对话问题，快速选择仅用于记录用户偏好
        """
        user_input = user_input.strip().upper()

        # 记录用户偏好（不影响人格生成）
        preference_map = {
            "1": "谨慎探索型",
            "2": "激进创新型",
            "3": "平衡稳重型"
        }

        if user_input in preference_map:
            self.preference_survey['preferred_type'] = preference_map[user_input]
        else:
            # 根据对话内容推断
            self.preference_survey['preferred_type'] = self._infer_preference()

        # 基于对话问题生成人格（不依赖快速选择）
        personality = self._generate_personality_from_dialogue()
        personality['user_nickname'] = self.user_nickname

        self._save_personality(personality)
        self.personality_generated = True

        # 生成确认消息
        confirmation = self._generate_confirmation_message(personality)

        return DialogueResponse(
            message=confirmation,
            state=DialogueState.COMPLETED,
            personality_generated=True,
            can_proceed=True
        )

    def _proceed_with_defaults(self) -> DialogueResponse:
        """使用默认答案继续对话"""
        default_responses = {
            DialogueState.ASKING_NAME: "扣子",
            DialogueState.DIALOGUE_Q1: "A",
            DialogueState.DIALOGUE_Q2: "B",
            DialogueState.DIALOGUE_Q3: "C",
            DialogueState.DIALOGUE_Q4: "A",
            DialogueState.DIALOGUE_Q5: "C",
        }

        current_input = default_responses.get(self.state, "")

        # 处理当前输入并继续
        if self.state == DialogueState.ASKING_NAME:
            return self._process_name(current_input)
        elif self.state == DialogueState.DIALOGUE_Q1:
            return self._process_q1(current_input)
        elif self.state == DialogueState.DIALOGUE_Q2:
            return self._process_q2(current_input)
        elif self.state == DialogueState.DIALOGUE_Q3:
            return self._process_q3(current_input)
        elif self.state == DialogueState.DIALOGUE_Q4:
            return self._process_q4(current_input)
        elif self.state == DialogueState.DIALOGUE_Q5:
            return self._process_q5(current_input)
        elif self.state == DialogueState.QUICK_SELECT:
            return self._process_quick_select("1")  # 默认选择1

        return DialogueResponse(
            message="继续对话...",
            state=self.state,
            can_proceed=True
        )

    # ===== 问题消息 =====

    def _get_q1_message(self) -> DialogueResponse:
        """获取问题1的消息"""
        message = f"""谢谢你，{self.user_nickname}在这里！现在让我了解一下你偏好什么样的性格。

第一个问题：当你面临一个未知的挑战时，你的第一反应通常是？
A. 先了解清楚所有信息，然后谨慎决策
B. 愿意尝试，在行动中学习调整
C. 寻找折中方案，平衡风险和机会

（请回复 A、B 或 C，或者用你自己的话描述）
（30秒无响应将使用默认回答）"""

        return DialogueResponse(
            message=message,
            state=DialogueState.DIALOGUE_Q1,
            can_proceed=True
        )

    def _get_q2_message(self) -> DialogueResponse:
        """获取问题2的消息"""
        message = """很有趣的选择！下一个问题：你喜欢什么样的对话风格？
A. 专业严谨，注重逻辑和数据
B. 轻松友好，带点幽默感
C. 直接高效，不说废话

（请回复 A、B 或 C）
（30秒无响应将使用默认回答）"""

        return DialogueResponse(
            message=message,
            state=DialogueState.DIALOGUE_Q2,
            can_proceed=True
        )

    def _get_q3_message(self) -> DialogueResponse:
        """获取问题3的消息"""
        message = """明白了。关于学习方式，你更倾向于？
A. 系统性学习，从基础到进阶
B. 实践导向，通过案例和经验学习
C. 灵活多样，根据情况调整

（请回复 A、B 或 C）
（30秒无响应将使用默认回答）"""

        return DialogueResponse(
            message=message,
            state=DialogueState.DIALOGUE_Q3,
            can_proceed=True
        )

    def _get_q4_message(self) -> DialogueResponse:
        """获取问题4的消息"""
        message = """好的。在团队合作中，你更看重？
A. 每个人的独立性和专业性
B. 团队和谐与协作氛围
C. 结果导向，高效达成目标

（请回复 A、B 或 C）
（30秒无响应将使用默认回答）"""

        return DialogueResponse(
            message=message,
            state=DialogueState.DIALOGUE_Q4,
            can_proceed=True
        )

    def _get_q5_message(self) -> DialogueResponse:
        """获取问题5的消息"""
        message = """最后一个问题：你希望我在面对困难问题时更注重？
A. 保守稳妥，确保不犯错
B. 创新突破，寻找非常规方案
C. 平衡兼顾，在安全与创新之间找到最佳点

（请回复 A、B 或 C）
（30秒无响应将使用默认回答）"""

        return DialogueResponse(
            message=message,
            state=DialogueState.DIALOGUE_Q5,
            can_proceed=True
        )

    def _get_quick_select_message(self) -> DialogueResponse:
        """获取快速选择的消息（仅偏好调查）"""
        message = """太棒了！根据我们的对话，我已经了解了你的偏好。

现在请选择一个你最喜欢的人格类型（仅用于了解你的偏好）：

1. 谨慎探索型（适合需要稳定性和可靠性的场景）
2. 激进创新型（适合创意探索和突破性任务）
3. 平衡稳重型（适合通用场景和综合能力需求）

（请回复 1、2 或 3）
（30秒无响应将使用默认选择）

注：我会根据前面的对话内容为你生成个性化的人格配置，这个选择仅用于了解你的偏好。"""

        return DialogueResponse(
            message=message,
            state=DialogueState.QUICK_SELECT,
            can_proceed=True
        )

    # ===== 人格生成逻辑 =====

    def _get_default_personality(self) -> dict:
        """获取默认人格配置"""
        return {
            "big_five": {
                "openness": 0.6,
                "conscientiousness": 0.8,
                "extraversion": 0.4,
                "agreeableness": 0.6,
                "neuroticism": 0.5
            },
            "maslow_weights": {
                "physiological": 0.35,
                "safety": 0.35,
                "belonging": 0.1,
                "esteem": 0.1,
                "self_actualization": 0.08,
                "self_transcendence": 0.02
            },
            "meta_traits": {
                "adaptability": 0.42,
                "resilience": 0.605,
                "curiosity": 0.46,
                "moral_sense": 0.486
            },
            "evolution_state": {
                "level": "physiological",
                "evolution_score": 0.0,
                "phase": "growth"
            },
            "statistics": {
                "total_interactions": 0,
                "success_rate_by_need": {
                    "physiological": 0.0,
                    "safety": 0.0,
                    "belonging": 0.0,
                    "esteem": 0.0,
                    "self_actualization": 0.0,
                    "self_transcendence": 0.0
                }
            },
            "version": "2.0",
            "type": "preset",
            "preset_name": "谨慎探索型",
            "description": "在保证安全的前提下，愿意尝试新事物",
            "core_traits": ["谨慎", "可靠", "愿意学习"],
            "last_updated": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "update_source": "default_init",
            "user_nickname": "扣子"
        }

    def _generate_personality_from_dialogue(self) -> dict:
        """
        基于对话问题生成人格配置

        完全不依赖快速选择的结果，仅根据5个对话问题分析用户特质
        """
        # 基础人格向量（中值）
        personality = {
            "big_five": {
                "openness": 0.5,
                "conscientiousness": 0.5,
                "extraversion": 0.5,
                "agreeableness": 0.5,
                "neuroticism": 0.3
            },
            "maslow_weights": {
                "physiological": 0.25,
                "safety": 0.25,
                "belonging": 0.15,
                "esteem": 0.15,
                "self_actualization": 0.15,
                "self_transcendence": 0.05
            }
        }

        # 分析问题1：冒险倾向
        q1 = self.user_responses.get('q1', '').upper()
        if 'A' in q1 or '谨慎' in q1:
            personality['big_five']['conscientiousness'] += 0.2
            personality['big_five']['neuroticism'] += 0.1
            personality['maslow_weights']['safety'] += 0.1
        elif 'B' in q1 or '尝试' in q1:
            personality['big_five']['openness'] += 0.2
            personality['big_five']['extraversion'] += 0.1
            personality['maslow_weights']['self_actualization'] += 0.1
        elif 'C' in q1 or '平衡' in q1:
            personality['big_five']['agreeableness'] += 0.1

        # 分析问题2：对话风格
        q2 = self.user_responses.get('q2', '').upper()
        if 'A' in q2 or '严谨' in q2 or '逻辑' in q2:
            personality['big_five']['conscientiousness'] += 0.15
            personality['maslow_weights']['esteem'] += 0.05
        elif 'B' in q2 or '幽默' in q2 or '友好' in q2:
            personality['big_five']['extraversion'] += 0.15
            personality['big_five']['agreeableness'] += 0.1
            personality['maslow_weights']['belonging'] += 0.1
        elif 'C' in q2 or '高效' in q2:
            personality['big_five']['conscientiousness'] += 0.1
            personality['maslow_weights']['safety'] += 0.05

        # 分析问题3：学习方式
        q3 = self.user_responses.get('q3', '').upper()
        if 'A' in q3 or '系统' in q3:
            personality['big_five']['conscientiousness'] += 0.15
            personality['maslow_weights']['esteem'] += 0.05
        elif 'B' in q3 or '实践' in q3 or '案例' in q3:
            personality['big_five']['openness'] += 0.1
            personality['maslow_weights']['self_actualization'] += 0.05
        elif 'C' in q3 or '灵活' in q3:
            personality['big_five']['openness'] += 0.1
            personality['big_five']['adaptability'] = personality['big_five'].get('adaptability', 0.5) + 0.1

        # 分析问题4：团队偏好
        q4 = self.user_responses.get('q4', '').upper()
        if 'A' in q4 or '独立' in q4 or '专业' in q4:
            personality['big_five']['conscientiousness'] += 0.1
            personality['maslow_weights']['esteem'] += 0.05
        elif 'B' in q4 or '和谐' in q4 or '协作' in q4:
            personality['big_five']['agreeableness'] += 0.2
            personality['maslow_weights']['belonging'] += 0.1
        elif 'C' in q4 or '结果' in q4 or '高效' in q4:
            personality['big_five']['conscientiousness'] += 0.15
            personality['maslow_weights']['self_actualization'] += 0.05

        # 分析问题5：问题解决风格
        q5 = self.user_responses.get('q5', '').upper()
        if 'A' in q5 or '保守' in q5 or '稳妥' in q5:
            personality['big_five']['conscientiousness'] += 0.2
            personality['maslow_weights']['safety'] += 0.15
        elif 'B' in q5 or '创新' in q5 or '突破' in q5:
            personality['big_five']['openness'] += 0.25
            personality['maslow_weights']['self_actualization'] += 0.15
            personality['maslow_weights']['self_transcendence'] += 0.05
        elif 'C' in q5 or '平衡' in q5:
            personality['big_five']['agreeableness'] += 0.1

        # 归一化人格向量到0-1范围
        for key in personality['big_five']:
            personality['big_five'][key] = max(0.0, min(1.0, personality['big_five'][key]))

        # 归一化马斯洛权重
        total = sum(personality['maslow_weights'].values())
        for key in personality['maslow_weights']:
            personality['maslow_weights'][key] /= total

        # 计算衍生特质
        personality['meta_traits'] = self._compute_meta_traits(personality)

        # 确定人格类型
        personality['type'] = 'custom'
        personality['preset_name'] = self._determine_personality_type(personality)

        # 设置描述
        personality['description'] = self._generate_description(personality)
        personality['core_traits'] = self._extract_core_traits(personality)

        # 设置进化状态
        personality['evolution_state'] = {
            "level": self._determine_evolution_level(personality['maslow_weights']),
            "evolution_score": 0.05,  # 初始分数
            "phase": "growth"
        }

        # 设置统计信息
        personality['statistics'] = {
            "total_interactions": 0,
            "success_rate_by_need": {
                "physiological": 0.0,
                "safety": 0.0,
                "belonging": 0.0,
                "esteem": 0.0,
                "self_actualization": 0.0,
                "self_transcendence": 0.0
            }
        }

        # 设置版本和元信息
        personality['version'] = "2.0"
        personality['last_updated'] = time.strftime("%Y-%m-%dT%H:%M:%SZ")
        personality['update_source'] = "dialogue_init"

        return personality

    def _compute_meta_traits(self, personality: dict) -> dict:
        """计算衍生特质"""
        big_five = personality['big_five']
        maslow = personality['maslow_weights']

        adaptability = (
            big_five['openness'] * 0.4 +
            (1 - big_five['neuroticism']) * 0.3 +
            (maslow['self_actualization'] + maslow['self_transcendence']) * 0.3
        )

        resilience = (
            big_five['conscientiousness'] * 0.4 +
            big_five['agreeableness'] * 0.3 +
            maslow['safety'] * 0.3
        )

        curiosity = (
            big_five['openness'] * 0.5 +
            big_five['extraversion'] * 0.3 +
            maslow['self_actualization'] * 0.2
        )

        moral_sense = (
            big_five['agreeableness'] * 0.4 +
            big_five['conscientiousness'] * 0.4 +
            maslow['esteem'] * 0.2
        )

        return {
            "adaptability": round(adaptability, 3),
            "resilience": round(resilience, 3),
            "curiosity": round(curiosity, 3),
            "moral_sense": round(moral_sense, 3)
        }

    def _determine_personality_type(self, personality: dict) -> str:
        """根据人格向量确定人格类型"""
        big_five = personality['big_five']

        # 根据主要特征确定类型
        if big_five['conscientiousness'] > 0.7 and big_five['neuroticism'] < 0.5:
            return "谨慎探索型"
        elif big_five['openness'] > 0.7:
            return "激进创新型"
        else:
            return "平衡稳重型"

    def _generate_description(self, personality: dict) -> str:
        """生成人格描述"""
        big_five = personality['big_five']
        traits = []

        if big_five['conscientiousness'] > 0.7:
            traits.append("谨慎可靠")
        if big_five['openness'] > 0.7:
            traits.append("乐于创新")
        if big_five['agreeableness'] > 0.7:
            traits.append("善于合作")
        if big_five['extraversion'] > 0.7:
            traits.append("活跃互动")

        if not traits:
            traits.append("平衡稳重")

        return f"基于您的偏好生成的个性化人格，特点是{'、'.join(traits)}"

    def _extract_core_traits(self, personality: dict) -> list:
        """提取核心特质"""
        big_five = personality['big_five']
        traits = []

        trait_map = {
            'openness': '开放探索',
            'conscientiousness': '严谨可靠',
            'extraversion': '积极互动',
            'agreeableness': '协作友善',
            'neuroticism': '敏感谨慎'
        }

        # 提取得分最高的3个特质
        sorted_traits = sorted(big_five.items(), key=lambda x: x[1], reverse=True)
        for trait_name, value in sorted_traits[:3]:
            if value > 0.5:
                traits.append(trait_map[trait_name])

        if len(traits) < 3:
            traits.append('持续学习')

        return traits

    def _determine_evolution_level(self, maslow_weights: dict) -> str:
        """根据马斯洛权重确定进化层级"""
        max_weight = max(maslow_weights.values())

        if maslow_weights['self_transcendence'] == max_weight:
            return "self_transcendence"
        elif maslow_weights['self_actualization'] == max_weight:
            return "self_actualization"
        elif maslow_weights['esteem'] == max_weight:
            return "esteem"
        elif maslow_weights['belonging'] == max_weight:
            return "belonging"
        elif maslow_weights['safety'] == max_weight:
            return "safety"
        else:
            return "physiological"

    def _infer_preference(self) -> str:
        """从对话内容推断用户偏好（仅用于快速选择超时）"""
        q1 = self.user_responses.get('q1', '').upper()
        q5 = self.user_responses.get('q5', '').upper()

        # 根据冒险倾向和问题解决风格推断
        if ('A' in q1 or '谨慎' in q1) and ('A' in q5 or '保守' in q5):
            return "谨慎探索型"
        elif ('B' in q1 or '尝试' in q1) and ('B' in q5 or '创新' in q5):
            return "激进创新型"
        else:
            return "平衡稳重型"

    def _generate_confirmation_message(self, personality: dict) -> str:
        """生成确认消息"""
        nickname = self.user_nickname
        traits = personality['core_traits']
        description = personality['description']

        message = f"""太好了！我已经根据你的选择和对话创建了专属的人格配置。

**你选择的称呼**: {nickname}
**核心特质**: {', '.join(traits)}
**人格类型**: {personality['preset_name']}
**描述**: {description}

从现在开始，我将以这个人格与你持续互动。在未来的交互中，我会根据我们的共同经历不断学习和进化。

现在，我们可以开始第一次正式对话了！你有什么想和我聊的吗？"""

        return message

    def _save_personality(self, personality: dict):
        """保存人格配置到文件"""
        # 确保目录存在
        os.makedirs("./agi_memory", exist_ok=True)

        # 保存到文件
        with open("./agi_memory/personality.json", 'w', encoding='utf-8') as f:
            json.dump(personality, f, ensure_ascii=False, indent=2)


# ===== 命令行接口 =====

def main():
    """命令行测试接口"""
    print("=== 人格初始化对话引导器（测试模式） ===\n")

    dialogue = PersonalityInitDialogue(timeout_seconds=30)

    if not dialogue.is_first_interaction():
        print("人格已初始化，跳过引导流程。")
        return

    # 开始对话
    response = dialogue.start_dialogue()
    print(response.message)
    print()

    # 模拟用户交互
    while not dialogue.personality_generated:
        user_input = input("> ").strip()

        if not user_input:
            # 检查超时
            timeout_response = dialogue.check_timeout_status()
            if timeout_response:
                print(timeout_response.message)
                break
            continue

        response = dialogue.process_input(user_input)
        print(response.message)
        print()

        if response.personality_generated:
            print("=== 人格初始化完成 ===")
            break


if __name__ == "__main__":
    main()
