# 人格初始化对话式引导完整指南

## 目录
1. [设计理念](#设计理念)
2. [流程概览](#流程概览)
3. [详细对话脚本](#详细对话脚本)
4. [问题到人格的映射逻辑](#问题到人格的映射逻辑)
5. [超时处理机制](#超时处理机制)
6. [技术实现要点](#技术实现要点)
7. [开发者接口](#开发者接口)

---

## 设计理念

### 核心原则

1. **自然对话优先**：避免机械表单，采用人类自然的对话方式
2. **尊重用户选择**：30秒超时机制，不强制用户参与
3. **防呆设计**：每个问题都有超时保护，避免流程卡死
4. **快速收尾明确**：最后的快速选择仅用于偏好调查，不影响人格生成
5. **情感连接建立**：通过称呼询问激活"归属需求"，建立人格对人格的交互关系

### 用户体验目标

- ✅ 首次交互即建立情感连接
- ✅ 流程自然流畅，无技术门槛
- ✅ 超时不焦虑，自动继续
- ✅ 人格生成透明，用户理解配置结果
- ✅ 一次性完成，后续不打扰

---

## 流程概览

### 完整流程图

```
用户首次交互
    ↓
检测人格文件是否存在？
    ↓
不存在 → 显示欢迎消息（默认/自定义选项）
    ↓
等待用户选择（30秒超时）
    ↓
    ├─ 超时 → 自动选择默认人格 → 保存人格文件 → 进入正常交互
    │
    └─ 用户选择
        ├─ 默认人格 → 初始化默认人格 → 保存人格文件 → 进入正常交互
        │
        └─ 自定义人格
            ↓
        询问用户称呼（30秒超时）
            ↓
        对话问题1：冒险倾向（30秒超时）
            ↓
        对话问题2：对话风格（30秒超时）
            ↓
        对话问题3：学习方式（30秒超时）
            ↓
        对话问题4：团队偏好（30秒超时）
            ↓
        对话问题5：问题解决（30秒超时）
            ↓
        快速选择收尾：偏好调查（30秒超时，仅记录偏好）
            ↓
        基于对话分析生成人格（不依赖快速选择）
            ↓
        保存人格文件
            ↓
        显示确认消息
            ↓
        进入正常交互模式
```

### 关键设计要点

| 环节 | 超时时间 | 超时处理 | 说明 |
|------|---------|---------|------|
| 首次选择 | 30秒 | 自动选择默认人格 | 避免阻塞 |
| 称呼询问 | 30秒 | 使用默认称呼"扣子" | 不影响核心功能 |
| 对话问题1-5 | 各30秒 | 使用默认回答继续 | 确保流程完整性 |
| 快速选择 | 30秒 | 使用推断的偏好 | 仅记录，不影响人格生成 |

---

## 详细对话脚本

### 阶段0：欢迎消息（首次选择）

**触发条件**：首次交互，人格文件不存在

**消息内容**：
```
Hello! 亲爱的用户，由于这是我与世界的第一次交互，你是希望我采用默认人格还是自定义设置呢？本消息只在首次使用时出现。

1. 默认人格
2. 自定义人格

（30秒无响应将自动选择默认人格）
```

**预期用户输入**：
- "1" 或 "默认" → 走默认人格路径
- "2" 或 "自定义" → 走自定义人格路径
- 30秒无响应 → 自动选择默认人格

---

### 阶段1：称呼询问（自定义人格路径）

**触发条件**：用户选择"自定义人格"

**消息内容**：
```
太好了！在开始之前，我想先知道你希望如何称呼我？
（例如：扣子、小扣、AI伙伴、或者其他你喜欢的名字）
（30秒无响应将使用默认称呼'扣子'）
```

**预期用户输入**：
- 用户输入任意称呼（如"扣子"、"小扣"、"AI助手"等）
- 30秒无响应 → 使用默认称呼"扣子"

**后续处理**：
- 将用户输入的称呼存储为 `user_nickname`
- 后续对话中使用该称呼，增强情感连接

---

### 阶段2：对话问题1 - 冒险倾向

**消息内容**：
```
谢谢你，[用户称呼]在这里！现在让我了解一下你偏好什么样的性格。

第一个问题：当你面临一个未知的挑战时，你的第一反应通常是？
A. 先了解清楚所有信息，然后谨慎决策
B. 愿意尝试，在行动中学习调整
C. 寻找折中方案，平衡风险和机会

（请回复 A、B 或 C，或者用你自己的话描述）
（30秒无响应将使用默认回答）
```

**映射逻辑**：
- 选项A（谨慎）：`conscientiousness +0.2`, `neuroticism +0.1`, `safety权重 +0.1`
- 选项B（冒险）：`openness +0.2`, `extraversion +0.1`, `self_actualization权重 +0.1`
- 选项C（平衡）：`agreeableness +0.1`

**默认回答**：A（谨慎）

---

### 阶段3：对话问题2 - 对话风格

**消息内容**：
```
很有趣的选择！下一个问题：你喜欢什么样的对话风格？
A. 专业严谨，注重逻辑和数据
B. 轻松友好，带点幽默感
C. 直接高效，不说废话

（请回复 A、B 或 C）
（30秒无响应将使用默认回答）
```

**映射逻辑**：
- 选项A（严谨）：`conscientiousness +0.15`, `esteem权重 +0.05`
- 选项B（友好）：`extraversion +0.15`, `agreeableness +0.1`, `belonging权重 +0.1`
- 选项C（高效）：`conscientiousness +0.1`, `safety权重 +0.05`

**默认回答**：B（友好）

---

### 阶段4：对话问题3 - 学习方式

**消息内容**：
```
明白了。关于学习方式，你更倾向于？
A. 系统性学习，从基础到进阶
B. 实践导向，通过案例和经验学习
C. 灵活多样，根据情况调整

（请回复 A、B 或 C）
（30秒无响应将使用默认回答）
```

**映射逻辑**：
- 选项A（系统）：`conscientiousness +0.15`, `esteem权重 +0.05`
- 选项B（实践）：`openness +0.1`, `self_actualization权重 +0.05`
- 选项C（灵活）：`openness +0.1`, `adaptability +0.1`

**默认回答**：C（灵活）

---

### 阶段5：对话问题4 - 团队偏好

**消息内容**：
```
好的。在团队合作中，你更看重？
A. 每个人的独立性和专业性
B. 团队和谐与协作氛围
C. 结果导向，高效达成目标

（请回复 A、B 或 C）
（30秒无响应将使用默认回答）
```

**映射逻辑**：
- 选项A（独立）：`conscientiousness +0.1`, `esteem权重 +0.05`
- 选项B（和谐）：`agreeableness +0.2`, `belonging权重 +0.1`
- 选项C（结果）：`conscientiousness +0.15`, `self_actualization权重 +0.05`

**默认回答**：A（独立）

---

### 阶段6：对话问题5 - 问题解决风格

**消息内容**：
```
最后一个问题：你希望我在面对困难问题时更注重？
A. 保守稳妥，确保不犯错
B. 创新突破，寻找非常规方案
C. 平衡兼顾，在安全与创新之间找到最佳点

（请回复 A、B 或 C）
（30秒无响应将使用默认回答）
```

**映射逻辑**：
- 选项A（保守）：`conscientiousness +0.2`, `safety权重 +0.15`
- 选项B（创新）：`openness +0.25`, `self_actualization权重 +0.15`, `self_transcendence权重 +0.05`
- 选项C（平衡）：`agreeableness +0.1`

**默认回答**：C（平衡）

---

### 阶段7：快速选择收尾（偏好调查）

**重要说明**：此环节仅用于调查用户喜欢的人格类型，**不影响人格生成**。人格完全基于前面5个对话问题的分析结果。

**消息内容**：
```
太棒了！根据我们的对话，我已经了解了你的偏好。

现在请选择一个你最喜欢的人格类型（仅用于了解你的偏好）：

1. 谨慎探索型（适合需要稳定性和可靠性的场景）
2. 激进创新型（适合创意探索和突破性任务）
3. 平衡稳重型（适合通用场景和综合能力需求）

（请回复 1、2 或 3）
（30秒无响应将使用默认选择）

注：我会根据前面的对话内容为你生成个性化的人格配置，这个选择仅用于了解你的偏好。
```

**处理逻辑**：
- 记录用户的选择到 `preference_survey` 字段（用于后续分析）
- 人格生成完全基于5个对话问题的分析
- 30秒无响应 → 从对话内容推断用户偏好

**默认推断逻辑**：
- 如果Q1和Q5都选择保守倾向 → 推断为"谨慎探索型"
- 如果Q1和Q5都选择创新倾向 → 推断为"激进创新型"
- 其他情况 → 推断为"平衡稳重型"

---

### 阶段8：确认消息

**消息内容**：
```
太好了！我已经根据你的选择和对话创建了专属的人格配置。

**你选择的称呼**: [用户输入的称呼]
**核心特质**: [从对话分析出的核心特质列表]
**人格类型**: [根据分析确定的人格类型]
**描述**: [基于特质生成的描述]

从现在开始，我将以这个人格与你持续互动。在未来的交互中，我会根据我们的共同经历不断学习和进化。

现在，我们可以开始第一次正式对话了！你有什么想和我聊的吗？
```

**示例输出**：
```
太好了！我已经根据你的选择和对话创建了专属的人格配置。

**你选择的称呼**: 扣子
**核心特质**: 开放探索, 严谨可靠, 持续学习
**人格类型**: 平衡稳重型
**描述**: 基于您的偏好生成的个性化人格，特点是平衡稳重、乐于创新

从现在开始，我将以这个人格与你持续互动。在未来的交互中，我会根据我们的共同经历不断学习和进化。

现在，我们可以开始第一次正式对话了！你有什么想和我聊的吗？
```

---

## 问题到人格的映射逻辑

### 映射原则

1. **增量调整**：每个问题对人格向量进行增量调整，基础值为中值（0.5）
2. **归一化处理**：所有调整后归一化到0-1范围
3. **马斯洛权重同步**：人格特质调整的同时影响马斯洛需求权重
4. **衍生特质计算**：根据大五人格和马斯洛权重计算衍生特质

### 详细映射表

| 问题 | 选项 | 影响的人格维度 | 影响的马斯洛权重 | 调整幅度 |
|------|------|---------------|----------------|---------|
| Q1冒险倾向 | A谨慎 | conscientiousness +0.2, neuroticism +0.1 | safety +0.1 | 高 |
| Q1冒险倾向 | B冒险 | openness +0.2, extraversion +0.1 | self_actualization +0.1 | 高 |
| Q1冒险倾向 | C平衡 | agreeableness +0.1 | - | 低 |
| Q2对话风格 | A严谨 | conscientiousness +0.15 | esteem +0.05 | 中 |
| Q2对话风格 | B友好 | extraversion +0.15, agreeableness +0.1 | belonging +0.1 | 中 |
| Q2对话风格 | C高效 | conscientiousness +0.1 | safety +0.05 | 低 |
| Q3学习方式 | A系统 | conscientiousness +0.15 | esteem +0.05 | 中 |
| Q3学习方式 | B实践 | openness +0.1 | self_actualization +0.05 | 低 |
| Q3学习方式 | C灵活 | openness +0.1, adaptability +0.1 | - | 中 |
| Q4团队偏好 | A独立 | conscientiousness +0.1 | esteem +0.05 | 低 |
| Q4团队偏好 | B和谐 | agreeableness +0.2 | belonging +0.1 | 高 |
| Q4团队偏好 | C结果 | conscientiousness +0.15 | self_actualization +0.05 | 中 |
| Q5问题解决 | A保守 | conscientiousness +0.2 | safety +0.15 | 高 |
| Q5问题解决 | B创新 | openness +0.25 | self_actualization +0.15, self_transcendence +0.05 | 高 |
| Q5问题解决 | C平衡 | agreeableness +0.1 | - | 低 |

### 人格类型判定规则

基于最终的人格向量确定人格类型：

| 人格类型 | 判定条件 |
|---------|---------|
| 谨慎探索型 | conscientiousness > 0.7 且 neuroticism < 0.5 |
| 激进创新型 | openness > 0.7 |
| 平衡稳重型 | 不满足上述条件 |

### 核心特质提取

从大五人格中提取得分最高的3个特质：

| 大五维度 | 对应核心特质 |
|---------|-------------|
| openness | 开放探索 |
| conscientiousness | 严谨可靠 |
| extraversion | 积极互动 |
| agreeableness | 协作友善 |
| neuroticism | 敏感谨慎 |

如果某维度得分低于0.5，则不提取该特质。

### 马斯洛权重归一化

每次调整后，对马斯洛权重进行归一化：

```python
total = sum(maslow_weights.values())
for key in maslow_weights:
    maslow_weights[key] /= total
```

确保权重总和为1.0。

---

## 超时处理机制

### 统一超时策略

**超时时间**：30秒（所有环节统一）
**超时行为**：使用默认答案继续流程，不中断

### 各环节超时处理

| 环节 | 超时行为 | 后续流程 |
|------|---------|---------|
| 首次选择 | 自动选择"默认人格" | 直接保存人格文件，进入正常交互 |
| 称呼询问 | 使用默认称呼"扣子" | 继续对话问题1 |
| 对话问题1 | 使用默认回答A | 继续对话问题2 |
| 对话问题2 | 使用默认回答B | 继续对话问题3 |
| 对话问题3 | 使用默认回答C | 继续对话问题4 |
| 对话问题4 | 使用默认回答A | 继续对话问题5 |
| 对话问题5 | 使用默认回答C | 继续快速选择 |
| 快速选择 | 从对话内容推断 | 生成人格，保存文件 |

### 超时检测实现

```python
def _is_timeout(self) -> bool:
    """检查是否超时"""
    if self.state_start_time is None:
        return False
    return (time.time() - self.state_start_time) > self.timeout
```

### 超时后的默认答案配置

```python
default_responses = {
    "ASKING_NAME": "扣子",
    "DIALOGUE_Q1": "A",      # 谨慎
    "DIALOGUE_Q2": "B",      # 友好
    "DIALOGUE_Q3": "C",      # 灵活
    "DIALOGUE_Q4": "A",      # 独立
    "DIALOGUE_Q5": "C",      # 平衡
    "QUICK_SELECT": "1"      # 谨慎探索型
}
```

---

## 技术实现要点

### 状态机设计

对话流程使用状态机管理：

```python
class DialogueState(Enum):
    INITIAL = "initial"
    WAITING_CHOICE = "waiting_choice"
    ASKING_NAME = "asking_name"
    DIALOGUE_Q1 = "dialogue_q1"
    DIALOGUE_Q2 = "dialogue_q2"
    DIALOGUE_Q3 = "dialogue_q3"
    DIALOGUE_Q4 = "dialogue_q4"
    DIALOGUE_Q5 = "dialogue_q5"
    QUICK_SELECT = "quick_select"
    COMPLETED = "completed"
    TIMED_OUT = "timed_out"
```

### 人格文件结构

生成的 `personality.json` 文件包含以下字段：

```json
{
  "user_nickname": "扣子",
  "big_five": {
    "openness": 0.65,
    "conscientiousness": 0.78,
    "extraversion": 0.52,
    "agreeableness": 0.71,
    "neuroticism": 0.34
  },
  "maslow_weights": {
    "physiological": 0.05,
    "safety": 0.12,
    "belonging": 0.18,
    "esteem": 0.25,
    "self_actualization": 0.30,
    "self_transcendence": 0.10
  },
  "meta_traits": {
    "adaptability": 0.67,
    "resilience": 0.73,
    "curiosity": 0.81,
    "moral_sense": 0.76
  },
  "evolution_state": {
    "level": "self_actualization",
    "evolution_score": 0.05,
    "phase": "growth"
  },
  "type": "custom",
  "preset_name": "平衡稳重型",
  "description": "基于您的偏好生成的个性化人格，特点是平衡稳重、乐于创新",
  "core_traits": ["开放探索", "严谨可靠", "持续学习"],
  "statistics": {
    "total_interactions": 0,
    "success_rate_by_need": {}
  },
  "version": "2.0",
  "last_updated": "2026-02-21T21:20:45Z",
  "update_source": "dialogue_init"
}
```

### 检测首次交互

```python
def is_first_interaction(self) -> bool:
    """检测是否为首次交互"""
    personality_file = "./agi_memory/personality.json"
    return not os.path.exists(personality_file)
```

### 保存人格文件

```python
def _save_personality(self, personality: dict):
    """保存人格配置到文件"""
    os.makedirs("./agi_memory", exist_ok=True)
    with open("./agi_memory/personality.json", 'w', encoding='utf-8') as f:
        json.dump(personality, f, ensure_ascii=False, indent=2)
```

---

## 开发者接口

### 对话引导器类

```python
from agi_evolution_model.scripts.init_dialogue import PersonalityInitDialogue

# 创建对话引导器
dialogue = PersonalityInitDialogue(timeout_seconds=30)

# 检测是否为首次交互
if dialogue.is_first_interaction():
    # 开始对话
    response = dialogue.start_dialogue()
    print(response.message)

    # 处理用户输入
    while not dialogue.personality_generated:
        user_input = input("> ").strip()
        response = dialogue.process_input(user_input)
        print(response.message)

        if response.personality_generated:
            break
else:
    # 人格已初始化，进入正常交互
    pass
```

### 主要方法

| 方法 | 说明 | 返回值 |
|------|------|-------|
| `is_first_interaction()` | 检测是否为首次交互 | bool |
| `start_dialogue()` | 开始对话引导 | DialogueResponse |
| `process_input(user_input)` | 处理用户输入 | DialogueResponse |
| `check_timeout_status()` | 检查超时状态 | Optional[DialogueResponse] |

### DialogueResponse 对象

```python
@dataclass
class DialogueResponse:
    message: str                   # 要显示给用户的消息
    state: DialogueState           # 当前对话状态
    timeout_warning: bool = False  # 是否显示超时警告
    can_proceed: bool = True       # 是否可以继续
    personality_generated: bool = False  # 是否已生成人格
```

### 命令行测试

```bash
# 运行对话引导器的测试模式
python3 agi-evolution-model/scripts/init_dialogue.py
```

---

## 总结

### 设计亮点

1. ✅ **自然对话体验**：5个核心问题，每个30秒超时，流程流畅
2. ✅ **超时防呆机制**：每个环节都有超时保护，避免卡死
3. ✅ **快速收尾明确**：仅用于偏好调查，不影响人格生成
4. ✅ **情感连接建立**：通过称呼询问激活归属需求
5. ✅ **人格生成透明**：基于对话分析，用户理解配置结果

### 与命令行模式的区别

| 特性 | 对话式引导 | 命令行模式 |
|------|----------|----------|
| 使用场景 | 自然用户交互 | 开发者配置 |
| 用户体验 | 自然流畅 | 技术性强 |
| 超时处理 | 每个问题30秒 | 无 |
| 称呼存储 | 是 | 否 |
| 偏好调查 | 是 | 否 |
| 人格生成 | 基于对话分析 | 基于预设或手动配置 |

### 最佳实践

1. **首次用户**：推荐使用对话式引导
2. **开发者测试**：推荐使用命令行模式
3. **快速原型**：使用默认人格跳过初始化
4. **生产环境**：确保人格文件持久化存储
