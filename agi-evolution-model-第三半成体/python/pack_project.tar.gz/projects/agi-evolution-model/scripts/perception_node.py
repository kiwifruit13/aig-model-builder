#!/usr/bin/env python3
"""
AGI进化模型 - 感知节点（Tool Use 接口）

功能：
1. 工具调用标准化接口
2. 参数验证
3. 执行结果标准化（status + data + metadata）
4. 错误处理和重试

设计原则：
- 纯函数式工具，无服务或交互循环
- 所有参数通过命令行传入
- 返回结构化数据，无噪音
"""

import json
import sys
import time
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple


# 工具注册表（示例工具，实际使用时可以扩展）
TOOL_REGISTRY = {
    "web_search": {
        "description": "执行网络搜索",
        "parameters": {
            "query": {"type": "string", "required": True},
            "limit": {"type": "integer", "required": False, "default": 10}
        }
    },
    "file_read": {
        "description": "读取文件内容",
        "parameters": {
            "path": {"type": "string", "required": True},
            "encoding": {"type": "string", "required": False, "default": "utf-8"}
        }
    },
    "calculator": {
        "description": "执行数学计算",
        "parameters": {
            "expression": {"type": "string", "required": True}
        }
    },
    "get_weather": {
        "description": "获取天气信息",
        "parameters": {
            "location": {"type": "string", "required": True},
            "unit": {"type": "string", "required": False, "default": "celsius", "enum": ["celsius", "fahrenheit"]}
        }
    }
}


def validate_parameters(tool_name: str, parameters: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
    """
    验证工具参数
    
    参数：
        tool_name: 工具名称
        parameters: 参数字典
    
    返回：
        (是否有效, 错误信息)
    """
    if tool_name not in TOOL_REGISTRY:
        return False, f"Unknown tool: {tool_name}"
    
    tool_spec = TOOL_REGISTRY[tool_name]
    param_specs = tool_spec.get("parameters", {})
    
    # 检查必需参数
    for param_name, param_spec in param_specs.items():
        if param_spec.get("required", False) and param_name not in parameters:
            return False, f"Missing required parameter: {param_name}"
        
        # 检查枚举值
        if param_name in parameters and "enum" in param_spec:
            value = parameters[param_name]
            if value not in param_spec["enum"]:
                return False, f"Invalid value for {param_name}: {value}. Must be one of {param_spec['enum']}"
    
    return True, None


def simulate_tool_execution(tool_name: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
    """
    模拟工具执行（实际使用时替换为真实工具调用）
    
    参数：
        tool_name: 工具名称
        parameters: 参数字典
    
    返回：
        工具执行结果
    """
    # 注意：这是模拟实现，实际使用时需要替换为真实的工具调用
    # 例如：调用搜索API、读取文件、执行计算等
    
    if tool_name == "web_search":
        return {
            "results": [
                {"title": "示例搜索结果1", "url": "https://example.com/1", "snippet": "这是搜索摘要"},
                {"title": "示例搜索结果2", "url": "https://example.com/2", "snippet": "这是搜索摘要"}
            ],
            "count": 2
        }
    
    elif tool_name == "file_read":
        # 模拟文件读取
        return {
            "content": "这是文件内容的模拟结果",
            "size": 1024,
            "encoding": parameters.get("encoding", "utf-8")
        }
    
    elif tool_name == "calculator":
        # 简单的计算器模拟
        expr = parameters.get("expression", "")
        try:
            # 安全限制：仅允许基础运算
            allowed_chars = set("0123456789+-*/.() ")
            if not all(c in allowed_chars for c in expr):
                raise ValueError("Invalid characters in expression")
            result = eval(expr)
            return {"expression": expr, "result": result}
        except Exception as e:
            raise ValueError(f"Calculation error: {str(e)}")
    
    elif tool_name == "get_weather":
        location = parameters.get("location", "Unknown")
        unit = parameters.get("unit", "celsius")
        # 模拟天气数据
        temp = 25 if unit == "celsius" else 77
        return {
            "location": location,
            "temperature": temp,
            "condition": "sunny",
            "unit": unit
        }
    
    else:
        raise ValueError(f"Tool not implemented: {tool_name}")


def call_tool(tool_name: str, parameters: Dict[str, Any], max_retries: int = 2) -> Dict[str, Any]:
    """
    调用工具并返回标准化结果
    
    参数：
        tool_name: 工具名称
        parameters: 参数字典
        max_retries: 最大重试次数
    
    返回：
        标准化响应字典
    """
    start_time = datetime.now()
    
    # 参数验证
    is_valid, error_msg = validate_parameters(tool_name, parameters)
    if not is_valid:
        return {
            "success": False,
            "status": "error",
            "error": {
                "code": "INVALID_PARAMS",
                "message": error_msg
            },
            "metadata": {
                "tool_name": tool_name,
                "timestamp": start_time.isoformat()
            }
        }
    
    # 执行工具（带重试）
    last_error = None
    for attempt in range(max_retries + 1):
        try:
            data = simulate_tool_execution(tool_name, parameters)
            
            # 成功
            end_time = datetime.now()
            execution_time_ms = (end_time - start_time).total_seconds() * 1000
            
            return {
                "success": True,
                "status": "success",
                "data": data,
                "metadata": {
                    "tool_name": tool_name,
                    "execution_time_ms": round(execution_time_ms, 2),
                    "timestamp": end_time.isoformat(),
                    "attempts": attempt + 1
                }
            }
        
        except Exception as e:
            last_error = str(e)
            if attempt < max_retries:
                # 重试前等待
                time.sleep(0.5 * (attempt + 1))
            else:
                # 重试用尽，返回错误
                end_time = datetime.now()
                execution_time_ms = (end_time - start_time).total_seconds() * 1000
                
                # 确定错误类型
                error_code = "UNKNOWN_ERROR"
                if "permission" in str(e).lower():
                    error_code = "PERMISSION_DENIED"
                elif "not found" in str(e).lower():
                    error_code = "RESOURCE_NOT_FOUND"
                elif "timeout" in str(e).lower():
                    error_code = "TIMEOUT"
                
                return {
                    "success": False,
                    "status": "error",
                    "error": {
                        "code": error_code,
                        "message": last_error
                    },
                    "metadata": {
                        "tool_name": tool_name,
                        "execution_time_ms": round(execution_time_ms, 2),
                        "timestamp": end_time.isoformat(),
                        "attempts": max_retries + 1
                    }
                }


def list_tools() -> Dict[str, Any]:
    """
    列出所有可用工具
    
    返回：
        包含工具列表的字典
    """
    tools_info = []
    for tool_name, tool_spec in TOOL_REGISTRY.items():
        tools_info.append({
            "name": tool_name,
            "description": tool_spec["description"],
            "parameters": tool_spec["parameters"]
        })
    
    return {
        "success": True,
        "count": len(tools_info),
        "tools": tools_info
    }


def main():
    """命令行接口"""
    if len(sys.argv) < 2:
        print("Usage: python perception_node.py <command> [options]", file=sys.stderr)
        print("Commands:", file=sys.stderr)
        print("  list                          - 列出所有可用工具", file=sys.stderr)
        print("  call --tool <name> --params '<json>' - 调用工具", file=sys.stderr)
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "list":
        result = list_tools()
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "call":
        if "--tool" not in sys.argv or "--params" not in sys.argv:
            print(json.dumps({"success": False, "error": "Missing --tool or --params"}, ensure_ascii=False))
            sys.exit(1)
        
        tool_idx = sys.argv.index("--tool")
        tool_name = sys.argv[tool_idx + 1]
        
        params_idx = sys.argv.index("--params")
        parameters = json.loads(sys.argv[params_idx + 1])
        
        result = call_tool(tool_name, parameters)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    else:
        print(f"Unknown command: {command}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
