#!/usr/bin/env python3
"""
AGI进化模型 - 映射层（人格层）核心逻辑

功能：
1. 人格向量初始化与管理（大五人格 + 马斯洛需求权重）
2. 从记录态提取"哲学信息"（价值偏好、成功/失败模式）
3. 需求层次映射（感知数据 → 需求激活 → 优先级计算）
4. 人格向量更新（基于洞察和实效性反馈）
5. 即时性与实效性计算
6. 生成对自我迭代顶点的进化建议

升级特性（整合自MAPPING_LAYER_IMPLEMENTATION）：
- 6层级马斯洛权重（含self_transcendence）
- 哲学洞察缓冲区（支持新颖性、哲学深度、马斯洛对齐度标记）
- 完整的人格更新算法（基于调整系数和哲学深度分级）
- 即时性/实效性反馈包
- 人格震荡检测与缓解
- 马斯洛螺旋上升验证

设计原则：
- 纯函数式工具，无服务或交互循环
- 所有数据通过参数传入
- 人格变化保持渐进性和稳定性
"""

import json
import os
import sys
from typing import Dict, List, Optional, Any, Tuple
from collections import Counter, deque
from datetime import datetime
import copy


# 记忆存储路径（与memory_store.py保持一致）
MEMORY_DIR = "./agi_memory"
RECORDS_FILE = os.path.join(MEMORY_DIR, "records.json")
PERSONALITY_FILE = os.path.join(MEMORY_DIR, "personality.json")
INSIGHT_BUFFER_FILE = os.path.join(MEMORY_DIR, "insight_buffer.json")


def ensure_memory_dir() -> None:
    """确保记忆存储目录存在"""
    if not os.path.exists(MEMORY_DIR):
        try:
            os.makedirs(MEMORY_DIR)
        except Exception as e:
            print(f"Error creating memory directory: {e}", file=sys.stderr)
            sys.exit(1)


# ============================================================================
# 核心数据结构
# ============================================================================

# 洞察类型到人格维度的映射规则
INSIGHT_TO_TRAIT_MAPPING = {
    'preference_pattern': 'openness',
    'efficiency_improvement': 'conscientiousness',
    'social_feedback': 'agreeableness',
    'uncertainty_handling': 'neuroticism',
    'engagement_pattern': 'extraversion'
}

# 马斯洛需求层级（6层级）
MASLOW_LEVELS = [
    'physiological',      # 生理需求
    'safety',             # 安全需求
    'belonging',          # 归属需求
    'esteem',             # 尊重需求
    'self_actualization', # 自我实现
    'self_transcendence'  # 自我超越
]

# 哲学深度分级调整幅度
PHILOSOPHICAL_DEPTH_ADJUSTMENT = {
    'philosophical': 0.10,  # > 0.8: 哲学级调整
    'experiential': 0.05,   # > 0.5: 经验级调整
    'micro': 0.02           # 其他: 微调
}


# ============================================================================
# 预设人格种子
# ============================================================================

PRESET_PERSONALITIES = {
    "谨慎探索型": {
        "名称": "谨慎探索型",
        "描述": "在保证安全的前提下，愿意尝试新事物",
        "人格向量": {
            "openness": 0.6,
            "conscientiousness": 0.8,
            "extraversion": 0.4,
            "agreeableness": 0.6,
            "neuroticism": 0.5
        },
        "马斯洛权重": {
            "physiological": 0.35,
            "safety": 0.35,
            "belonging": 0.1,
            "esteem": 0.1,
            "self_actualization": 0.08,
            "self_transcendence": 0.02
        },
        "核心特质": ["谨慎", "可靠", "愿意学习"]
    },
    
    "激进创新型": {
        "名称": "激进创新型",
        "描述": "追求创新，愿意承担风险，挑战常规",
        "人格向量": {
            "openness": 0.9,
            "conscientiousness": 0.6,
            "extraversion": 0.7,
            "agreeableness": 0.5,
            "neuroticism": 0.3
        },
        "马斯洛权重": {
            "physiological": 0.2,
            "safety": 0.15,
            "belonging": 0.1,
            "esteem": 0.2,
            "self_actualization": 0.25,
            "self_transcendence": 0.1
        },
        "核心特质": ["创新", "冒险", "挑战"]
    },
    
    "平衡稳重型": {
        "名称": "平衡稳重型",
        "描述": "在各种需求之间保持平衡，追求稳定发展",
        "人格向量": {
            "openness": 0.5,
            "conscientiousness": 0.7,
            "extraversion": 0.5,
            "agreeableness": 0.7,
            "neuroticism": 0.4
        },
        "马斯洛权重": {
            "physiological": 0.25,
            "safety": 0.25,
            "belonging": 0.2,
            "esteem": 0.15,
            "self_actualization": 0.1,
            "self_transcendence": 0.05
        },
        "核心特质": ["平衡", "稳定", "协调"]
    }
}

DEFAULT_PERSONALITY = "谨慎探索型"


# ============================================================================
# 哲学洞察缓冲区
# ============================================================================

class InsightBuffer:
    """哲学洞察缓冲区（FIFO队列）"""
    
    def __init__(self, max_size: int = 50):
        self.max_size = max_size
        self.buffer = deque(maxlen=max_size)
        self.last_flush = datetime.now().isoformat()
    
    def add_insight(self, insight: Dict[str, Any]) -> bool:
        """
        添加哲学洞察到缓冲区
        
        参数：
            insight: 哲学洞察字典，必须包含：
                - content: 洞察内容
                - type: 洞察类型
                - novelty_score: 新颖性 [0,1]
                - philosophical_depth: 哲学深度 [0,1]
                - maslow_alignment: 马斯洛对齐度 [0,1]
                - intensity: 洞察强度 [0,1]
        
        返回：
            是否添加成功
        """
        try:
            insight_obj = {
                "id": f"insight_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                "timestamp": datetime.now().isoformat(),
                "source": "recording_layer",
                "content": insight.get('content', ''),
                "type": insight.get('type', 'unknown'),
                "novelty_score": float(insight.get('novelty_score', 0.5)),
                "philosophical_depth": float(insight.get('philosophical_depth', 0.5)),
                "maslow_alignment": float(insight.get('maslow_alignment', 0.5)),
                "intensity": float(insight.get('intensity', 0.5)),
                "processed": False
            }
            self.buffer.append(insight_obj)
            return True
        except Exception as e:
            print(f"Error adding insight to buffer: {e}", file=sys.stderr)
            return False
    
    def get_next_insight(self) -> Optional[Dict[str, Any]]:
        """获取下一个未处理的洞察"""
        for insight in self.buffer:
            if not insight.get('processed', False):
                return insight
        return None
    
    def mark_processed(self, insight_id: str) -> bool:
        """标记洞察为已处理"""
        for insight in self.buffer:
            if insight.get('id') == insight_id:
                insight['processed'] = True
                return True
        return False
    
    def flush_processed(self) -> int:
        """清理已处理的洞察，返回清理数量"""
        initial_size = len(self.buffer)
        self.buffer = deque(
            [i for i in self.buffer if not i.get('processed', False)],
            maxlen=self.max_size
        )
        self.last_flush = datetime.now().isoformat()
        return initial_size - len(self.buffer)
    
    def save(self) -> bool:
        """保存缓冲区到文件"""
        ensure_memory_dir()
        try:
            data = {
                "buffer": list(self.buffer),
                "buffer_size": self.max_size,
                "last_flush": self.last_flush
            }
            with open(INSIGHT_BUFFER_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"Error saving insight buffer: {e}", file=sys.stderr)
            return False
    
    def load(self) -> bool:
        """从文件加载缓冲区"""
        if not os.path.exists(INSIGHT_BUFFER_FILE):
            return True
        
        try:
            with open(INSIGHT_BUFFER_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.buffer = deque(data.get('buffer', []), maxlen=self.max_size)
                self.max_size = data.get('buffer_size', 50)
                self.last_flush = data.get('last_flush', datetime.now().isoformat())
            return True
        except Exception as e:
            print(f"Error loading insight buffer: {e}", file=sys.stderr)
            return False
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            "insight_buffer": list(self.buffer),
            "buffer_size": self.max_size,
            "last_flush": self.last_flush,
            "unprocessed_count": sum(1 for i in self.buffer if not i.get('processed', False))
        }


# ============================================================================
# 核心计算函数
# ============================================================================

def compute_meta_traits(personality: Dict[str, Any]) -> Dict[str, float]:
    """
    计算衍生特质（由基础人格和马斯洛权重计算得出）
    
    参数：
        personality: 人格向量字典，包含 big_five 和 maslow_weights
    
    返回：
        衍生特质字典：adaptability, resilience, curiosity, moral_sense
    """
    big_five = personality.get('big_five', {})
    maslow = personality.get('maslow_weights', {})
    
    # 适应性：开放性 + 低神经质 + 高层需求权重
    adaptability = (
        big_five.get('openness', 0.5) * 0.4 +
        (1 - big_five.get('neuroticism', 0.5)) * 0.3 +
        (maslow.get('self_actualization', 0) + maslow.get('self_transcendence', 0)) * 0.3
    )
    
    # 韧性：高尽责性 + 宜人性 + 安全需求权重
    resilience = (
        big_five.get('conscientiousness', 0.5) * 0.4 +
        big_five.get('agreeableness', 0.5) * 0.3 +
        maslow.get('safety', 0) * 0.3
    )
    
    # 好奇心：高开放性 + 外向性 + 归属/尊重需求权重
    curiosity = (
        big_five.get('openness', 0.5) * 0.5 +
        big_five.get('extraversion', 0.5) * 0.3 +
        (maslow.get('belonging', 0) + maslow.get('esteem', 0)) * 0.2
    )
    
    # 道德感：高宜人性 + 尽责性 + 自我超越权重
    moral_sense = (
        big_five.get('agreeableness', 0.5) * 0.4 +
        big_five.get('conscientiousness', 0.5) * 0.3 +
        maslow.get('self_transcendence', 0) * 0.3
    )
    
    # 限制在[0,1]范围内
    return {
        'adaptability': min(max(adaptability, 0.0), 1.0),
        'resilience': min(max(resilience, 0.0), 1.0),
        'curiosity': min(max(curiosity, 0.0), 1.0),
        'moral_sense': min(max(moral_sense, 0.0), 1.0)
    }


def normalize_maslow_weights(maslow_weights: Dict[str, float]) -> Dict[str, float]:
    """
    归一化马斯洛权重（确保总和为1.0）
    
    参数：
        maslow_weights: 马斯洛权重字典
    
    返回：
        归一化后的权重字典
    """
    total = sum(maslow_weights.values())
    if total == 0:
        return {k: 1.0 / len(MASLOW_LEVELS) for k in MASLOW_LEVELS}
    
    return {k: maslow_weights.get(k, 0) / total for k in MASLOW_LEVELS}


def update_evolution_state(personality: Dict[str, Any]) -> Dict[str, Any]:
    """
    更新进化状态
    
    参数：
        personality: 人格向量字典
    
    返回：
        进化状态字典
    """
    maslow = personality.get('maslow_weights', {})
    
    # 找出权重最高的需求层次
    max_weight = 0
    dominant_level = 'physiological'
    
    for level in MASLOW_LEVELS:
        if maslow.get(level, 0) > max_weight:
            max_weight = maslow.get(level, 0)
            dominant_level = level
    
    # 计算进化分数（高层需求权重之和）
    evolution_score = (
        maslow.get('esteem', 0) * 0.3 +
        maslow.get('self_actualization', 0) * 0.5 +
        maslow.get('self_transcendence', 0) * 0.2
    )
    
    # 确定进化阶段
    if evolution_score < 0.3:
        phase = 'growth'
    elif evolution_score < 0.7:
        phase = 'stable'
    else:
        phase = 'plateau'
    
    return {
        'level': dominant_level,
        'evolution_score': min(max(evolution_score, 0.0), 1.0),
        'phase': phase
    }


def detect_personality_oscillation(personality_history: List[Dict[str, Any]], 
                                   max_adjustment: float = 0.05) -> Tuple[bool, List[str]]:
    """
    检测人格震荡（风险缓解机制）
    
    参数：
        personality_history: 人格历史记录列表
        max_adjustment: 最大允许调整阈值
    
    返回：
        (是否震荡, 震荡维度列表)
    """
    if len(personality_history) < 3:
        return False, []
    
    # 检查最近的调整幅度
    recent = personality_history[-3:]
    oscillating_traits = []
    
    for trait in ['openness', 'conscientiousness', 'extraversion', 'agreeableness', 'neuroticism']:
        values = [p.get('big_five', {}).get(trait, 0.5) for p in recent]
        # 计算相邻变化的幅度
        for i in range(len(values) - 1):
            if abs(values[i+1] - values[i]) > max_adjustment:
                oscillating_traits.append(trait)
                break
    
    return len(oscillating_traits) > 0, oscillating_traits


def detect_maslow_spiral(maslow_history: List[Dict[str, float]], 
                        min_ascent_rate: float = 0.01) -> Tuple[bool, str]:
    """
    检测马斯洛螺旋上升（风险缓解机制）
    
    参数：
        maslow_history: 马斯洛权重历史记录列表
        min_ascent_rate: 最小上升率阈值
    
    返回：
        (是否上升, 上升类型)
    """
    if len(maslow_history) < 2:
        return False, "insufficient_data"
    
    # 计算高层需求权重增长率
    prev = maslow_history[-2]
    curr = maslow_history[-1]
    
    ascent_sum = 0
    ascent_count = 0
    
    for level in ['esteem', 'self_actualization', 'self_transcendence']:
        prev_weight = prev.get(level, 0)
        curr_weight = curr.get(level, 0)
        ascent_sum += curr_weight - prev_weight
        ascent_count += 1
    
    avg_ascent = ascent_sum / ascent_count if ascent_count > 0 else 0
    
    if avg_ascent >= min_ascent_rate:
        return True, "ascending"
    elif avg_ascent <= -min_ascent_rate:
        return True, "descending"
    else:
        return False, "stable"


def update_personality(insight: Dict[str, Any], 
                      current_personality: Dict[str, Any],
                      personality_history: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    基于哲学洞察更新人格向量（核心算法）
    
    参数：
        insight: 哲学洞察对象，包含：
            - type: 洞察类型
            - intensity: 洞察强度 [0,1]
            - philosophical_depth: 哲学深度 [0,1]
            - maslow_alignment: 马斯洛对齐度 [0,1]
        current_personality: 当前人格向量
        personality_history: 人格历史记录（用于震荡检测）
    
    返回：
        更新后的人格向量
    """
    # 深拷贝，避免修改原始数据
    updated = copy.deepcopy(current_personality)
    
    # 1. 计算调整系数
    adjustment_coefficient = (
        insight.get('intensity', 0.5) * 
        insight.get('maslow_alignment', 0.5)
    )
    
    # 2. 根据哲学深度确定调整幅度
    philosophical_depth = insight.get('philosophical_depth', 0.5)
    if philosophical_depth > 0.8:
        magnitude = PHILOSOPHICAL_DEPTH_ADJUSTMENT['philosophical']
    elif philosophical_depth > 0.5:
        magnitude = PHILOSOPHICAL_DEPTH_ADJUSTMENT['experiential']
    else:
        magnitude = PHILOSOPHICAL_DEPTH_ADJUSTMENT['micro']
    
    delta = adjustment_coefficient * magnitude
    
    # 3. 震荡检测与缓解
    oscillating, traits = detect_personality_oscillation(personality_history)
    if oscillating:
        # 如果检测到震荡，应用平滑因子（降低调整幅度）
        delta *= 0.5
        print(f"Warning: Personality oscillation detected on traits {traits}, applying smoothing", file=sys.stderr)
    
    # 4. 根据洞察类型调整对应的人格维度
    insight_type = insight.get('type', 'unknown')
    target_trait = INSIGHT_TO_TRAIT_MAPPING.get(insight_type)
    
    if target_trait:
        # 单向调整（哲学洞察只能增强，不能削弱）
        current_value = updated.get('big_five', {}).get(target_trait, 0.5)
        new_value = min(current_value + delta, 1.0)
        updated['big_five'][target_trait] = new_value
    
    # 5. 更新马斯洛权重（螺旋上升）
    if insight.get('maslow_alignment', 0.5) >= 0.7:
        # 高层洞察推动权重向上流动
        for level in MASLOW_LEVELS:
            current_weight = updated.get('maslow_weights', {}).get(level, 0)
            # 权重增长率与洞察强度和马斯洛对齐度相关
            growth_rate = delta * 0.1
            updated['maslow_weights'][level] = current_weight * (1 + growth_rate)
    
    # 6. 归一化马斯洛权重
    updated['maslow_weights'] = normalize_maslow_weights(updated.get('maslow_weights', {}))
    
    # 7. 更新衍生特质
    updated['meta_traits'] = compute_meta_traits(updated)
    
    # 8. 更新进化状态
    updated['evolution_state'] = update_evolution_state(updated)
    
    # 9. 更新时间戳
    updated['last_updated'] = datetime.now().isoformat()
    updated['update_source'] = 'philosophical_insight'
    
    return updated


def compute_timeliness_feedback(perception_latency: float,
                               decision_latency: float,
                               execution_latency: float) -> Dict[str, Any]:
    """
    计算即时性反馈
    
    参数：
        perception_latency: 感知延迟（秒）
        decision_latency: 决策延迟（秒）
        execution_latency: 执行延迟（秒）
    
    返回：
        即时性指标字典
    """
    total_latency = perception_latency + decision_latency + execution_latency
    
    # 理想阈值：总延迟 < 3秒
    ideal_threshold = 3.0
    
    # 计算延迟得分（越小越好，使用归一化到[0,1]）
    latency_score = max(1 - (total_latency / (ideal_threshold * 2)), 0.0)
    
    return {
        'perception_latency': round(perception_latency, 2),
        'decision_latency': round(decision_latency, 2),
        'execution_latency': round(execution_latency, 2),
        'total_latency': round(total_latency, 2),
        'latency_score': round(latency_score, 2)
    }


def compute_effectiveness_feedback(goal_achievement_rate: float,
                                  resource_consumption: float,
                                  side_effects: float) -> Dict[str, Any]:
    """
    计算实效性反馈
    
    参数：
        goal_achievement_rate: 目标达成率 [0,1]
        resource_consumption: 资源消耗 [0,1]
        side_effects: 副作用 [0,1]
    
    返回：
        实效性指标字典
    """
    # 实效性得分：目标达成率 - 资源消耗/2 - 副作用/2
    effectiveness_score = (
        goal_achievement_rate * 0.6 +
        (1 - resource_consumption) * 0.2 +
        (1 - side_effects) * 0.2
    )
    
    return {
        'goal_achievement_rate': round(goal_achievement_rate, 3),
        'resource_consumption': round(resource_consumption, 3),
        'side_effects': round(side_effects, 3),
        'effectiveness_score': round(effectiveness_score, 3)
    }


def generate_feedback_package(timeliness: Dict[str, Any],
                             effectiveness: Dict[str, Any],
                             personality: Dict[str, Any],
                             traits_used: List[str]) -> Dict[str, Any]:
    """
    生成完整的反馈包
    
    参数：
        timeliness: 即时性指标
        effectiveness: 实效性指标
        personality: 人格向量
        traits_used: 使用的人格维度列表
    
    返回：
        完整反馈包
    """
    # 计算人格与任务的对齐度
    trait_alignment = 0.0
    if traits_used and len(traits_used) > 0:
        total_trait_value = sum(personality.get('big_five', {}).get(t, 0.5) for t in traits_used)
        trait_alignment = total_trait_value / len(traits_used)
    
    # 生成迭代建议
    suggestions = []
    
    # 基于实效性得分生成建议
    if effectiveness['effectiveness_score'] < 0.6:
        suggestions.append(f"建议强化{'/'.join(traits_used)}在当前任务中的应用")
    
    # 基于延迟得分生成建议
    if timeliness['latency_score'] < 0.6:
        suggestions.append("建议优化决策流程，减少延迟")
    
    return {
        'timeliness_metrics': timeliness,
        'effectiveness_metrics': effectiveness,
        'personality_feedback': {
            'traits_used': traits_used,
            'trait_alignment': round(trait_alignment, 2),
            'stress_level': round(personality.get('big_five', {}).get('neuroticism', 0.5), 2),
            'confidence': round(trait_alignment * 0.8 + effectiveness['effectiveness_score'] * 0.2, 2)
        },
        'meta_feedback': {
            'iteration_suggestion': suggestions[0] if suggestions else "继续当前策略",
            'priority_adjustment': {},
            'pattern_matched': 'unknown'
        }
    }


# ============================================================================
# 数据持久化
# ============================================================================

def load_personality() -> Dict[str, Any]:
    """加载人格向量，如果不存在则返回默认初始化值"""
    if not os.path.exists(PERSONALITY_FILE):
        return initialize_personality()
    
    try:
        with open(PERSONALITY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading personality: {e}", file=sys.stderr)
        return initialize_personality()


def save_personality(personality: Dict[str, Any]) -> bool:
    """保存人格向量"""
    ensure_memory_dir()
    try:
        with open(PERSONALITY_FILE, 'w', encoding='utf-8') as f:
            json.dump(personality, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"Error saving personality: {e}", file=sys.stderr)
        return False


# ============================================================================
# 人格初始化
# ============================================================================

def initialize_personality(preset_name: Optional[str] = None, 
                          custom_personality: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    初始化人格向量
    
    参数：
        preset_name: 预设人格名称（"谨慎探索型"、"激进创新型"、"平衡稳重型"）
        custom_personality: 自定义人格字典，包含"人格向量"和"马斯洛权重"
    
    返回：
        完整的人格向量字典
    """
    # 如果提供了自定义人格
    if custom_personality:
        big_five = custom_personality.get("人格向量", {})
        maslow_weights = custom_personality.get("马斯洛权重", {})
        
        # 确保6层级马斯洛权重完整
        for level in MASLOW_LEVELS:
            if level not in maslow_weights:
                maslow_weights[level] = 0.0
        
        # 归一化
        maslow_weights = normalize_maslow_weights(maslow_weights)
        
        personality = {
            "big_five": big_five,
            "maslow_weights": maslow_weights,
            "meta_traits": {},
            "evolution_state": {},
            "statistics": {
                "total_interactions": 0,
                "success_rate_by_need": {level: 0.0 for level in MASLOW_LEVELS}
            },
            "version": "2.0",
            "type": "custom"
        }
        
        # 计算衍生特质和进化状态
        personality['meta_traits'] = compute_meta_traits(personality)
        personality['evolution_state'] = update_evolution_state(personality)
        
        return personality
    
    # 如果提供了预设人格名称
    if preset_name and preset_name in PRESET_PERSONALITIES:
        preset = PRESET_PERSONALITIES[preset_name]
        big_five = preset["人格向量"]
        maslow_weights = preset["马斯洛权重"]
        
        # 确保6层级完整
        for level in MASLOW_LEVELS:
            if level not in maslow_weights:
                maslow_weights[level] = 0.0
        
        personality = {
            "big_five": big_five,
            "maslow_weights": maslow_weights,
            "meta_traits": {},
            "evolution_state": {},
            "statistics": {
                "total_interactions": 0,
                "success_rate_by_need": {level: 0.0 for level in MASLOW_LEVELS}
            },
            "version": "2.0",
            "type": "preset",
            "preset_name": preset_name,
            "description": preset["描述"],
            "core_traits": preset["核心特质"]
        }
        
        # 计算衍生特质和进化状态
        personality['meta_traits'] = compute_meta_traits(personality)
        personality['evolution_state'] = update_evolution_state(personality)
        
        return personality
    
    # 默认人格（谨慎探索型）
    return initialize_personality(preset_name=DEFAULT_PERSONALITY)


# ============================================================================
# 命令行接口
# ============================================================================

def main():
    """命令行入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='AGI进化模型 - 映射层管理工具')
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # init 命令
    init_parser = subparsers.add_parser('init', help='初始化人格')
    init_parser.add_argument('--preset', help='预设人格名称')
    init_parser.add_argument('--custom', help='自定义人格JSON')
    
    # preset-list 命令
    subparsers.add_parser('preset-list', help='列出所有预设人格')
    
    # questionnaire 命令
    subparsers.add_parser('questionnaire', help='显示人格问卷')
    
    # update 命令
    update_parser = subparsers.add_parser('update', help='更新人格')
    update_parser.add_argument('--type', required=True, help='更新类型：growth/stability')
    update_parser.add_argument('--effectiveness', type=float, required=True, help='实效性得分 [0,1]')
    update_parser.add_argument('--detail', help='洞察详情')
    
    # feedback 命令
    feedback_parser = subparsers.add_parser('feedback', help='生成反馈')
    feedback_parser.add_argument('--immediacy', type=float, required=True, help='即时性得分 [0,1]')
    feedback_parser.add_argument('--effectiveness', type=float, required=True, help='实效性得分 [0,1]')
    
    # status 命令
    subparsers.add_parser('status', help='查看当前人格状态')
    
    args = parser.parse_args()
    
    if args.command == 'init':
        personality = initialize_personality(preset_name=args.preset)
        save_personality(personality)
        print(f"人格初始化成功：{personality.get('type', 'unknown')}")
        if args.preset:
            print(f"预设人格：{args.preset}")
        print(f"进化状态：{personality.get('evolution_state', {})}")
    
    elif args.command == 'preset-list':
        print("可用预设人格：")
        for name, preset in PRESET_PERSONALITIES.items():
            print(f"  - {name}: {preset['描述']}")
    
    elif args.command == 'questionnaire':
        print("人格问卷（5个维度）：")
        print("1. 开放性：您对新事物的接受程度如何？（0-10）")
        print("2. 尽责性：您的自律性和规划能力如何？（0-10）")
        print("3. 外向性：您的社交能量如何？（0-10）")
        print("4. 宜人性：您的合作性和同理心如何？（0-10）")
        print("5. 神经质：您的情绪稳定性如何？（0-10，0=非常稳定，10=容易焦虑）")
        print("\n马斯洛需求层次权重（0-10）：")
        for level in MASLOW_LEVELS:
            print(f"  - {level}")
    
    elif args.command == 'update':
        personality = load_personality()
        
        # 构造哲学洞察
        insight = {
            'type': args.type,
            'intensity': args.effectiveness,
            'philosophical_depth': 0.7 if args.effectiveness > 0.7 else 0.5,
            'maslow_alignment': 0.8 if args.effectiveness > 0.8 else 0.6,
            'content': args.detail or f"{args.type} update with effectiveness {args.effectiveness}"
        }
        
        # 更新人格
        updated = update_personality(insight, personality, [])
        save_personality(updated)
        
        print(f"人格更新成功")
        print(f"进化分数：{updated.get('evolution_state', {}).get('evolution_score', 0):.2f}")
        print(f"主导需求：{updated.get('evolution_state', {}).get('level', 'unknown')}")
    
    elif args.command == 'feedback':
        timeliness = compute_timeliness_feedback(0.5, 0.8, 0.6)
        effectiveness = compute_effectiveness_feedback(args.effectiveness, 0.3, 0.1)
        personality = load_personality()
        traits_used = ['openness', 'conscientiousness']
        
        feedback = generate_feedback_package(timeliness, effectiveness, personality, traits_used)
        print(json.dumps(feedback, indent=2, ensure_ascii=False))
    
    elif args.command == 'status':
        personality = load_personality()
        print(json.dumps(personality, indent=2, ensure_ascii=False))
    
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
