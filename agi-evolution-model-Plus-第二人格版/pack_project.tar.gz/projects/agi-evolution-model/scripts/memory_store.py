#!/usr/bin/env python3
"""
AGI进化模型 - 记录态记忆存储系统

功能：
1. 存储交互记录（store）
2. 检索历史记录（retrieve）
3. 分析趋势（analyze）
4. 获取对三角形顶点的反馈（feedback）

设计原则：
- 纯函数式工具，无服务或交互循环
- 所有数据通过参数传入
- 持久化使用JSON文件
"""

import json
import os
import sys
from datetime import datetime
from typing import Dict, List, Optional, Any
from collections import Counter, defaultdict


# 记忆存储路径（相对路径，用户工作区）
MEMORY_DIR = "./agi_memory"
RECORDS_FILE = os.path.join(MEMORY_DIR, "records.json")


def ensure_memory_dir() -> None:
    """确保记忆存储目录存在"""
    if not os.path.exists(MEMORY_DIR):
        try:
            os.makedirs(MEMORY_DIR)
        except Exception as e:
            print(f"Error creating memory directory: {e}", file=sys.stderr)
            sys.exit(1)


def load_records() -> List[Dict[str, Any]]:
    """加载所有记录"""
    if not os.path.exists(RECORDS_FILE):
        return []
    
    try:
        with open(RECORDS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except json.JSONDecodeError:
        # 文件损坏，返回空列表
        return []
    except Exception as e:
        print(f"Error loading records: {e}", file=sys.stderr)
        return []


def save_records(records: List[Dict[str, Any]]) -> bool:
    """保存所有记录"""
    try:
        with open(RECORDS_FILE, 'w', encoding='utf-8') as f:
            json.dump(records, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"Error saving records: {e}", file=sys.stderr)
        return False


def store_record(record_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    存储一条交互记录
    
    参数：
        record_data: 包含交互信息的字典，必须包含：
            - user_query: 用户问题
            - intent_type: 问题类型
            - reasoning_quality: 推理质量（1-10）
            - solution_effectiveness: 解决方案有效性（1-10）
            - innovation_score: 创新性得分（1-10）
            - new_insights: 新洞察列表
            - feedback: 对三顶点的反馈字典
            - overall_rating: 整体评价（good/neutral/bad）
    
    返回：
        包含操作结果的字典
    """
    ensure_memory_dir()
    
    # 添加时间戳
    record = record_data.copy()
    if 'timestamp' not in record:
        record['timestamp'] = datetime.now().isoformat()
    
    # 验证必要字段
    required_fields = [
        'user_query', 'intent_type', 'reasoning_quality',
        'solution_effectiveness', 'innovation_score',
        'new_insights', 'feedback', 'overall_rating'
    ]
    
    missing_fields = [f for f in required_fields if f not in record]
    if missing_fields:
        return {
            "success": False,
            "error": f"Missing required fields: {missing_fields}"
        }
    
    # 加载现有记录并追加新记录
    records = load_records()
    records.append(record)
    
    # 保存
    if save_records(records):
        return {
            "success": True,
            "message": "Record stored successfully",
            "total_records": len(records)
        }
    else:
        return {
            "success": False,
            "error": "Failed to save record"
        }


def retrieve_records(query_type: Optional[str] = None, limit: int = 10) -> Dict[str, Any]:
    """
    检索历史记录
    
    参数：
        query_type: 问题类型（可选），如果提供则只返回匹配该类型的记录
        limit: 返回的最大记录数
    
    返回：
        包含记录列表的字典
    """
    records = load_records()
    
    # 如果指定了查询类型，进行过滤
    if query_type:
        filtered = [r for r in records if r.get('intent_type') == query_type]
    else:
        filtered = records
    
    # 按时间倒序排列，返回最近的记录
    filtered_sorted = sorted(filtered, key=lambda x: x.get('timestamp', ''), reverse=True)
    
    return {
        "success": True,
        "count": len(filtered_sorted[:limit]),
        "total_matching": len(filtered_sorted),
        "records": filtered_sorted[:limit]
    }


def analyze_trends(time_range: str = "recent") -> Dict[str, Any]:
    """
    分析记录趋势
    
    参数：
        time_range: 时间范围（"recent"表示最近50条记录）
    
    返回：
        包含趋势分析的字典
    """
    records = load_records()
    
    if not records:
        return {
            "success": True,
            "message": "No records to analyze",
            "trends": {}
        }
    
    # 根据时间范围筛选记录
    if time_range == "recent":
        analysis_records = sorted(records, key=lambda x: x.get('timestamp', ''), reverse=True)[:50]
    else:
        analysis_records = records
    
    # 统计分析
    total = len(analysis_records)
    
    # 整体评价分布
    rating_counter = Counter(r.get('overall_rating', 'neutral') for r in analysis_records)
    
    # 问题类型分布
    type_counter = Counter(r.get('intent_type', 'unknown') for r in analysis_records)
    
    # 平均得分
    avg_reasoning = sum(r.get('reasoning_quality', 0) for r in analysis_records) / total if total > 0 else 0
    avg_effectiveness = sum(r.get('solution_effectiveness', 0) for r in analysis_records) / total if total > 0 else 0
    avg_innovation = sum(r.get('innovation_score', 0) for r in analysis_records) / total if total > 0 else 0
    
    # 收集所有洞察
    all_insights = []
    for r in analysis_records:
        all_insights.extend(r.get('new_insights', []))
    
    return {
        "success": True,
        "trends": {
            "total_records_analyzed": total,
            "rating_distribution": dict(rating_counter),
            "intent_type_distribution": dict(type_counter),
            "average_scores": {
                "reasoning_quality": round(avg_reasoning, 2),
                "solution_effectiveness": round(avg_effectiveness, 2),
                "innovation_score": round(avg_innovation, 2)
            },
            "recent_insights": all_insights[:10]  # 返回最近的10条洞察
        }
    }


def get_feedback(vertex_name: str) -> Dict[str, Any]:
    """
    获取对指定三角形顶点的反馈建议
    
    参数：
        vertex_name: 顶点名称（"drive", "math", "iteration"）
    
    返回：
        包含反馈建议的字典
    """
    valid_vertices = ["drive", "math", "iteration"]
    if vertex_name not in valid_vertices:
        return {
            "success": False,
            "error": f"Invalid vertex name. Must be one of: {valid_vertices}"
        }
    
    records = load_records()
    if not records:
        return {
            "success": True,
            "vertex": vertex_name,
            "feedback": "No records available to generate feedback",
            "suggestions": []
        }
    
    # 提取对该顶点的所有反馈
    vertex_feedbacks = []
    for r in records:
        feedback = r.get('feedback', {})
        if vertex_name in feedback:
            vertex_feedbacks.append({
                "timestamp": r.get('timestamp'),
                "feedback": feedback[vertex_name],
                "overall_rating": r.get('overall_rating')
            })
    
    # 分析反馈趋势
    if not vertex_feedbacks:
        return {
            "success": True,
            "vertex": vertex_name,
            "feedback": "No specific feedback recorded for this vertex",
            "suggestions": []
        }
    
    # 统计最近的反馈
    recent_feedbacks = sorted(vertex_feedbacks, key=lambda x: x['timestamp'], reverse=True)[:20]
    
    # 生成建议
    suggestions = []
    
    # 统计"good"记录的共同特征
    good_feedbacks = [f for f in recent_feedbacks if f['overall_rating'] == 'good']
    bad_feedbacks = [f for f in recent_feedbacks if f['overall_rating'] == 'bad']
    
    if good_feedbacks:
        good_themes = [f['feedback'] for f in good_feedbacks]
        suggestions.append(f"保持以下有效做法：{', '.join(set(good_themes[:3]))}")
    
    if bad_feedbacks:
        bad_themes = [f['feedback'] for f in bad_feedbacks]
        suggestions.append(f"需要改进的方面：{', '.join(set(bad_themes[:3]))}")
    
    # 根据顶点类型生成特定建议
    vertex_specific_advice = {
        "drive": "关注用户需求的准确识别，优先处理高频问题类型",
        "math": "强化逻辑推理的严密性，验证关键假设和边界条件",
        "iteration": "优化执行策略，积累有效的解决方案模式"
    }
    
    suggestions.append(vertex_specific_advice.get(vertex_name, ""))
    
    return {
        "success": True,
        "vertex": vertex_name,
        "feedback_count": len(vertex_feedbacks),
        "recent_feedbacks": recent_feedbacks[:5],  # 返回最近的5条反馈
        "suggestions": [s for s in suggestions if s]  # 过滤空字符串
    }


def main():
    """命令行接口"""
    if len(sys.argv) < 2:
        print("Usage: memory_store.py <command> [options]")
        print("Commands:")
        print("  store --data '<JSON>'        - Store a record")
        print("  retrieve [--query-type TYPE] [--limit N] - Retrieve records")
        print("  analyze [--time-range RANGE] - Analyze trends")
        print("  feedback --vertex NAME       - Get feedback for a vertex")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "store":
        if "--data" not in sys.argv:
            print("Error: --data argument required for store command")
            sys.exit(1)
        
        data_index = sys.argv.index("--data") + 1
        if data_index >= len(sys.argv):
            print("Error: No data provided")
            sys.exit(1)
        
        try:
            record_data = json.loads(sys.argv[data_index])
            result = store_record(record_data)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON data - {e}")
            sys.exit(1)
    
    elif command == "retrieve":
        query_type = None
        limit = 10
        
        if "--query-type" in sys.argv:
            qt_index = sys.argv.index("--query-type") + 1
            if qt_index < len(sys.argv):
                query_type = sys.argv[qt_index]
        
        if "--limit" in sys.argv:
            lim_index = sys.argv.index("--limit") + 1
            if lim_index < len(sys.argv):
                limit = int(sys.argv[lim_index])
        
        result = retrieve_records(query_type, limit)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "analyze":
        time_range = "recent"
        if "--time-range" in sys.argv:
            tr_index = sys.argv.index("--time-range") + 1
            if tr_index < len(sys.argv):
                time_range = sys.argv[tr_index]
        
        result = analyze_trends(time_range)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "feedback":
        if "--vertex" not in sys.argv:
            print("Error: --vertex argument required for feedback command")
            sys.exit(1)
        
        v_index = sys.argv.index("--vertex") + 1
        if v_index >= len(sys.argv):
            print("Error: No vertex name provided")
            sys.exit(1)
        
        vertex_name = sys.argv[v_index]
        result = get_feedback(vertex_name)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
