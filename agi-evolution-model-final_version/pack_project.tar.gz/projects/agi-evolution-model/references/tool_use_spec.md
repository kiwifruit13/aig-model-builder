# Tool Use 接口设计规范

## 目录
- [概览](#概览)
- [基础结构](#基础结构)
- [设计原则](#设计原则)
- [标准化输出格式](#标准化输出格式)
- [错误处理](#错误处理)
- [行业标准参考](#行业标准参考)
- [最佳实践](#最佳实践)
- [选型建议](#选型建议)
- [趋势与展望](#趋势与展望)
- [在感知节点中的应用](#在感知节点中的应用)

---

## 概览

Tool Use（工具调用）是连接智能体与外部世界的关键接口。本规范定义了感知节点使用的标准化接口，确保工具调用的可靠性和一致性。

### 核心价值

- **标准化**：统一接口格式，降低集成成本
- **可靠性**：参数校验、错误处理、重试策略
- **可扩展**：支持动态工具发现（MCP）
- **兼容性**：兼容主流 AI 平台的规范

---

## 基础结构

### 工具定义格式

```json
{
  "name": "get_current_weather",
  "description": "获取指定城市的实时天气信息",
  "parameters": {
    "type": "object",
    "properties": {
      "location": {
        "type": "string",
        "description": "城市名称，如 'Beijing' 或 'San Francisco, CA'"
      },
      "unit": {
        "type": "string",
        "enum": ["celsius", "fahrenheit"],
        "description": "温度单位"
      }
    },
    "required": ["location"],
    "additionalProperties": false
  },
  "strict": true
}
```

### 命名规范

- 使用英文小写+下划线（snake_case）
- 符合正则：`^[a-zA-Z_][a-zA-Z0-9_-]{0,63}$`
- 名称语义清晰，如 `search_product` 优于 `do_stuff`

### 描述撰写原则

| 要素 | 建议 | 示例 |
|------|------|------|
| 功能描述 | 一句话说明用途 | "查询股票实时价格" |
| 参数说明 | 标注类型、格式、取值范围 | "symbol: 股票代码，如 'AAPL'" |
| 边界条件 | 说明限制或异常场景 | "仅支持美股市场，数据延迟15分钟" |

---

## 设计原则

### 单一职责原则

**错误**（多功能聚合）：
```python
{
  "name": "query_service",
  "description": "可查天气、股票、新闻..."
}
```

**正确**（拆分为独立工具）：
- `get_weather(location)`
- `get_stock_price(symbol)`
- `search_news(keyword)`

### 幂等性设计

- 相同输入参数 → 相同输出结果
- 避免因网络重试导致重复执行副作用

### 参数校验前置

```python
def get_weather(location: str, unit: str = "celsius"):
    # 前置校验
    if not re.match(r'^[A-Za-z\s,]+$', location):
        return {"success": False, "error": "Invalid location format"}
    if unit not in ["celsius", "fahrenheit"]:
        return {"success": False, "error": "Invalid unit"}
    # 业务逻辑...
```

### Strict Mode

**关键配置**：`strict: true` + `additionalProperties: false`

```json
{
  "strict": true,
  "parameters": {
    "additionalProperties": false
  }
}
```

**重要性**：
- ✅ 100% Schema 合规保证
- ✅ 防止模型产生幻觉参数
- ✅ 生产环境标配（2026 年标准）

---

## 标准化输出格式

### 成功响应

```json
{
  "success": true,
  "status": "success",
  "data": {
    "temperature": 25,
    "condition": "sunny"
  },
  "metadata": {
    "tool_name": "get_weather",
    "execution_time_ms": 127,
    "timestamp": "2024-01-01T00:00:00Z"
  }
}
```

### 错误响应

```json
{
  "success": false,
  "status": "error",
  "error": {
    "code": "CITY_NOT_FOUND",
    "message": "城市'XYZ'未收录"
  },
  "metadata": {
    "tool_name": "get_weather",
    "timestamp": "2024-01-01T00:00:00Z"
  }
}
```

### 字段说明

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| success | bool | 是 | 操作是否成功 |
| status | string | 是 | 状态值：success/error |
| data | object | 条件 | 成功时的返回数据 |
| error | object | 条件 | 失败时的错误信息 |
| metadata | object | 是 | 元数据（工具名、时间、执行耗时） |

---

## 错误处理

### 错误类型

| 错误码 | 含义 | 处理建议 |
|--------|------|---------|
| INVALID_PARAMS | 参数验证失败 | 检查参数类型和格式 |
| RESOURCE_NOT_FOUND | 资源不存在 | 确认资源ID或路径 |
| PERMISSION_DENIED | 权限不足 | 检查授权 |
| TIMEOUT | 执行超时 | 重试或优化 |
| RATE_LIMITED | 超出速率限制 | 延迟后重试 |

### 重试策略

```python
# 重试规则
- 网络错误：最多重试3次
- 超时错误：最多重试2次
- 参数错误：不重试（立即返回）
- 权限错误：不重试（立即返回）
```

---

## 行业标准参考

### 主流规范对比（2026 年）

| 规范 | 主导方 | 核心特点 | 适用场景 | 采用率 |
|------|--------|----------|----------|--------|
| **OpenAI Function Calling** | OpenAI | JSON Schema + `strict` 模式 + 并行调用 | GPT 系列应用、兼容生态 | ⭐⭐⭐⭐⭐ |
| **Anthropic Tool Use** | Anthropic | `input_schema` + Client/Server Tools 分离 | Claude 应用、企业 Agent | ⭐⭐⭐⭐⭐ |
| **MCP (Model Context Protocol)** | Anthropic + 社区 | 开放协议 + 动态工具发现 + 解耦架构 | 跨平台 Agent、企业集成 | ⭐⭐⭐⭐ 📈 |

### OpenAI Function Calling（最成熟）

```json
{
  "type": "function",
  "function": {
    "name": "get_weather",
    "description": "Get weather by location",
    "parameters": {
      "type": "object",
      "properties": {
        "location": { "type": "string", "description": "City, Country" }
      },
      "required": ["location"],
      "additionalProperties": false
    },
    "strict": true  // 🔑 关键：开启严格模式保证 schema 合规
  }
}
```

**关键特性**：
- ✅ `strict: true` + `additionalProperties: false` = 100% schema 合规
- ✅ `parallel_tool_calls: false` 控制并发
- ✅ `tool_choice` 支持 `auto`/`required`/`{"name":"xxx"}` 三级控制

### Anthropic Tool Use（最灵活）

```json
{
  "name": "get_weather",
  "description": "Get weather by location",
  "input_schema": {  // ⚠️ 字段名与 OpenAI 不同
    "type": "object",
    "properties": {
      "location": { "type": "string" }
    },
    "required": ["location"]
  },
  "strict": true
}
```

**独特优势**：
- 🔹 **Client Tools**：自定义逻辑，模型返回 `tool_use` 后由应用执行
- 🔹 **Server Tools**：平台内置（如 `web_search_20250305`），无需实现
- 🔹 **MCP 原生兼容**：`inputSchema` → `input_schema` 一键转换

### MCP Protocol（增长最快 🚀）

```typescript
// MCP Server 工具定义（标准接口）
interface ToolDefinition {
  name: string;
  description?: string;
  inputSchema: Record<string, unknown>;  // JSON Schema
  annotations?: {
    title?: string;
    readOnlyHint?: boolean;     // 是否只读
    destructiveHint?: boolean;  // 是否有副作用
  };
}

// 客户端动态发现工具
{
  "method": "tools/list",
  "params": {}
}
// → 返回工具列表，支持热更新
```

**为什么 MCP 在爆发**：
| 优势 | 说明 |
|------|------|
| 🔌 **USB-C for AI** | 统一协议连接任意数据源/工具，无需重复开发 |
| 🔁 **动态注册** | 工具变更无需重启 Agent，支持企业级热部署 |
| 🔐 **权限隔离** | MCP Server 可独立控制访问权限，模型不直接接触敏感数据 |
| 🌐 **生态互通** | Claude、ChatGPT、开源模型均可通过 MCP Client 调用同一套工具 |

> 💡 截至 2026 Q1，MCP 已有 200+ 官方/社区 Server（Notion、Google Calendar、PostgreSQL、Figma 等）

---

## 最佳实践

### 1. Strict Mode 成为生产环境标配

```json
{
  "strict": true,
  "parameters": {
    "additionalProperties": false
  }
}
```

**原因**：
- 2026 年所有主流平台均推荐开启
- Schema 校验从"可选"变"必需"
- 防止模型产生幻觉参数

### 2. 参数校验最佳实践

```python
def validate_parameters(tool_name: str, params: dict, schema: dict) -> tuple[bool, str]:
    """
    参数校验最佳实践
    
    返回：
        (is_valid, error_message)
    """
    try:
        # 1. 检查必需参数
        required = schema.get('required', [])
        for param in required:
            if param not in params:
                return False, f"Missing required parameter: {param}"
        
        # 2. 检查参数类型
        properties = schema.get('properties', {})
        for param_name, param_value in params.items():
            if param_name in properties:
                param_schema = properties[param_name]
                expected_type = param_schema.get('type')
                
                # 类型校验
                if expected_type == 'string' and not isinstance(param_value, str):
                    return False, f"Parameter '{param_name}' must be string"
                elif expected_type == 'integer' and not isinstance(param_value, int):
                    return False, f"Parameter '{param_name}' must be integer"
                elif expected_type == 'number' and not isinstance(param_value, (int, float)):
                    return False, f"Parameter '{param_name}' must be number"
                
                # 枚举值校验
                if 'enum' in param_schema and param_value not in param_schema['enum']:
                    return False, f"Parameter '{param_name}' must be one of {param_schema['enum']}"
        
        # 3. 检查额外参数（if strict mode）
        if schema.get('strict') and schema.get('parameters', {}).get('additionalProperties', False) is False:
            for param_name in params:
                if param_name not in properties:
                    return False, f"Unexpected parameter: {param_name}"
        
        return True, ""
    
    except Exception as e:
        return False, f"Validation error: {str(e)}"
```

### 3. 错误处理最佳实践

```python
def call_tool_with_retry(tool_name: str, params: dict, max_retries: int = 3) -> dict:
    """
    带重试的工具调用
    
    重试策略：
    - 网络错误：最多重试 3 次
    - 超时错误：最多重试 2 次
    - 参数错误：不重试
    - 权限错误：不重试
    """
    retry_count = 0
    last_error = None
    
    while retry_count < max_retries:
        try:
            result = execute_tool(tool_name, params)
            
            # 检查是否需要重试
            if not result['success']:
                error_code = result.get('error', {}).get('code')
                
                # 参数错误和权限错误不重试
                if error_code in ['INVALID_PARAMS', 'PERMISSION_DENIED']:
                    return result
                
                # 超时错误最多重试 2 次
                if error_code == 'TIMEOUT' and retry_count >= 2:
                    return result
                
                # 其他错误继续重试
                last_error = result
                retry_count += 1
                time.sleep(2 ** retry_count)  # 指数退避
                continue
            
            return result
        
        except requests.exceptions.RequestException as e:
            # 网络错误重试
            last_error = {
                "success": False,
                "status": "error",
                "error": {
                    "code": "NETWORK_ERROR",
                    "message": str(e)
                }
            }
            retry_count += 1
            time.sleep(2 ** retry_count)
            continue
        
        except Exception as e:
            # 其他错误不重试
            return {
                "success": False,
                "status": "error",
                "error": {
                    "code": "UNKNOWN_ERROR",
                    "message": str(e)
                }
            }
    
    # 重试次数用尽
    return last_error
```

### 4. 动态工具发现（MCP 模式）

```python
class MCPToolRegistry:
    """MCP 工具注册表"""
    
    def __init__(self):
        self.tools = {}
        self.servers = {}
    
    async def register_server(self, server_url: str):
        """注册 MCP Server"""
        # 连接服务器
        response = await requests.post(
            f"{server_url}/tools/list",
            json={}
        )
        
        # 注册工具
        for tool in response.json()['tools']:
            self.tools[tool['name']] = tool
            self.servers[tool['name']] = server_url
    
    async def call_tool(self, tool_name: str, params: dict) -> dict:
        """调用 MCP 工具"""
        if tool_name not in self.tools:
            return {
                "success": False,
                "error": {
                    "code": "TOOL_NOT_FOUND",
                    "message": f"Tool '{tool_name}' not found"
                }
            }
        
        server_url = self.servers[tool_name]
        
        response = await requests.post(
            f"{server_url}/tools/call",
            json={
                "name": tool_name,
                "arguments": params
            }
        )
        
        return response.json()
```

---

## 选型建议

### 场景匹配

```mermaid
graph LR
    A[你的需求] --> B{目标模型?}
    B -->|GPT 系列| C[OpenAI Function Calling]
    B -->|Claude 系列| D[Anthropic Tool Use + MCP]
    B -->|多模型/开源| E[MCP 或自定义]
    
    A --> F{工具复杂度?}
    F -->|简单 API 调用| C
    F -->|动态工具/企业集成| E[MCP]
    F -->|RAG+ 工具| G[自定义集成]
    
    A --> H{开发语言?}
    H -->|Python| I[Python SDK]
    H -->|.NET| J[.NET SDK]
    H -->|任意| K[MCP + 自定义 Client]
```

### 快速选择指南

| 场景 | 推荐规范 | 原因 |
|------|---------|------|
| **GPT 应用** | OpenAI Function Calling | 原生支持，成熟稳定 |
| **Claude 应用** | Anthropic Tool Use + MCP | 灵活性高，生态丰富 |
| **跨平台 Agent** | MCP 协议 | 统一协议，未来兼容性最佳 |
| **企业级集成** | MCP + 自定义 Server | 动态工具发现，权限隔离 |
| **AGI 进化模型** | 自定义规范 + MCP 兼容 | 满足独特需求，保持兼容 |

### AGI 进化模型的适配

**当前规范特点**：
- ✅ 标准化输出格式（success/status/data/error/metadata）
- ✅ 统一的错误处理机制
- ✅ 参数校验前置
- ✅ 幂等性设计

**与主流规范的兼容性**：

| 特性 | 本规范 | OpenAI | Anthropic | MCP | 兼容性 |
|------|--------|--------|-----------|-----|--------|
| JSON Schema | ✅ | ✅ | ✅ | ✅ | 完全兼容 |
| Strict Mode | ⚠️ 建议添加 | ✅ | ✅ | ✅ | 可兼容 |
| Dynamic Discovery | ❌ | ❌ | ✅ | ✅ | 需扩展 |
| Client/Server | ❌ | ❌ | ✅ | ✅ | 需扩展 |

**建议**：
1. 保持当前标准化输出格式
2. 添加 `strict: true` 和 `additionalProperties: false`
3. 考虑添加 MCP Server 支持（可选）

---

## 趋势与展望

### 2026 年趋势预测

1. **MCP 将成为跨平台事实标准**  
   类似 OpenAPI 之于 REST，MCP 正在成为 AI Agent 的"工具接口标准"

2. **Strict Mode 成为生产环境标配**  
   所有主流平台均推荐开启 `strict: true`，schema 校验从"可选"变"必需"

3. **Custom Tools + CFG 崛起**  
   对非结构化输出场景（代码生成、创意写作），Lark/Regex 语法约束工具调用正在替代纯 JSON Schema

4. **工具编排层标准化**  
   框架正在抽象"工具调用策略"，未来可能出现 Tool Orchestration Spec

### 未来发展方向

1. **语义级工具发现**
   - 从"工具名称匹配"到"语义意图匹配"
   - 自动推荐最合适的工具

2. **工具组合编排**
   - 支持多工具协同工作流
   - 工具依赖关系管理

3. **自适应参数优化**
   - 基于历史数据优化参数
   - 自动补全默认值

4. **安全与权限增强**
   - 更细粒度的权限控制
   - 敏感操作确认机制

---

## 在感知节点中的应用

### 标准化接口

```python
class PerceptionNode:
    def call_tool(self, tool_name: str, parameters: dict) -> dict:
        """
        调用工具并返回标准化结果
        
        参数：
            tool_name: 工具名称
            parameters: 工具参数
        
        返回：
            标准化响应字典（包含success、status、data/error、metadata）
        """
        pass
```

### 无噪音输入

感知节点只接收结构化的工具调用结果，原始信号处理由工具本身完成：

**传统感知**（有噪音）：
```
摄像头输入 → 图像处理 → 物体识别 → 判断
```

**Tool Use感知**（无噪音）：
```
符号系统 → 调用 weather_tool(location='Beijing') 
→ 感知节点接收：{success: true, data: {temperature: 5}}
```

### 与数学顶点的协同

```
用户输入
    ↓
感知节点 → Tool Use → 工具调用
    ↓
数学顶点 → 逻辑推理 → 验证
    ↓
认知架构洞察 → 模式提取 → 洞察
    ↓
映射层 → 策略优化 → 行动
```

---

## 参考资料

| 规范 | 官方文档 | 示例代码库 |
|------|----------|-----------|
| OpenAI Functions | [platform.openai.com/docs](https://platform.openai.com/docs/guides/function-calling) | [openai/openai-cookbook](https://github.com/openai/openai-cookbook) |
| Anthropic Tools | [docs.anthropic.com](https://docs.anthropic.com/en/docs/tool-use) | [anthropics/anthropic-cookbook](https://github.com/anthropics/anthropic-cookbook) |
| MCP | [modelcontextprotocol.io](https://modelcontextprotocol.io) | [modelcontextprotocol/servers](https://github.com/modelcontextprotocol/servers) |

---

> 💡 **一句话总结**：  
> - 做 **GPT 应用** → 用 OpenAI Function Calling + `strict: true`  
> - 做 **Claude 应用** → 用 Anthropic Tool Use + 优先集成 MCP Server  
> - 做 **跨平台/企业级 Agent** → 直接采用 **MCP 协议**，未来兼容性最佳

---

**版本**: V2.0 | **更新日期**: 2026-03-05 | **协议**: AGPL-3.0
