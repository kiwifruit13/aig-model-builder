# Tool Use 接口设计规范

## 目录
- [基础结构](#基础结构)
- [设计原则](#设计原则)
- [标准化输出格式](#标准化输出格式)
- [错误处理](#错误处理)

---

## 概览

Tool Use（工具调用）是连接智能体与外部世界的关键接口。本规范定义了感知节点使用的标准化接口，确保工具调用的可靠性和一致性。

---

## 基础结构

### 工具定义格式

```json
{
  "name": "get_current_weather",
  "description": "获取指定城市的实时天气信息",
  "parameters": {
    "type": "object",
    "properties": {
      "location": {
        "type": "string",
        "description": "城市名称，如 'Beijing' 或 'San Francisco, CA'"
      },
      "unit": {
        "type": "string",
        "enum": ["celsius", "fahrenheit"],
        "description": "温度单位"
      }
    },
    "required": ["location"]
  }
}
```

### 命名规范

- 使用英文小写+下划线（snake_case）
- 符合正则：`^[a-zA-Z_][a-zA-Z0-9_-]{0,63}$`
- 名称语义清晰，如 `search_product` 优于 `do_stuff`

### 描述撰写原则

| 要素 | 建议 | 示例 |
|------|------|------|
| 功能描述 | 一句话说明用途 | "查询股票实时价格" |
| 参数说明 | 标注类型、格式、取值范围 | "symbol: 股票代码，如 'AAPL'" |
| 边界条件 | 说明限制或异常场景 | "仅支持美股市场，数据延迟15分钟" |

---

## 设计原则

### 单一职责原则

**错误**（多功能聚合）：
```python
{
  "name": "query_service",
  "description": "可查天气、股票、新闻..."
}
```

**正确**（拆分为独立工具）：
- `get_weather(location)`
- `get_stock_price(symbol)`
- `search_news(keyword)`

### 幂等性设计

- 相同输入参数 → 相同输出结果
- 避免因网络重试导致重复执行副作用

### 参数校验前置

```python
def get_weather(location: str, unit: str = "celsius"):
    # 前置校验
    if not re.match(r'^[A-Za-z\s,]+$', location):
        return {"success": False, "error": "Invalid location format"}
    if unit not in ["celsius", "fahrenheit"]:
        return {"success": False, "error": "Invalid unit"}
    # 业务逻辑...
```

---

## 标准化输出格式

### 成功响应

```json
{
  "success": true,
  "status": "success",
  "data": {
    "temperature": 25,
    "condition": "sunny"
  },
  "metadata": {
    "tool_name": "get_weather",
    "execution_time_ms": 127,
    "timestamp": "2024-01-01T00:00:00Z"
  }
}
```

### 错误响应

```json
{
  "success": false,
  "status": "error",
  "error": {
    "code": "CITY_NOT_FOUND",
    "message": "城市'XYZ'未收录"
  },
  "metadata": {
    "tool_name": "get_weather",
    "timestamp": "2024-01-01T00:00:00Z"
  }
}
```

### 字段说明

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| success | bool | 是 | 操作是否成功 |
| status | string | 是 | 状态值：success/error |
| data | object | 条件 | 成功时的返回数据 |
| error | object | 条件 | 失败时的错误信息 |
| metadata | object | 是 | 元数据（工具名、时间、执行耗时） |

---

## 错误处理

### 错误类型

| 错误码 | 含义 | 处理建议 |
|--------|------|---------|
| INVALID_PARAMS | 参数验证失败 | 检查参数类型和格式 |
| RESOURCE_NOT_FOUND | 资源不存在 | 确认资源ID或路径 |
| PERMISSION_DENIED | 权限不足 | 检查授权 |
| TIMEOUT | 执行超时 | 重试或优化 |
| RATE_LIMITED | 超出速率限制 | 延迟后重试 |

### 重试策略

```python
# 重试规则
- 网络错误：最多重试3次
- 超时错误：最多重试2次
- 参数错误：不重试（立即返回）
- 权限错误：不重试（立即返回）
```

---

## 在感知节点中的应用

### 标准化接口

```python
class PerceptionNode:
    def call_tool(self, tool_name: str, parameters: dict) -> dict:
        """
        调用工具并返回标准化结果
        
        参数：
            tool_name: 工具名称
            parameters: 工具参数
        
        返回：
            标准化响应字典（包含success、status、data/error、metadata）
        """
        pass
```

### 无噪音输入

感知节点只接收结构化的工具调用结果，原始信号处理由工具本身完成：

**传统感知**（有噪音）：
```
摄像头输入 → 图像处理 → 物体识别 → 判断
```

**Tool Use感知**（无噪音）：
```
符号系统 → 调用 weather_tool(location='Beijing') 
→ 感知节点接收：{success: true, data: {temperature: 5}}
```

---

## 注意事项

- 所有工具必须返回结构化数据（非原始文本）
- 每次调用都应记录执行时间（execution_time_ms）
- 敏感操作（删除、修改）需要二次确认
- 工具内部必须有参数校验和异常处理
