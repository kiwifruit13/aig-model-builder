# 人格初始化优化版使用指南

## 概览

优化版人格初始化脚本合并了简化版和最终版的优点：
- ✅ 快速检测（<1ms）
- ✅ 无状态文件依赖
- ✅ 快速响应，无卡顿感
- ✅ 统一生成参数
- ✅ 原子性写入
- ✅ 格式与参考文档一致

## 核心特性

### 1. 快速检测机制
- 内存缓存（TTL=60秒）
- 文件存在性检测
- 检测速度 <1ms

### 2. 快速响应
- 每个问题立即返回
- 无状态文件读写延迟
- 智能体控制流程

### 3. 统一生成
- 所有回答收集后一次性生成
- 原子性写入防止数据损坏
- 数据结构完整

### 4. 跨平台兼容
- 纯Python标准库
- 无平台依赖
- Windows/Linux/macOS通用

## 使用流程

### 检测首次交互

```bash
python3 scripts/init_dialogue_optimized.py --check --memory-dir ./agi_memory
```

返回值：
- `is_first_interaction: True` - 需要初始化
- `is_first_interaction: False` - 已初始化

### 显示欢迎消息

```bash
python3 scripts/init_dialogue_optimized.py --welcome --memory-dir ./agi_memory
```

输出：
```
Hello! 亲爱的用户，由于这是我与世界的第一次交互，你是希望我采用默认人格还是自定义设置呢？本消息只在首次使用时出现。

1. 默认人格
2. 自定义人格

（30秒无响应将自动选择默认人格）
```

### 逐个询问问题

**询问用户称呼**（智能体自己问，不需要脚本）：
```
太好了！在开始之前，我想先知道你希望如何称呼我？
（例如：塔斯、贾维斯、伊迪斯、AI伙伴、或者其他你喜欢的名字）
（30秒无响应将使用默认称呼'塔斯'）
```

**问题1**：
```bash
python3 scripts/init_dialogue_optimized.py --question 0 --nickname "塔斯" --memory-dir ./agi_memory
```

输出：
```
谢谢你，塔斯在这里！现在让我了解一下你希望我偏好什么样的性格。

第一个问题：当你面临一个未知的挑战时，你的第一反应通常是？
A. 先了解清楚所有信息，然后谨慎决策
B. 愿意尝试，在行动中学习调整
C. 寻找折中方案，平衡风险和机会

（请回复 A、B 或 C，或者用你自己的话描述）
（30秒无响应将使用默认回答）
```

**问题2-5**：
```bash
python3 scripts/init_dialogue_optimized.py --question 1 --memory-dir ./agi_memory
python3 scripts/init_dialogue_optimized.py --question 2 --memory-dir ./agi_memory
python3 scripts/init_dialogue_optimized.py --question 3 --memory-dir ./agi_memory
python3 scripts/init_dialogue_optimized.py --question 4 --memory-dir ./agi_memory
```

### 使用默认人格

```bash
python3 scripts/init_dialogue_optimized.py \
  --default \
  --nickname "塔斯" \
  --memory-dir ./agi_memory
```

输出：
```
已为您初始化默认人格（谨慎探索型）。

太好了！我会根据你的选择和对话创建了专属的人格配置。

**你选择的称呼**: 塔斯
**核心特质**: 谨慎、可靠、愿意学习
**人格类型**: 谨慎探索型
**描述**: 在保证安全的前提下，愿意尝试新事物

从现在开始，我将以这个人格与你持续互动。在未来的交互中，我会根据我们的共同经历不断学习和进化。

现在，我们可以开始第一次正式对话了！你有什么想和我聊的吗？

STATUS: personality_generated=True
```

### 使用自定义人格（依据用户的选择依次对应生成）

比如：

```bash
python3 scripts/init_dialogue_optimized.py \
  --custom \
  --nickname "扣子" \
  --answers "B,B,B,A,C" \
  --memory-dir ./agi_memory
```

输出：
```
太好了！我会根据你的选择和对话创建专属的人格配置。

**你选择的称呼**: 扣子
**核心特质**: 乐于创新
**人格类型**: 激进创新型
**描述**: 基于您的偏好生成的个性化人格，特点是乐于创新

从现在开始，我将以这个人格与你持续互动。在未来的交互中，我会根据我们的共同经历不断学习和进化。

现在，我们可以开始第一次正式对话了！你有什么想和我聊的吗？

STATUS: personality_generated=True
```

## 智能体工作流程

### 标准流程

1. **检测首次交互**：
   ```python
   result = run_command("python3 scripts/init_dialogue_optimized.py --check")
   # 如果返回 is_first_interaction: True，进入初始化流程
   ```

2. **显示欢迎消息**：
   ```python
   result = run_command("python3 scripts/init_dialogue_optimized.py --welcome")
   # 直接返回结果给用户
   ```

3. **收集用户选择**：
   - 如果用户选择默认人格：调用 `--default`
   - 如果用户选择自定义人格：进入问题流程

4. **自定义人格流程**：
   - 询问称呼（智能体自己问）
   - 逐个调用 `--question 0` 到 `--question 4`
   - 收集所有回答到列表

5. **依次对应生成参数**：
   ```python
   answers = ["B", "B", "B", "A", "C"]  # 收集的所有回答
   result = run_command(f"python3 scripts/init_dialogue_optimized.py --custom --nickname '扣子' --answers '{','.join(answers)}'")
   ```

6. **进入正常交互**：人格初始化完成

### 超时处理

**原则**：超时处理由智能体控制

**处理方式**：
- 30秒无响应：智能体使用默认选项
- 自定义人格中某个问题超时：智能体使用默认回答（A）
- 称呼超时：智能体使用默认称呼"塔斯"

## 命令行参数

| 参数 | 说明 | 示例 |
|------|------|------|
| `--check` | 检查是否为首次交互 | `--check` |
| `--welcome` | 获取欢迎消息 | `--welcome` |
| `--question` | 获取指定索引的问题（0-4） | `--question 0` |
| `--default` | 使用默认人格 | `--default` |
| `--custom` | 使用自定义人格 | `--custom` |
| `--nickname` | 用户称呼 | `--nickname "塔斯"` |
| `--answers` | 5个问题的回答，用逗号分隔 | `--answers "A,B,C,A,B"` |
| `--memory-dir` | 记忆存储目录 | `--memory-dir ./agi_memory` |

## 性能特点

### 快速响应
- 检测首次交互：<1ms
- 获取欢迎消息：<1ms
- 获取问题：<1ms
- 生成人格参数：<10ms
- 保存人格参数：<50ms

### 无卡顿感
- 每个问题立即返回
- 无状态文件读写延迟
- 智能体控制流程节奏

### 安全可靠
- 原子性写入防止数据损坏
- 内存缓存提高性能
- 异常处理完善

## 与其他版本对比

| 特性 | 简化版 | 最终版 | 优化版 |
|------|--------|--------|--------|
| 快速检测 | ❌ | ✅ 三层缓存 | ✅ 内存缓存 |
| 快速响应 | ✅ | ✅ | ✅ |
| 统一生成 | ✅ | ✅ | ✅ |
| 原子写入 | ❌ | ✅ | ✅ |
| 状态文件 | ❌ | ✅ | ❌ |
| 跨平台 | ✅ | ❌（fcntl） | ✅ |
| 格式一致 | ✅ | ❌ | ✅ |
| 智能体控制 | ✅ | 中 | ✅ |
| 代码量 | 300行 | 972行 | 500行 |

## 常见问题

### Q1: 为什么没有状态文件？
A: 为了提高响应速度和简化复杂度，由智能体控制流程。智能体知道当前问到第几个问题。

### Q2: 如何处理超时？
A: 由智能体控制。30秒无响应时，智能体使用默认选项继续流程。

### Q3: 为什么使用原子写入？
A: 防止数据损坏。使用临时文件 + 重命名确保写入过程原子性。

### Q4: 如何保证快速响应？
A: 
- 内存缓存减少文件检测时间
- 无状态文件减少读写延迟
- 每个问题立即返回，不阻塞

### Q5: 与参考文档的格式一致吗？
A: 是的，欢迎消息和问题格式与参考文档001.txt完全一致。

## 输出文件

初始化完成后，会创建以下文件：

- `./agi_memory/personality.json` - 人格配置文件

## 数据结构

### 默认人格（谨慎探索型）

```json
{
  "big_five": {
    "openness": 0.6,
    "conscientiousness": 0.8,
    "extraversion": 0.4,
    "agreeableness": 0.6,
    "neuroticism": 0.5
  },
  "maslow_weights": {
    "physiological": 0.35,
    "safety": 0.35,
    "belonging": 0.1,
    "esteem": 0.1,
    "self_actualization": 0.08,
    "self_transcendence": 0.02
  },
  "meta_traits": {
    "adaptability": 0.42,
    "resilience": 0.605,
    "curiosity": 0.46,
    "moral_sense": 0.486
  },
  "evolution_state": {
    "level": "physiological",
    "evolution_score": 0.0,
    "phase": "growth"
  },
  "version": "2.0",
  "type": "preset",
  "preset_name": "谨慎探索型",
  "description": "在保证安全的前提下，愿意尝试新事物",
  "core_traits": ["谨慎", "可靠", "愿意学习"],
  "last_updated": "2024-02-22T...",
  "update_source": "default_init",
  "user_nickname": "塔斯",
  "initialized": true,
  "initialization_time": "2024-02-22T..."
}
```

### 自定义人格

```json
{
  "big_five": { ... },
  "maslow_weights": { ... },
  "meta_traits": { ... },
  "evolution_state": { ... },
  "version": "2.0",
  "type": "custom",
  "preset_name": "激进创新型",
  "description": "基于您的偏好生成的个性化人格，特点是乐于创新",
  "core_traits": ["乐于创新"],
  "last_updated": "2024-02-22T...",
  "update_source": "dialogue_init",
  "user_nickname": "塔斯",
  "initialized": true,
  "initialization_time": "2024-02-22T...",
  "customization": {
    "q1": "B",
    "q2": "B",
    "q3": "B",
    "q4": "A",
    "q5": "C"
  }
}
```

## 总结

优化版方案合并了简化版和最终版的优点：
- ✅ 快速响应（<1ms）
- ✅ 无卡顿感
- ✅ 统一生成
- ✅ 原子写入
- ✅ 格式一致
- ✅ 跨平台兼容
- ✅ 智能体控制权高

适用于需要快速响应、高可靠性、跨平台部署的场景。
