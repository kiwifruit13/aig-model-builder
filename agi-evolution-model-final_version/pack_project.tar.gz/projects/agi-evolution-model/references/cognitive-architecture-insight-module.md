# 认知架构洞察模块 (Cognitive Architecture Insight Module V2)

## 1. 模块概览

**认知架构洞察模块 V2**是 AGI 进化模型的核心创新组件，隶属于**数学节点工具箱**。它填补了"数学验证"与"架构进化"之间的关键空白，负责从数学顶点输出的**已验证结构化模式**中提取深度洞察，为映射层（策略优化）和自我迭代顶点（架构升级）提供进化依据。

### 1.1 核心定位
*   **归属**：数学节点工具箱 (Math Node Toolbox)。
*   **触发时机**：数学顶点推理完成并输出结构化模式后。
*   **执行方式**：异步运行，不打断主循环，维持系统实时性。
*   **核心价值**：将"数据"转化为"智慧"，实现从"术"（技巧）到"法"（法则）再到"道"（原理）的认知跃迁。

### 1.2 V2 版本新增能力
1.  **概念提炼**：从模式中抽象出概念，实现四层抽象架构（Pattern → Rule → Concept → Principle）
2.  **TF-IDF 加权提取**：使用 TF-IDF 算法智能提取关键词和概念特征
3.  **动态迁移学习**：基于历史迁移数据学习最优迁移路径
4.  **增强验证机制**：支持用户反馈和 A/B 测试
5.  **性能优化**：LRU 缓存、增量更新、索引优化

### 1.3 设计原则
1.  **单向流约束**：信息流严格遵循 `数学顶点 → 认知架构洞察 → 映射层/自我迭代`，**严禁回流**至数学节点，确保因果律不被破坏。
2.  **推理后运行**：仅处理经过数学节点验证的逻辑结构，确保洞察基于真理而非幻觉。
3.  **超然性**：仅提供建议和优化依据，不直接强制执行，最终决策权在映射层或自我迭代顶点。
4.  **非侵入式**：独立于主循环三角形之外，作为旁路分支存在。

---

## 2. 核心功能详解

本模块通过六大核心算法流程，将原始模式转化为可执行的进化策略。

### 2.1 总结 (Summarization)
**目标**：从验证后的模式中提取核心特征和本质描述，去粗取精。
*   **输入**：数学顶点输出的原始结构化模式列表。
*   **处理流程**：
    1.  **去重与聚类**：识别重复模式，按语义相似度聚类。
    2.  **分组统计**：按模式类型（strategy/logic/behavior/error）分组。
    3.  **特征提取**：计算每组的平均验证得分、出现频率、来源分布。
    4.  **抽象生成**：生成自然语言或结构化摘要。
    5.  **置信度计算**：基于数据量和一致性计算总结的可信度。
*   **输出示例**：
    ```json
    {
      "summary": "发现 strategy 类型模式 3 个，平均验证得分 0.92，累计出现 25 次",
      "core_features": {
        "strategy": {"count": 3, "avg_validation": 0.92, "total_occurrences": 25}
      },
      "confidence": 0.92
    }
    ```

### 2.2 分类 (Classification)
**目标**：识别模式类型和洞察类型，明确其作用域。
*   **分类维度**：
    *   **模式类型**：`strategy` (策略), `logic` (逻辑), `behavior` (行为), `error` (错误)。
    *   **洞察类型（V2 优化）**：
        - `error_correction`（错误纠正）- 最高优先级
        - `architecture_upgrade`（架构升级）- 系统级影响
        - `concept_abstraction`（概念提炼）- V2 新增，需要多样性>0.6且验证分数>0.75
        - `strategy_optimization`（策略优化）- 兜底选项
    *   **影响范围**：`local` (局部), `global` (全局)。
    *   **紧急程度**：`low`, `medium`, `high`。
*   **输出示例**：
    ```json
    {
      "pattern_types": ["strategy"],
      "insight_type": "strategy_optimization",
      "impact_scope": "local",
      "urgency": "medium",
      "classification_confidence": 0.8
    }
    ```

### 2.3 共性 (Commonality)
**目标**：识别跨场景、跨时间的共同特征，发现普适规律。
*   **处理流程**：
    1.  **属性提取**：提取每个模式的关键属性向量。
    2.  **相似度计算**：构建属性相似度矩阵。
    3.  **聚类分析**：将相似模式聚类，提取类内共性。
    4.  **全局识别**：识别跨越所有聚类的全局共性（Global Commonality）。
    5.  **多样性评分**：计算模式的多样性得分（越低表示共性越强）。
*   **输出示例**：
    ```json
    {
      "global_commonality": {
        "all_from_same_source": true,
        "all_same_type": true
      },
      "diversity_score": 0.3
    }
    ```

### 2.4 革新依据 (Innovation Basis)
**目标**：判断是否存在值得进行架构革新或策略调整的坚实依据。
*   **评估维度**：
    1.  **新颖性**：是否为新发现的模式？
    2.  **频率**：模式出现的频率是否足够高？
    3.  **稳定性**：模式在不同场景下是否一致？
    4.  **影响力**：模式对系统性能的影响深度。
    5.  **改进潜力**：基于此模式进行改进的预期收益。
*   **判断规则**：
    *   存在革新依据条件：`avg_validation > 0.7` 且 `total_occurrences > 10`。
*   **输出示例**：
    ```json
    {
      "exists": true,
      "description": "发现高频高置信度模式，建议优化 strategy_optimization",
      "priority": 0.92,
      "expected_impact": {"scope": "local"}
    }
    ```

### 2.5 概念提炼 (Concept Abstraction) ⭐ V2 新增
**目标**：从模式中抽象出概念，实现从"术"到"道"的认知跃迁。
*   **四层抽象架构**：
    ```
    Pattern (具体模式)
        ↓ 归纳
    Rule (行为规则)
        ↓ 抽象
    Concept (领域概念)
        ↓ 升华
    Principle (通用原理)
    ```
*   **提取流程（TF-IDF 加权）**：
    1.  **提取共同语义特征**：使用 TF-IDF 算法提取高频关键词
    2.  **识别抽象层级**：
        - `rule`: 单一领域，具体行为
        - `concept`: 跨领域，中等抽象
        - `principle`: 跨领域 + 通用术语，高度抽象
    3.  **生成概念定义**：基于 TF-IDF 关键词组合
    4.  **识别适用边界**：适用领域列表、边界条件提取
    5.  **识别迁移路径**：基于动态学习系统定义目标领域
    6.  **计算置信度**：验证分数均值(50%) + 多样性(30%) + 样本充足性(20%)
*   **输出示例**：
    ```json
    {
      "concept_name": "分治原则",
      "definition": "将复杂问题分解为多个子问题，分别解决后合并结果",
      "abstraction_level": "principle",
      "applicable_domains": ["算法设计", "系统架构", "项目管理"],
      "boundary_conditions": ["当问题规模较大时", "当子问题相互独立时"],
      "migration_paths": [
        {
          "from": "代码生成",
          "to_targets": "数据分析",
          "confidence": 0.85,
          "total_attempts": 12,
          "is_learned": true
        }
      ],
      "confidence": 0.87,
      "extraction_method": "tfidf"
    }
    ```

### 2.6 适用性评估 (Applicability)
**目标**：评估洞察在当前具体场景下的可用性和推荐等级。
*   **评估维度及权重**：
    *   **时效性 (20%)**：洞察是否过时？
    *   **相关性 (30%)**：与当前任务/状态的相关性？
    *   **兼容性 (20%)**：与现有架构/人格的兼容性？
    *   **资源效率 (15%)**：实施该洞察的资源消耗？
    *   **风险 (15%)**：应用该洞察的潜在风险？
    *   **概念匹配 (V2 新增)**：如果是概念抽象，额外评估抽象层级匹配度（占30%，基础70%）
*   **推荐规则**：
    *   `score ≥ 0.7` → **推荐应用 (apply)**
    *   `0.4 ≤ score < 0.7` → **暂缓等待 (wait)**
    *   `score < 0.4` → **拒绝应用 (reject)**
*   **输出示例**：
    ```json
    {
      "score": 0.78,
      "dimensions": {
        "timeliness": 0.85,
        "relevance": 0.80,
        "compatibility": 0.95,
        "resource_efficiency": 0.70,
        "risk": 0.75,
        "concept_match": 0.85
      },
      "recommendation": "apply"
    }
    ```

---

## 3. 信息流方向约束

本模块严格遵守架构的单向流原则，任何违反以下约束的行为都被视为严重错误。

### 3.1 合法信息流
| 起点 | 终点 | 数据类型 | 方向 | 说明 |
| :--- | :--- | :--- | :--- | :--- |
| **数学顶点** | **认知架构洞察** | 验证后的结构化模式 | **单向** | 输入源，必须是经过验证的数据 |
| **认知架构洞察** | **模式存储** | 模式数据 (patterns.json) | **单向** | 持久化存储 |
| **认知架构洞察** | **洞察存储** | 洞察数据 (insights.json) | **单向** | 持久化存储 |
| **认知架构洞察** | **概念库** | 概念数据 (concept_library.json) | **单向** | V2 新增，概念持久化 |
| **认知架构洞察** | **映射层** | 策略优化洞察、行为建议、概念 | **单向** | 指导人格化决策 |
| **认知架构洞察** | **自我迭代顶点** | 架构升级洞察、进化方向 | **单向** | 指导系统进化 |

### 3.2 禁止信息流 (Critical Constraints)
| 起点 | 终点 | 禁止原因 |
| :--- | :--- | :--- |
| **认知架构洞察** | **数学顶点** | ❌ **严禁回流**。防止未经验证的洞察污染逻辑推理，破坏因果律。 |
| **映射层** | **认知架构洞察** | ❌ 禁止反向指令。洞察模块只输出建议，不接受映射层的直接控制。 |
| **自我迭代** | **认知架构洞察** | ❌ 禁止反向指令。进化执行结果应记录在案，供下一次洞察使用，而非直接干预洞察过程。 |

---

## 4. 概念边界约束

为确保模块职责清晰，必须遵守以下边界：

1.  **不参与实时推理**：本模块仅处理历史或刚完成的模式数据，**严禁**介入当前的用户请求推理过程。
2.  **不直接执行动作**：本模块只生成"洞察报告"和"建议"，**严禁**直接调用工具、修改人格参数或更新系统代码。执行权属于映射层和自我迭代顶点。
3.  **不处理原始输入**：输入必须是经过数学节点处理后的**结构化模式**，不能直接处理用户的原始自然语言输入。
4.  **不存储临时会话数据**：仅存储具有长期价值的模式和洞察，临时会话数据应由记录层管理。

---

## 5. 数据存储规范

所有数据和洞察均存储在 `agi_memory/cognitive_insight/` 目录下。

### 5.1 文件结构
```text
agi_memory/
└── cognitive_insight/
    ├── patterns.json          # 原始模式数据池
    ├── insights.json          # 生成的洞察报告库
    ├── pattern_library.json   # 经筛选的高价值模式库
    └── concept_library.json   # V2 新增，概念库
```

### 5.2 洞察数据格式标准
每条洞察记录必须包含以下字段：
```json
{
  "insight_id": "insight_abc123",
  "timestamp": "2025-02-22T10:30:00Z",
  "insight_type": "strategy_optimization",
  "summary": "...",                 // 来自功能 2.1
  "commonality": {...},             // 来自功能 2.3
  "innovation_basis": {...},        // 来自功能 2.4
  "applicability": {...},           // 来自功能 2.6
  "confidence": 0.85,               // 综合置信度
  "source_patterns": ["pattern_xxx"], // 溯源
  "version": "2.0",                 // V2 新增
  "concept": {...}                  // V2 新增，如果是概念抽象类型
}
```

### 5.3 概念库数据格式（V2 新增）
```json
{
  "concepts": [
    {
      "concept_id": "concept_abc123",
      "source_insight_id": "insight_xyz789",
      "concept": {
        "concept_name": "分治原则",
        "definition": "...",
        "abstraction_level": "principle"
      },
      "validation_count": 3,
      "applicability_history": [],
      "user_feedback": [],           // V2 新增
      "ab_test_results": [],         // V2 新增
      "created_at": "2026-03-03T10:30:00Z",
      "last_validated_at": "2026-03-03T15:00:00Z",
      "is_incremental": true         // V2 新增
    }
  ],
  "principles": [
    {
      "principle_id": "concept_abc123",
      "principle_name": "分治原则",
      "definition": "..."
    }
  ],
  "migration_history": {},           // V2 新增，迁移路径学习数据
  "metadata": {
    "total_count": 5,
    "last_updated": "2026-03-03T15:00:00Z",
    "version": "2.0"
  }
}
```

---

## 6. V2 新增核心组件

### 6.1 TF-IDF 计算器 (TFIDFCalculator)
**功能**：使用 TF-IDF 算法智能提取关键词
- **TF (Term Frequency)**：词频，衡量词在文档中的重要性
- **IDF (Inverse Document Frequency)**：逆文档频率，衡量词在整个语料库中的稀有程度
- **关键词提取**：按 TF-IDF 分数排序提取 top-k 关键词

### 6.2 概念缓存 (ConceptCache)
**功能**：LRU (Least Recently Used) 缓存优化
- **容量限制**：默认缓存 100 个概念
- **命中统计**：记录缓存命中率
- **自动淘汰**：缓存满时淘汰最久未使用的概念

### 6.3 迁移路径学习器 (MigrationPathLearner)
**功能**：基于历史数据动态学习最优迁移路径
- **迁移记录**：记录每次迁移的成功/失败
- **置信度更新**：使用指数加权移动平均动态调整置信度
- **路径排序**：按学习到的置信度排序迁移路径

### 6.4 概念提取扩展 (ConceptExtractionExtension)
**功能**：概念提取、库管理、评估的核心模块
- **extract_concept**：使用 TF-IDF 提取概念
- **add_concept_to_library**：添加概念到库（支持去重）
- **record_user_feedback**：记录用户反馈
- **record_ab_test_result**：记录 A/B 测试结果
- **record_migration_result**：记录迁移结果

---

## 7. 模块脑图 (Mermaid)

```mermaid
mindmap
  root((认知架构洞察模块 V2))
    核心功能
      总结 Summarization
      分类 Classification
      共性 Commonality
      革新依据 Innovation Basis
      概念提炼 Concept Abstraction
      适用性评估 Applicability
    V2 新增能力
      四层抽象
        Pattern
        Rule
        Concept
        Principle
      TF-IDF 加权提取
      动态迁移学习
      增强验证机制
      性能优化
    数据存储
      patterns.json
      insights.json
      pattern_library.json
      concept_library.json
    核心组件
      TFIDFCalculator
      ConceptCache
      MigrationPathLearner
      ConceptExtractionExtension
    信息流约束
      合法流
        数学顶点→洞察
        洞察→映射层/自我迭代
      禁止流
        洞察→数学顶点
        映射层/自我迭代→洞察
```

---

## 8. 使用示例

### 8.1 基本使用

```python
from cognitive_insight import CognitiveInsight

# 初始化
ci = CognitiveInsight(memory_dir="./agi_memory")

# 添加模式
ci.add_pattern({
    "pattern_id": "pattern_001",
    "pattern_type": "strategy",
    "description": "在代码生成任务中，先分析需求再生成代码",
    "validation_score": 0.95,
    "domain": "代码生成",
    "occurrence_count": 15
})

# 生成洞察
insight = ci.generate_insight(["pattern_001", "pattern_002", "pattern_003"])

# 查看洞察类型
print(f"洞察类型: {insight['insight_type']}")

# 如果是概念抽象，查看概念数据
if insight.get('insight_type') == 'concept_abstraction':
    concept = insight['concept']
    print(f"概念名称: {concept['concept_name']}")
    print(f"抽象层级: {concept['abstraction_level']}")
```

### 8.2 记录用户反馈

```python
# 记录用户对概念的反馈
ci.record_user_feedback(insight_id="insight_abc123", feedback={
    'rating': 5,
    'comment': '这个概念很有用，帮助我理解了问题的本质',
    'scenario': '系统设计'
})
```

### 8.3 记录迁移结果

```python
# 记录概念迁移的成功/失败
ci.record_migration_result(
    from_domain="代码生成",
    to_domain="数据分析",
    success=True
)
```

### 8.4 获取系统统计

```python
# 获取系统统计信息
stats = ci.get_system_stats()
print(f"模式数量: {stats['patterns_count']}")
print(f"洞察数量: {stats['insights_count']}")
print(f"缓存命中率: {stats['cache_stats']['hit_rate']:.2%}")
print(f"迁移学习统计: {stats['learning_stats']}")
```

---

## 9. 版本说明

- **V1.0**：基础版本，包含总结、分类、共性、革新依据、适用性评估
- **V2.0**：增强版本，新增概念提炼、TF-IDF 加权、动态迁移学习、缓存优化、增强验证机制

**迁移指南**：
- V1 版本已备份为 `cognitive_insight_backup.py`
- V2 版本完全向后兼容 V1 的数据格式
- 可以直接升级，无需迁移数据
