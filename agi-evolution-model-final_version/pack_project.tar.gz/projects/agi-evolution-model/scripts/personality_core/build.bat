@echo off
REM C 扩展编译脚本（Windows）
REM 用途：快速编译 personality_core.so
REM 协议：AGPL-3.0

echo ======================================
echo   AGI Evolution Model - C Extension
echo   Build Script (Windows)
echo   License: AGPL-3.0
echo ======================================
echo.

REM 进入 personality_core 目录
cd /d "%~dp0"

echo 当前目录: %cd%
echo.

REM 检查 Python 版本
python --version

REM 检查编译器
echo.
echo 检查编译器...
where cl.exe >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] MSVC 编译器可用
) else (
    echo [ERROR] 未找到 MSVC 编译器
    echo.
    echo 请安装 Visual Studio Build Tools:
    echo https://visualstudio.microsoft.com/visual-cpp-build-tools/
    echo.
    echo 或从开始菜单打开 "Developer Command Prompt for VS"
    pause
    exit /b 1
)

REM 编译 C 扩展
echo.
echo ======================================
echo 开始编译 C 扩展...
echo ======================================
python setup.py build_ext --inplace

REM 检查编译产物
echo.
echo 编译产物:
echo.
dir *.so 2>nul || dir *.pyd 2>nul || echo 未找到编译产物

REM 重命名为主文件名（如果需要）
if exist *.cp*.pyd (
    echo.
    echo 重命名为主文件名（Windows）...
    copy *.cp*.pyd personality_core.so >nul
    echo [OK] 已创建 personality_core.so
)

REM 清理临时文件
echo.
echo 清理临时文件...
if exist build rmdir /s /q build
echo [OK] 已清理 build 目录

REM 测试 C 扩展
echo.
echo ======================================
echo 测试 C 扩展...
echo ======================================
python -c "import personality_core; print('[OK] C 扩展加载成功'); print('[OK] 可用函数:', ', '.join([name for name in dir(personality_core) if not name.startswith('_')]))"

echo.
echo ======================================
echo [OK] 编译完成！
echo ======================================
echo.
echo 编译产物:
dir personality_core.*
echo.
echo 下一步：
echo   1. 将 personality_core.so 复制到 Skill 的 scripts\personality_core\ 目录
echo   2. 重新打包 Skill
echo.
pause
