# C Extension Build Instructions

## Overview

Build `personality_core.so` for local development and custom platforms.

## Prerequisites

### Linux
```bash
sudo apt-get install build-essential  # Ubuntu/Debian
# or
sudo yum install gcc make             # CentOS/RHEL
```

### macOS
```bash
xcode-select --install
```

### Windows
Install [Visual Studio C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/)

## Build Steps

### 1. Navigate to source directory
```bash
cd scripts/personality_core
```

### 2. Compile
```bash
python3 setup.py build_ext --inplace
```

### 3. Rename output
```bash
# Linux/macOS
cp personality_core.cpython-*-*.so personality_core.so

# Windows
copy personality_core.cp*.pyd personality_core.so
```

## Supported Platforms

| Platform | Architecture | Status |
|----------|-------------|--------|
| Linux | x86_64 | ✅ Tested |
| Linux | ARM64 | ✅ Should work |
| macOS | x86_64 | ✅ Should work |
| macOS | ARM64 (Apple Silicon) | ✅ Should work |
| Windows | x86_64 | ✅ Should work |
| Windows | ARM64 | ⚠️ Untested |

## Troubleshooting

### "command 'gcc' not found"
Install build tools for your platform (see Prerequisites)

### "error: Python.h: No such file or directory"
Install Python development headers:
```bash
# Ubuntu/Debian
sudo apt-get install python3-dev

# CentOS/RHEL
sudo yum install python3-devel

# macOS
brew install python3
```

### "wrong ELF class"
Architecture mismatch (32-bit vs 64-bit). Recompile with correct architecture.

## Advanced Options

### Optimization Level
Edit `setup.py` to change `-O3` to:
- `-O0` - No optimization (debug)
- `-O1` - Basic optimization
- `-O2` - Recommended optimization
- `-O3` - Maximum optimization

### Native Architecture
Edit `setup.py` to remove `-march=native` for better compatibility.

## Verification

```bash
cd scripts
python3 -c "
import personality_core
print('✓ C extension loaded')
print('Functions:', [x for x in dir(personality_core) if not x.startswith('_')])
"
```
