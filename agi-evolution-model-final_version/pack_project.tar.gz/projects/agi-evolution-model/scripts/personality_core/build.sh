#!/bin/bash
# C 扩展编译脚本（Linux/macOS）
# 用途：快速编译 personality_core.so
# 协议：AGPL-3.0

set -e

echo "======================================"
echo "  AGI Evolution Model - C Extension"
echo "  Build Script (Linux/macOS)"
echo "  License: AGPL-3.0"
echo "======================================"
echo ""

# 进入 personality_core 目录
cd "$(dirname "$0")"

echo "当前目录: $(pwd)"
echo ""

# 检查 Python 版本
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python 版本: $PYTHON_VERSION"

# 检查编译器
echo ""
echo "检查编译器..."
if command -v gcc &> /dev/null; then
    GCC_VERSION=$(gcc --version | head -n1)
    echo "✓ GCC: $GCC_VERSION"
elif command -v clang &> /dev/null; then
    CLANG_VERSION=$(clang --version | head -n1)
    echo "✓ Clang: $CLANG_VERSION"
else
    echo "✗ 未找到编译器"
    echo "请安装编译工具："
    echo "  Ubuntu/Debian: sudo apt-get install build-essential"
    echo "  CentOS/RHEL: sudo yum install gcc make"
    echo "  macOS: xcode-select --install"
    exit 1
fi

# 检查 Python 开发头文件
echo ""
echo "检查 Python 开发头文件..."
if python3 -c "import sysconfig; print(sysconfig.get_path('include'))" &> /dev/null; then
    echo "✓ Python 开发头文件可用"
else
    echo "✗ Python 开发头文件不可用"
    echo "请安装 Python 开发包："
    echo "  Ubuntu/Debian: sudo apt-get install python3-dev"
    echo "  CentOS/RHEL: sudo yum install python3-devel"
    exit 1
fi

# 编译 C 扩展
echo ""
echo "======================================"
echo "开始编译 C 扩展..."
echo "======================================"
python3 setup.py build_ext --inplace

# 检查编译产物
echo ""
echo "编译产物:"
echo ""
ls -lh *.so 2>/dev/null || ls -lh *.pyd 2>/dev/null || echo "未找到编译产物"

# 重命名为主文件名（如果需要）
if ls *.cpython-*.so 1> /dev/null 2>&1; then
    echo ""
    echo "重命名为主文件名..."
    cp *.cpython-*.so personality_core.so
    echo "✓ 已创建 personality_core.so"
fi

if ls *.cp*.pyd 1> /dev/null 2>&1; then
    echo ""
    echo "重命名为主文件名（Windows）..."
    cp *.cp*.pyd personality_core.so
    echo "✓ 已创建 personality_core.so"
fi

# 清理临时文件
echo ""
echo "清理临时文件..."
rm -rf build/
echo "✓ 已清理 build 目录"

# 测试 C 扩展
echo ""
echo "======================================"
echo "测试 C 扩展..."
echo "======================================"
python3 -c "
import sys
import os

# 测试导入
try:
    import personality_core
    print('✓ C 扩展加载成功')
    print(f'✓ 模块文件: {personality_core.__file__}')
    print()
    print('可用的函数:')
    for name in dir(personality_core):
        if not name.startswith('_'):
            obj = getattr(personality_core, name)
            print(f'  - {name}: {type(obj).__name__}')
    print()
    
    # 简单功能测试
    weights = [0.35, 0.35, 0.1, 0.1, 0.08, 0.02]
    normalized = personality_core.normalize_weights(weights)
    print(f'功能测试: 归一化 {weights} -> 总和={sum(normalized):.6f}')
    if abs(sum(normalized) - 1.0) < 1e-6:
        print('✓ 功能测试通过')
    else:
        print('✗ 功能测试失败')
        sys.exit(1)
        
except ImportError as e:
    print(f'✗ C 扩展加载失败: {e}')
    sys.exit(1)
except Exception as e:
    print(f'✗ 测试失败: {e}')
    import traceback
    traceback.print_exc()
    sys.exit(1)
"

echo ""
echo "======================================"
echo "✓ 编译完成！"
echo "======================================"
echo ""
echo "编译产物:"
ls -lh personality_core.*
echo ""
echo "下一步："
echo "  1. 将 personality_core.so 复制到 Skill 的 scripts/personality_core/ 目录"
echo "  2. 重新打包 Skill"
echo ""
