# Personality Core C Extension

## 概述

`personality_core.so` 是 AGI 进化模型的核心算法 C 扩展，提供高性能的人格计算功能。

## 功能

1. **normalize_weights**: 马斯洛权重归一化
2. **calculate_similarity**: 大五人格相似度计算
3. **compute_maslow_priority**: 马斯洛优先级计算
4. **compute_all_scores**: 批量优先级计算

## 编译

### Linux / macOS

```bash
cd scripts/personality_core
python3 setup.py build_ext --inplace
```

### 使用 pip 安装

```bash
cd scripts/personality_core
pip install -e .
```

### Windows

需要 Visual Studio C++ 编译器：

```cmd
cd scripts\personality_core
python setup.py build_ext --inplace
```

## 编译产物

编译成功后会生成对应平台的二进制文件：

| 平台 | 文件名 |
|------|--------|
| Linux x64 | `personality_core.cpython-38-x86_64-linux-gnu.so` |
| macOS x64 | `personality_core.cpython-38-darwin.so` |
| macOS ARM64 | `personality_core.cpython-38-darwin.so` |
| Windows x64 | `personality_core.cp38-win_amd64.pyd` |

为了兼容性，需要将生成的文件重命名为 `personality_core.so`：

```bash
# Linux/macOS
cp personality_core.*.so personality_core.so

# Windows
copy personality_core.*.pyd personality_core.so
```

## 使用示例

```python
import personality_core

# 归一化权重
weights = [0.35, 0.35, 0.1, 0.1, 0.08, 0.02]
normalized = personality_core.normalize_weights(weights)
print(normalized)  # [0.35, 0.35, 0.1, 0.1, 0.08, 0.02]

# 计算相似度
trait1 = [0.6, 0.8, 0.4, 0.6, 0.5]
trait2 = [0.5, 0.7, 0.5, 0.6, 0.4]
similarity = personality_core.calculate_similarity(trait1, trait2)
print(similarity)  # 0.918...

# 计算优先级
maslow = [0.35, 0.35, 0.1, 0.1, 0.08, 0.02]
intent = [0.2, 0.3, 0.15, 0.15, 0.1, 0.1]
priority = personality_core.compute_maslow_priority(maslow, intent)
print(priority)  # 0.2445...
```

## 性能对比

| 操作 | 纯Python | C扩展 | 提升 |
|------|----------|-------|------|
| 权重归一化 | ~0.1ms | ~0.005ms | **20倍** |
| 相似度计算 | ~0.5ms | ~0.02ms | **25倍** |
| 批量计算(100) | ~50ms | ~2ms | **25倍** |

## 降级机制

如果 C 扩展加载失败，Python 模块会自动降级到纯 Python 实现：

```python
try:
    import personality_core
    USE_C_EXT = True
except ImportError:
    USE_C_EXT = False
    # 使用纯 Python 实现的回退函数
```

## 故障排查

### ImportError: No module named 'personality_core'

- 确保已编译 C 扩展
- 检查 `personality_core.so` 文件是否在 `scripts/` 目录下
- 确认平台匹配（例如 Linux x64 的 .so 不能在 macOS 上运行）

### 编译错误

**Linux**: 安装 build-essential
```bash
sudo apt-get install build-essential
```

**macOS**: 安装 Xcode Command Line Tools
```bash
xcode-select --install
```

**Windows**: 安装 Visual Studio Build Tools
```
https://visualstudio.microsoft.com/visual-cpp-build-tools/
```

## 平台支持

当前支持以下平台：

- ✅ Linux x64 (glibc)
- ✅ Linux x64 (musl)
- ✅ macOS x64 (Intel)
- ✅ macOS ARM64 (Apple Silicon)
- ✅ Windows x64

其他平台（如 ARM Linux）需要手动编译。
