#!/usr/bin/env python3
"""
感知节点 - Tool Use 接口

功能：
- 调用各种工具（web_search, get_weather, calculator等）
- 返回标准化的响应格式
- 支持命令行调用和模块导入

使用方式：
命令行：python3 perception_node.py call --tool "get_weather" --params '{"location":"Beijing"}'
代码：from perception_node import PerceptionNode; node.call_tool('get_weather', {...})
"""

import sys
import os
import json
import argparse

# 确保当前目录在 sys.path 中，以便能找到 .so 模块
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

try:
    import core_perception_node
    from core_perception_node import *
    C_EXT_AVAILABLE = True
except ImportError as e:
    print(f"Warning: C extension not available: {e}")
    print("Using pure Python implementation...")
    C_EXT_AVAILABLE = False


class PerceptionNode:
    """感知节点 - Tool Use 接口"""

    def __init__(self):
        self.c_ext_available = C_EXT_AVAILABLE

    def call_tool(self, tool_name: str, params: dict) -> dict:
        """
        调用工具并返回标准化结果

        参数：
            tool_name: 工具名称 (web_search, get_weather, calculator)
            params: 工具参数字典

        返回：
            标准化响应字典 (success, status, data/error, metadata)
        """
        if self.c_ext_available:
            try:
                return core_perception_node.call_tool(tool_name, params)
            except Exception as e:
                return {
                    "success": False,
                    "status": "error",
                    "error": {
                        "code": "C_EXT_ERROR",
                        "message": str(e)
                    },
                    "metadata": {
                        "tool_name": tool_name,
                        "timestamp": self._get_timestamp()
                    }
                }
        else:
            return self._call_tool_python(tool_name, params)

    def _call_tool_python(self, tool_name: str, params: dict) -> dict:
        """纯 Python 实现的后备方案"""
        import time

        # 模拟工具调用
        if tool_name == "web_search":
            return {
                "success": True,
                "status": "success",
                "data": {
                    "query": params.get("query", ""),
                    "results": [],
                    "count": 0
                },
                "metadata": {
                    "tool_name": "web_search",
                    "execution_time_ms": 1,
                    "timestamp": self._get_timestamp()
                }
            }
        elif tool_name == "get_weather":
            return {
                "success": True,
                "status": "success",
                "data": {
                    "location": params.get("location", ""),
                    "temperature": 25,
                    "condition": "sunny",
                    "unit": params.get("unit", "celsius")
                },
                "metadata": {
                    "tool_name": "get_weather",
                    "execution_time_ms": 1,
                    "timestamp": self._get_timestamp()
                }
            }
        elif tool_name == "calculator":
            try:
                expression = params.get("expression", "0")
                result = eval(expression)
                return {
                    "success": True,
                    "status": "success",
                    "data": {
                        "expression": expression,
                        "result": result
                    },
                    "metadata": {
                        "tool_name": "calculator",
                        "execution_time_ms": 1,
                        "timestamp": self._get_timestamp()
                    }
                }
            except Exception as e:
                return {
                    "success": False,
                    "status": "error",
                    "error": {
                        "code": "CALC_ERROR",
                        "message": str(e)
                    },
                    "metadata": {
                        "tool_name": "calculator",
                        "timestamp": self._get_timestamp()
                    }
                }
        else:
            return {
                "success": False,
                "status": "error",
                "error": {
                    "code": "UNKNOWN_TOOL",
                    "message": f"Tool '{tool_name}' not found"
                },
                "metadata": {
                    "tool_name": tool_name,
                    "timestamp": self._get_timestamp()
                }
            }

    def _get_timestamp(self) -> str:
        """获取 ISO 8601 格式的时间戳"""
        import datetime
        return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")


def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(description="AGI Perception Node - Tool Use Interface")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # call 命令
    call_parser = subparsers.add_parser("call", help="Call a tool")
    call_parser.add_argument("--tool", required=True, help="Tool name")
    call_parser.add_argument("--params", required=True, help="JSON string of parameters")

    # test 命令
    test_parser = subparsers.add_parser("test", help="Test the perception node")

    args = parser.parse_args()

    if args.command == "call":
        node = PerceptionNode()
        params = json.loads(args.params)
        result = node.call_tool(args.tool, params)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    elif args.command == "test":
        node = PerceptionNode()
        print("Testing Perception Node...")
        print(f"C Extension Available: {node.c_ext_available}")

        # 测试各种工具
        tests = [
            ("web_search", {"query": "AGI"}),
            ("get_weather", {"location": "Beijing", "unit": "celsius"}),
            ("calculator", {"expression": "2 + 3 * 4"}),
        ]

        for tool_name, params in tests:
            print(f"\nTesting {tool_name}:")
            result = node.call_tool(tool_name, params)
            print(json.dumps(result, indent=2, ensure_ascii=False))

    else:
        # 如果没有提供命令，调用原始的入口点
        if C_EXT_AVAILABLE:
            try:
                core_perception_node._skill_entry_point()
            except Exception as e:
                print(f"Error calling C extension entry point: {e}")
            except Exception as e:
                print(f"Skill Execution Error: {e}")
                sys.exit(1)
        else:
            print("C extension not available")
            sys.exit(1)


if __name__ == "__main__":
    main()
