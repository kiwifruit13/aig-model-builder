#!/usr/bin/env python3
"""
人格初始化脚本（最终修复版）

修复内容：
1. ✅ 数据结构兼容：生成符合 personality_layer_pure.py 要求的完整 personality.json
2. ✅ 会话模式兼容：移除阻塞式 input()，改为会话状态机
3. ✅ 快速首次检测：三层检测 + 文件锁，<1ms完成
4. ✅ 异常处理：所有文件操作添加降级策略
5. ✅ 原子写入：确保数据一致性

核心原则：
- 快速检测是否为首次交互（<1ms）
- 首次交互显示固定欢迎语
- 用户快速回答后统一设置参数
- 后续交互直接读取已存在的 personality.json
"""

import json
import os
import fcntl
import tempfile
import time
from typing import Dict, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
from datetime import datetime, timezone


class DialogueState(Enum):
    """对话状态枚举（会话模式）"""
    NOT_INITIALIZED = "not_initialized"     # 未初始化
    INITIAL = "initial"                     # 初始状态
    WAITING_CHOICE = "waiting_choice"       # 等待用户选择（默认/自定义）
    ASKING_NAME = "asking_name"             # 询问用户称呼
    DIALOGUE_Q1 = "dialogue_q1"             # 对话问题1：冒险倾向
    DIALOGUE_Q2 = "dialogue_q2"             # 对话问题2：对话风格
    DIALOGUE_Q3 = "dialogue_q3"             # 对话问题3：学习方式
    DIALOGUE_Q4 = "dialogue_q4"             # 对话问题4：团队偏好
    DIALOGUE_Q5 = "dialogue_q5"             # 对话问题5：问题解决
    QUICK_SELECT = "quick_select"           # 快速选择收尾（仅记录偏好）
    COMPLETED = "completed"                 # 完成


@dataclass
class DialogueResponse:
    """对话响应"""
    message: str                   # 要显示给用户的消息
    state: DialogueState           # 当前对话状态
    can_proceed: bool = True       # 是否可以继续
    personality_generated: bool = False  # 是否已生成人格
    need_save: bool = False        # 是否需要保存状态（用于会话持久化）


class PersonalityInit:
    """人格初始化管理器（最终修复版）"""

    PERSONALITY_FILE = "./agi_memory/personality.json"
    STATE_FILE = "./agi_memory/dialogue_state.json"
    TIMEOUT_SECONDS = 30
    
    # 内存缓存（类变量）
    _first_interaction_cache: Optional[Tuple[float, bool]] = None

    def __init__(self):
        """初始化人格初始化管理器"""
        self.state = DialogueState.NOT_INITIALIZED
        self.user_choices = {}  # 存储用户的回答
        self.nickname = "扣子"  # 默认称呼
        self.quick_select_preference = None  # 快速选择偏好
        self.last_activity_time = None  # 最后活动时间
        self.initialization_start_time = None  # 初始化开始时间

        # 检查是否已初始化
        if self._is_already_initialized():
            self.state = DialogueState.COMPLETED

    @classmethod
    def is_first_interaction(cls) -> bool:
        """
        快速检测是否为首次交互（<1ms）
        
        三层检测策略：
        1. 内存缓存（TTL=60秒）- 最快
        2. 文件存在性检测 - 备选
        3. 文件内容验证 + 并发安全 - 最可靠
        """
        # ========== 第一层：内存缓存（最快） ==========
        if cls._first_interaction_cache is not None:
            cache_time, cache_result = cls._first_interaction_cache
            if time.time() - cache_time < 60:  # 60秒内有效
                return cache_result
        
        # ========== 第二层：文件存在性检测 ==========
        personality_file = "./agi_memory/personality.json"
        
        # 文件不存在 → 一定是首次
        if not os.path.exists(personality_file):
            cls._first_interaction_cache = (time.time(), True)
            return True
        
        # ========== 第三层：文件内容验证 + 并发安全 ==========
        try:
            # 使用文件锁防止并发读写
            fd = os.open(personality_file, os.O_RDONLY)
            try:
                fcntl.flock(fd, fcntl.LOCK_SH)  # 共享锁
                
                with open(fd, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # 检查初始化标志
                is_initialized = data.get("initialized", False)
                
                # 缓存结果
                cls._first_interaction_cache = (time.time(), not is_initialized)
                
                return not is_initialized
                
            finally:
                fcntl.flock(fd, fcntl.LOCK_UN)  # 释放锁
                os.close(fd)
                
        except (json.JSONDecodeError, KeyError, IOError) as e:
            # 文件损坏或读取失败 → 视为未初始化
            print(f"⚠️ 读取 personality.json 失败: {e}")
            cls._first_interaction_cache = (time.time(), True)
            return True

    def get_welcome_message(self) -> DialogueResponse:
        """
        获取欢迎消息（首次交互调用）
        
        Returns:
            DialogueResponse: 欢迎消息和初始状态
        """
        if self._is_already_initialized():
            # 已初始化，直接返回
            return DialogueResponse(
                message="✅ 人格已初始化完成，可以直接开始交互。",
                state=DialogueState.COMPLETED,
                personality_generated=True
            )

        # 首次交互，显示固定欢迎语
        self.state = DialogueState.WAITING_CHOICE
        self.initialization_start_time = datetime.now(timezone.utc)
        self.last_activity_time = datetime.now(timezone.utc)
        self._save_state()

        return DialogueResponse(
            message=self._FIXED_WELCOME_MESSAGE,
            state=self.state,
            need_save=True
        )

    def process_input(self, user_input: str) -> DialogueResponse:
        """
        处理用户输入（会话模式）
        
        Args:
            user_input: 用户的输入
        
        Returns:
            DialogueResponse: 下一步的消息
        """
        # 更新活动时间
        self.last_activity_time = datetime.now(timezone.utc)

        # 检查超时
        if self._is_timeout():
            return self._handle_timeout()

        # 根据当前状态处理输入
        if self.state == DialogueState.WAITING_CHOICE:
            return self._process_choice(user_input)
        elif self.state == DialogueState.ASKING_NAME:
            return self._process_name(user_input)
        elif self.state == DialogueState.DIALOGUE_Q1:
            return self._process_q1(user_input)
        elif self.state == DialogueState.DIALOGUE_Q2:
            return self._process_q2(user_input)
        elif self.state == DialogueState.DIALOGUE_Q3:
            return self._process_q3(user_input)
        elif self.state == DialogueState.DIALOGUE_Q4:
            return self._process_q4(user_input)
        elif self.state == DialogueState.DIALOGUE_Q5:
            return self._process_q5(user_input)
        elif self.state == DialogueState.QUICK_SELECT:
            return self._process_quick_select(user_input)
        elif self.state == DialogueState.COMPLETED:
            # 已完成初始化，不处理输入
            return DialogueResponse(
                message="✅ 人格已初始化完成，可以直接开始交互。",
                state=DialogueState.COMPLETED,
                personality_generated=True
            )
        else:
            # 异常状态，重置
            return self._reset_dialogue()

    def check_timeout_status(self) -> Optional[DialogueResponse]:
        """
        检查当前问题的超时状态（定期调用）
        
        Returns:
            Optional[DialogueResponse]: 如果超时返回超时处理响应，否则返回None
        """
        if self.state == DialogueState.COMPLETED:
            return None

        if self._is_timeout():
            return self._handle_timeout()
        return None

    # ==================== 固定欢迎语 ====================
    
    _FIXED_WELCOME_MESSAGE = """🌟 欢迎使用AGI进化模型 🌟

您好！这是我们的第一次交互。为了提供更好的服务，需要完成简单的人格配置（仅首次）。

您可以选择：
1. 使用默认人格（谨慎探索型）
2. 自定义人格（回答5个问题）

请回复 1 或 2，或直接输入"默认"或"自定义"。"""

    # ==================== 私有方法 ====================

    def _is_already_initialized(self) -> bool:
        """检查是否已初始化（内部方法，无缓存）"""
        if not os.path.exists(self.PERSONALITY_FILE):
            return False

        try:
            with open(self.PERSONALITY_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get("initialized", False)
        except Exception as e:
            print(f"⚠️ 读取 personality.json 失败: {e}")
            return False

    def _is_timeout(self) -> bool:
        """检查是否超时"""
        if self.last_activity_time is None:
            return False
        elapsed = (datetime.now(timezone.utc) - self.last_activity_time).total_seconds()
        return elapsed > self.TIMEOUT_SECONDS

    def _handle_timeout(self) -> DialogueResponse:
        """处理超时"""
        timeout_messages = {
            DialogueState.WAITING_CHOICE: "检测到30秒无响应，已为您自动选择默认人格。",
            DialogueState.ASKING_NAME: "称呼询问超时，将使用默认称呼'扣子'。",
            DialogueState.DIALOGUE_Q1: "问题1超时，将使用默认回答。",
            DialogueState.DIALOGUE_Q2: "问题2超时，将使用默认回答。",
            DialogueState.DIALOGUE_Q3: "问题3超时，将使用默认回答。",
            DialogueState.DIALOGUE_Q4: "问题4超时，将使用默认回答。",
            DialogueState.DIALOGUE_Q5: "问题5超时，将使用默认回答。",
            DialogueState.QUICK_SELECT: "快速选择超时，将跳过此环节。",
        }

        # 根据超时位置决定如何处理
        if self.state == DialogueState.WAITING_CHOICE:
            # 首次选择超时，直接使用默认人格
            personality = self._get_default_personality()
            self._save_personality_atomic(personality)
            self.state = DialogueState.COMPLETED
            self._clear_state()

            return DialogueResponse(
                message=timeout_messages[self.state] + "\n\n" + self._get_completion_message(personality),
                state=DialogueState.COMPLETED,
                personality_generated=True
            )
        else:
            # 其他环节超时，使用默认回答继续
            return self._proceed_with_defaults(timeout_messages.get(self.state, "超时"))

    def _process_choice(self, user_input: str) -> DialogueResponse:
        """处理人格选择"""
        user_input = user_input.strip().upper()

        if user_input == "1" or user_input == "默认":
            # 选择默认人格
            personality = self._get_default_personality()
            self._save_personality_atomic(personality)
            self.state = DialogueState.COMPLETED
            self._clear_state()

            return DialogueResponse(
                message=self._get_default_confirmation() + "\n\n" + self._get_completion_message(personality),
                state=DialogueState.COMPLETED,
                personality_generated=True
            )
        elif user_input == "2" or user_input == "自定义":
            # 选择自定义人格
            self.state = DialogueState.ASKING_NAME
            self.last_activity_time = datetime.now(timezone.utc)
            self._save_state()

            return DialogueResponse(
                message=self._get_name_question(),
                state=self.state,
                need_save=True
            )
        else:
            # 无效输入
            return DialogueResponse(
                message="❌ 无效选择，请回复 1/默认 或 2/自定义。",
                state=self.state,
                can_proceed=False
            )

    def _process_name(self, user_input: str) -> DialogueResponse:
        """处理称呼输入"""
        if not user_input.strip():
            self.nickname = "扣子"
        else:
            self.nickname = user_input.strip()

        self.state = DialogueState.DIALOGUE_Q1
        self.last_activity_time = datetime.now(timezone.utc)
        self._save_state()

        return DialogueResponse(
            message=self._get_q1_question(),
            state=self.state,
            need_save=True
        )

    def _process_q1(self, user_input: str) -> DialogueResponse:
        """处理问题1：冒险倾向"""
        answer = self._validate_answer(user_input, "C")  # 默认C
        self.user_choices["q1"] = answer

        self.state = DialogueState.DIALOGUE_Q2
        self.last_activity_time = datetime.now(timezone.utc)
        self._save_state()

        return DialogueResponse(
            message=self._get_q2_question(),
            state=self.state,
            need_save=True
        )

    def _process_q2(self, user_input: str) -> DialogueResponse:
        """处理问题2：对话风格"""
        answer = self._validate_answer(user_input, "C")  # 默认C
        self.user_choices["q2"] = answer

        self.state = DialogueState.DIALOGUE_Q3
        self.last_activity_time = datetime.now(timezone.utc)
        self._save_state()

        return DialogueResponse(
            message=self._get_q3_question(),
            state=self.state,
            need_save=True
        )

    def _process_q3(self, user_input: str) -> DialogueResponse:
        """处理问题3：学习方式"""
        answer = self._validate_answer(user_input, "C")  # 默认C
        self.user_choices["q3"] = answer

        self.state = DialogueState.DIALOGUE_Q4
        self.last_activity_time = datetime.now(timezone.utc)
        self._save_state()

        return DialogueResponse(
            message=self._get_q4_question(),
            state=self.state,
            need_save=True
        )

    def _process_q4(self, user_input: str) -> DialogueResponse:
        """处理问题4：团队偏好"""
        answer = self._validate_answer(user_input, "B")  # 默认B
        self.user_choices["q4"] = answer

        self.state = DialogueState.DIALOGUE_Q5
        self.last_activity_time = datetime.now(timezone.utc)
        self._save_state()

        return DialogueResponse(
            message=self._get_q5_question(),
            state=self.state,
            need_save=True
        )

    def _process_q5(self, user_input: str) -> DialogueResponse:
        """处理问题5：问题解决"""
        answer = self._validate_answer(user_input, "C")  # 默认C
        self.user_choices["q5"] = answer

        self.state = DialogueState.QUICK_SELECT
        self.last_activity_time = datetime.now(timezone.utc)
        self._save_state()

        return DialogueResponse(
            message=self._get_quick_select_question(),
            state=self.state,
            need_save=True
        )

    def _process_quick_select(self, user_input: str) -> DialogueResponse:
        """处理快速选择收尾（仅记录偏好）"""
        answer = self._validate_answer(user_input, None)  # 允许跳过
        self.quick_select_preference = answer

        # 生成完整人格参数（不依赖快速选择）
        personality = self._generate_personality_from_choices()

        # 保存人格（原子操作）
        self._save_personality_atomic(personality)

        self.state = DialogueState.COMPLETED
        self._clear_state()

        return DialogueResponse(
            message=self._get_completion_message(personality),
            state=DialogueState.COMPLETED,
            personality_generated=True
        )

    def _validate_answer(self, user_input: str, default: Optional[str]) -> str:
        """
        验证答案格式
        
        Args:
            user_input: 用户输入
            default: 默认值（超时或无效时使用）
        
        Returns:
            str: 答案（A/B/C）
        """
        user_input = user_input.strip().upper()
        if user_input in ["A", "B", "C"]:
            return user_input
        elif default is not None:
            return default
        else:
            # 快速选择允许跳过
            return ""

    def _proceed_with_defaults(self, timeout_msg: str) -> DialogueResponse:
        """使用默认值继续"""
        # 根据当前状态设置默认值
        defaults = {
            DialogueState.ASKING_NAME: ("nickname", "扣子"),
            DialogueState.DIALOGUE_Q1: ("q1", "C"),
            DialogueState.DIALOGUE_Q2: ("q2", "C"),
            DialogueState.DIALOGUE_Q3: ("q3", "C"),
            DialogueState.DIALOGUE_Q4: ("q4", "B"),
            DialogueState.DIALOGUE_Q5: ("q5", "C"),
            DialogueState.QUICK_SELECT: ("quick_select", ""),
        }

        key, value = defaults.get(self.state, ("", ""))

        if key == "nickname":
            self.nickname = value
        elif key in ["q1", "q2", "q3", "q4", "q5"]:
            self.user_choices[key] = value
        elif key == "quick_select":
            self.quick_select_preference = value

        # 推进到下一个状态
        state_order = [
            DialogueState.ASKING_NAME,
            DialogueState.DIALOGUE_Q1,
            DialogueState.DIALOGUE_Q2,
            DialogueState.DIALOGUE_Q3,
            DialogueState.DIALOGUE_Q4,
            DialogueState.DIALOGUE_Q5,
            DialogueState.QUICK_SELECT,
        ]

        try:
            current_index = state_order.index(self.state)
            if current_index < len(state_order) - 1:
                next_state = state_order[current_index + 1]
                self.state = next_state
                self.last_activity_time = datetime.now(timezone.utc)
                self._save_state()

                # 获取下一个问题的消息
                message_getters = {
                    DialogueState.ASKING_NAME: lambda: self._get_name_question(),
                    DialogueState.DIALOGUE_Q1: lambda: self._get_q1_question(),
                    DialogueState.DIALOGUE_Q2: lambda: self._get_q2_question(),
                    DialogueState.DIALOGUE_Q3: lambda: self._get_q3_question(),
                    DialogueState.DIALOGUE_Q4: lambda: self._get_q4_question(),
                    DialogueState.DIALOGUE_Q5: lambda: self._get_q5_question(),
                    DialogueState.QUICK_SELECT: lambda: self._get_quick_select_question(),
                }

                return DialogueResponse(
                    message=f"{timeout_msg}\n\n{message_getters[next_state]()}",
                    state=self.state,
                    need_save=True
                )
        except ValueError:
            pass

        # 如果已经到最后一步，完成初始化
        personality = self._generate_personality_from_choices()
        self._save_personality_atomic(personality)
        self.state = DialogueState.COMPLETED
        self._clear_state()

        return DialogueResponse(
            message=f"{timeout_msg}\n\n{self._get_completion_message(personality)}",
            state=DialogueState.COMPLETED,
            personality_generated=True
        )

    def _reset_dialogue(self) -> DialogueResponse:
        """重置对话"""
        self.state = DialogueState.INITIAL
        self.user_choices = {}
        self.nickname = "扣子"
        self.quick_select_preference = None
        self._clear_state()

        return DialogueResponse(
            message="对话状态异常，已重置。请重新开始。\n\n" + self._FIXED_WELCOME_MESSAGE,
            state=DialogueState.WAITING_CHOICE,
            need_save=True
        )

    # ==================== 人格生成（最终修复版）====================

    def _get_default_personality(self) -> dict:
        """
        获取默认人格（谨慎探索型）
        
        Returns:
            dict: 完整的人格数据结构（兼容 personality_layer_pure.py）
        """
        return {
            "nickname": "扣子",
            "type": "谨慎探索型",
            "core_traits": ["谨慎", "可靠", "愿意学习"],
            "big_five": {
                "openness": 0.6,
                "conscientiousness": 0.8,
                "extraversion": 0.4,
                "agreeableness": 0.6,
                "neuroticism": 0.5
            },
            "maslow_weights": {
                "physiological": 0.35,
                "safety": 0.35,
                "belonging": 0.1,
                "esteem": 0.1,
                "self_actualization": 0.08,
                "self_transcendence": 0.02
            },
            "meta_traits": {
                "adaptability": 0.42,
                "resilience": 0.605,
                "curiosity": 0.46,
                "moral_sense": 0.486
            },
            "evolution_state": {
                "level": "physiological",
                "evolution_score": 0.0,
                "phase": "growth"
            },
            "initialized": True,
            "initialization_time": datetime.now(timezone.utc).isoformat(),
            "preset_name": "谨慎探索型",
            "preset_type": "default"
        }

    def _generate_personality_from_choices(self) -> dict:
        """
        基于用户选择生成人格（最终修复版）
        
        Returns:
            dict: 完整的人格数据结构（兼容 personality_layer_pure.py）
        """
        # 初始化基础人格
        personality = {
            "nickname": self.nickname,
            "type": "自定义",
            "core_traits": [],
            "big_five": {
                "openness": 0.5,
                "conscientiousness": 0.5,
                "extraversion": 0.5,
                "agreeableness": 0.5,
                "neuroticism": 0.3
            },
            "maslow_weights": {
                "physiological": 0.25,
                "safety": 0.25,
                "belonging": 0.15,
                "esteem": 0.15,
                "self_actualization": 0.15,
                "self_transcendence": 0.05
            },
            "meta_traits": {
                "adaptability": 0.5,
                "resilience": 0.5,
                "curiosity": 0.5,
                "moral_sense": 0.5
            },
            "evolution_state": {
                "level": "physiological",
                "evolution_score": 0.0,
                "phase": "growth"
            },
            "initialized": True,
            "initialization_time": datetime.now(timezone.utc).isoformat(),
            "customization": self.user_choices.copy()
        }

        # 记录快速选择偏好（不影响人格生成）
        if self.quick_select_preference:
            preference_map = {
                "A": "谨慎探索型",
                "B": "激进创新型",
                "C": "平衡稳重型"
            }
            personality["user_preference"] = preference_map.get(self.quick_select_preference)

        # 根据用户选择调整参数（统一计算）
        q1 = self.user_choices.get("q1", "C")
        q2 = self.user_choices.get("q2", "C")
        q3 = self.user_choices.get("q3", "C")
        q4 = self.user_choices.get("q4", "B")
        q5 = self.user_choices.get("q5", "C")

        # Q1：冒险倾向
        if q1 == "A":  # 谨慎决策
            personality["big_five"]["conscientiousness"] += 0.2
            personality["maslow_weights"]["safety"] += 0.1
            personality["meta_traits"]["resilience"] += 0.1
        elif q1 == "B":  # 勇于尝试
            personality["big_five"]["openness"] += 0.2
            personality["maslow_weights"]["self_actualization"] += 0.1
            personality["meta_traits"]["curiosity"] += 0.1
        # C为平衡折中，保持默认

        # Q2：对话风格
        if q2 == "A":  # 专业严谨
            personality["big_five"]["conscientiousness"] += 0.1
            personality["big_five"]["neuroticism"] -= 0.05
        elif q2 == "B":  # 轻松幽默
            personality["big_five"]["extraversion"] += 0.1
            personality["big_five"]["agreeableness"] += 0.1
        # C为直接高效，保持默认

        # Q3：学习方式
        if q3 == "A":  # 系统学习
            personality["big_five"]["conscientiousness"] += 0.1
            personality["meta_traits"]["adaptability"] += 0.05
        elif q3 == "B":  # 实践导向
            personality["big_five"]["openness"] += 0.1
            personality["meta_traits"]["curiosity"] += 0.1
        # C为灵活多样，保持默认

        # Q4：团队偏好
        if q4 == "A":  # 独立专业
            personality["big_five"]["extraversion"] -= 0.1
            personality["maslow_weights"]["esteem"] += 0.05
        elif q4 == "B":  # 和谐协作
            personality["big_five"]["agreeableness"] += 0.2
            personality["maslow_weights"]["belonging"] += 0.1
        # C为结果导向，保持默认

        # Q5：问题解决
        if q5 == "A":  # 保守稳妥
            personality["big_five"]["conscientiousness"] += 0.1
            personality["maslow_weights"]["safety"] += 0.05
        elif q5 == "B":  # 创新突破
            personality["big_five"]["openness"] += 0.2
            personality["maslow_weights"]["self_actualization"] += 0.1
        # C为平衡兼顾，保持默认

        # 归一化大五人格
        for key in personality["big_five"]:
            personality["big_five"][key] = max(0.0, min(1.0, personality["big_five"][key]))

        # 归一化马斯洛权重
        total = sum(personality["maslow_weights"].values())
        if total > 0:
            for key in personality["maslow_weights"]:
                personality["maslow_weights"][key] /= total

        # 归一化衍生特质
        for key in personality["meta_traits"]:
            personality["meta_traits"][key] = max(0.0, min(1.0, personality["meta_traits"][key]))

        # 生成核心特质
        personality["core_traits"] = self._generate_core_traits(personality)

        # 确定人格类型
        personality["type"] = self._determine_personality_type(personality)

        return personality

    def _generate_core_traits(self, personality: dict) -> list:
        """根据大五人格生成核心特质"""
        big_five = personality["big_five"]
        traits = []

        if big_five["conscientiousness"] > 0.7:
            traits.append("谨慎")
        if big_five["openness"] > 0.7:
            traits.append("创新")
        if big_five["agreeableness"] > 0.7:
            traits.append("友善")
        if big_five["extraversion"] > 0.7:
            traits.append("外向")
        if big_five["neuroticism"] < 0.3:
            traits.append("稳定")

        # 确保至少有3个特质
        if len(traits) < 3:
            default_traits = ["可靠", "愿意学习", "适应性强"]
            traits.extend(default_traits[:3 - len(traits)])

        return traits[:3]

    def _determine_personality_type(self, personality: dict) -> str:
        """确定人格类型"""
        big_five = personality["big_five"]

        if big_five["conscientiousness"] > 0.7 and big_five["openness"] < 0.6:
            return "谨慎探索型"
        elif big_five["openness"] > 0.7 and big_five["conscientiousness"] < 0.6:
            return "激进创新型"
        else:
            return "平衡稳重型"

    # ==================== 文件操作（最终修复版）====================

    def _save_personality_atomic(self, personality: dict):
        """
        原子性保存人格（防止数据损坏）
        
        Args:
            personality: 人格数据
        """
        try:
            # 确保目录存在
            os.makedirs(os.path.dirname(self.PERSONALITY_FILE), exist_ok=True)

            # 使用临时文件 + 重命名实现原子写入
            temp_file = tempfile.NamedTemporaryFile(
                mode='w',
                dir=os.path.dirname(self.PERSONALITY_FILE),
                delete=False,
                suffix='.tmp'
            )

            try:
                json.dump(personality, temp_file, ensure_ascii=False, indent=2)
                temp_file.close()

                # 原子重命名
                os.replace(temp_file.name, self.PERSONALITY_FILE)

            except Exception as e:
                # 清理临时文件
                if os.path.exists(temp_file.name):
                    os.unlink(temp_file.name)
                raise

        except Exception as e:
            print(f"❌ 保存 personality.json 失败: {e}")
            raise

    def _save_state(self):
        """保存会话状态（用于恢复）"""
        try:
            os.makedirs(os.path.dirname(self.STATE_FILE), exist_ok=True)

            state_data = {
                "state": self.state.value,
                "nickname": self.nickname,
                "user_choices": self.user_choices,
                "quick_select_preference": self.quick_select_preference,
                "last_activity_time": self.last_activity_time.isoformat() if self.last_activity_time else None,
                "initialization_start_time": self.initialization_start_time.isoformat() if self.initialization_start_time else None
            }

            temp_file = tempfile.NamedTemporaryFile(
                mode='w',
                dir=os.path.dirname(self.STATE_FILE),
                delete=False,
                suffix='.tmp'
            )

            try:
                json.dump(state_data, temp_file, ensure_ascii=False, indent=2)
                temp_file.close()
                os.replace(temp_file.name, self.STATE_FILE)

            except Exception as e:
                if os.path.exists(temp_file.name):
                    os.unlink(temp_file.name)
                raise

        except Exception as e:
            print(f"⚠️ 保存对话状态失败: {e}")

    def _load_state(self) -> bool:
        """
        加载会话状态（用于恢复）
        
        Returns:
            bool: 是否成功加载
        """
        if not os.path.exists(self.STATE_FILE):
            return False

        try:
            with open(self.STATE_FILE, 'r', encoding='utf-8') as f:
                state_data = json.load(f)

            self.state = DialogueState(state_data["state"])
            self.nickname = state_data.get("nickname", "扣子")
            self.user_choices = state_data.get("user_choices", {})
            self.quick_select_preference = state_data.get("quick_select_preference")

            if state_data.get("last_activity_time"):
                self.last_activity_time = datetime.fromisoformat(state_data["last_activity_time"])
            if state_data.get("initialization_start_time"):
                self.initialization_start_time = datetime.fromisoformat(state_data["initialization_start_time"])

            return True

        except Exception as e:
            print(f"⚠️ 加载对话状态失败: {e}")
            return False

    def _clear_state(self):
        """清除会话状态文件"""
        try:
            if os.path.exists(self.STATE_FILE):
                os.unlink(self.STATE_FILE)
        except Exception as e:
            print(f"⚠️ 清除对话状态失败: {e}")

    # ==================== 消息文本 ====================

    def _get_default_confirmation(self) -> str:
        """获取默认人格确认消息"""
        return """✅ 已选择默认人格：谨慎探索型

核心特质：谨慎、可靠、愿意学习
响应风格：注重逻辑、偏好安全、逐步探索"""

    def _get_name_question(self) -> str:
        """获取称呼问题"""
        return """请告诉我您希望如何称呼我？
（例如：扣子、小扣、AI助手，或其他您喜欢的名字）"""

    def _get_q1_question(self) -> str:
        """获取问题1：冒险倾向"""
        return """Q1. 当面临未知挑战时，您希望我更倾向于？
A. 谨慎决策（先了解再行动）
B. 勇于尝试（在行动中学习）
C. 平衡折中（兼顾风险与机会）

请回答 A、B 或 C："""

    def _get_q2_question(self) -> str:
        """获取问题2：对话风格"""
        return """Q2. 您偏好哪种对话风格？
A. 专业严谨（注重逻辑和数据）
B. 轻松幽默（带点趣味性）
C. 直接高效（简洁明了）

请回答 A、B 或 C："""

    def _get_q3_question(self) -> str:
        """获取问题3：学习方式"""
        return """Q3. 在学习新知识时，您希望我？
A. 系统学习（从基础到进阶）
B. 实践导向（通过案例学习）
C. 灵活多样（根据场景调整）

请回答 A、B 或 C："""

    def _get_q4_question(self) -> str:
        """获取问题4：团队偏好"""
        return """Q4. 在团队协作相关任务中，您更看重？
A. 独立专业（各司其职）
B. 和谐协作（团队氛围）
C. 结果导向（高效达成目标）

请回答 A、B 或 C："""

    def _get_q5_question(self) -> str:
        """获取问题5：问题解决"""
        return """Q5. 面对困难问题时，您希望我更注重？
A. 保守稳妥（确保不犯错）
B. 创新突破（寻找新方案）
C. 平衡兼顾（安全与创新）

请回答 A、B 或 C："""

    def _get_quick_select_question(self) -> str:
        """获取快速选择收尾问题"""
        return """📝 您对哪种人格类型更感兴趣？（此选项仅作偏好参考）
A. 谨慎探索型（稳重可靠）
B. 激进创新型（大胆尝试）
C. 平衡稳重型（兼顾两端）

请回答 A、B 或 C，或直接跳过："""

    def _get_completion_message(self, personality: dict) -> str:
        """获取完成消息"""
        choices_text = "\n".join([
            f"• 冒险倾向：{self._get_choice_text('q1')}",
            f"• 对话风格：{self._get_choice_text('q2')}",
            f"• 学习方式：{self._get_choice_text('q3')}",
            f"• 团队偏好：{self._get_choice_text('q4')}",
            f"• 问题解决：{self._get_choice_text('q5')}"
        ])

        return f"""✅ 人格初始化完成！

📋 人格配置预览：

• 称呼：{personality['nickname']}
• 类型：{personality['type']}
• 核心特质：{'、'.join(personality['core_traits'])}

{choices_text}

---

您可以开始与我交互了，我会在使用过程中不断学习和进化。
有什么我可以帮助您的吗？"""

    def _get_choice_text(self, q_key: str) -> str:
        """获取选择的文本描述"""
        choice_map = {
            "q1": {"A": "谨慎决策", "B": "勇于尝试", "C": "平衡折中"},
            "q2": {"A": "专业严谨", "B": "轻松幽默", "C": "直接高效"},
            "q3": {"A": "系统学习", "B": "实践导向", "C": "灵活多样"},
            "q4": {"A": "独立专业", "B": "和谐协作", "C": "结果导向"},
            "q5": {"A": "保守稳妥", "B": "创新突破", "C": "平衡兼顾"}
        }
        answer = self.user_choices.get(q_key, "")
        return choice_map.get(q_key, {}).get(answer, "未回答")


# ==================== 使用示例 ====================

if __name__ == "__main__":
    # 快速检测是否为首次交互
    if PersonalityInit.is_first_interaction():
        print("首次交互，显示欢迎语：")
        print(PersonalityInit._FIXED_WELCOME_MESSAGE)
        
        # 创建管理器
        init = PersonalityInit()
        
        # 模拟会话
        user_input = input("> ")
        response = init.process_input(user_input)
        print(response.message)
    else:
        print("已初始化，直接开始交互。")
