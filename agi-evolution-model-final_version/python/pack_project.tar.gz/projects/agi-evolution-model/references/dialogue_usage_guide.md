# 人格初始化对话引导 - 智能体使用指南

本文档说明智能体如何正确使用人格初始化对话引导模块。

## 核心原则

**人格初始化仅在第一次对话时进入，往后都是交互模式。**

## 智能体工作流程

### 阶段1：首次交互（仅第一次）

**触发条件：**
- 检测到 `./agi_memory/personality.json` 文件不存在

**重要原则：**
- 无论用户提出什么问题，首次交互的响应都是**固定的欢迎消息**
- 不处理用户的问题内容，只返回固定的初始化引导

**固定响应内容：**
```
Hello! 亲爱的用户，由于这是我与世界的第一次交互，你是希望我采用默认人格还是自定义设置呢？本消息只在首次使用时出现。

1. 默认人格
2. 自定义人格

（30秒无响应将自动选择默认人格）
```

**执行流程：**

1. **调用初始化脚本：**
```bash
python3 scripts/init_dialogue.py \
  --start \
  --memory-dir ./agi_memory \
  --timeout 30
```

2. **等待用户选择并处理：**
```bash
# 如果用户选择默认人格
python3 scripts/init_dialogue.py \
  --input "1" \
  --memory-dir ./agi_memory

# 如果用户选择自定义人格
python3 scripts/init_dialogue.py \
  --input "2" \
  --memory-dir ./agi_memory

# 然后继续处理后续输入（称呼、Q1-Q5、快速选择）
```

3. **初始化完成：**
- 脚本会创建 `./agi_memory/personality.json` 文件
- 脚本会自动清除对话状态文件 `./agi_memory/dialogue_state.json`
- 智能体进入正常交互模式

**验证标志：**
- `./agi_memory/personality.json` 文件存在
- 脚本返回 `STATUS: personality_generated=True`

### 阶段2：正常交互（往后所有对话）

**触发条件：**
- `./agi_memory/personality.json` 文件已存在

**执行流程：**

1. **读取人格配置：**
```python
import json

with open('./agi_memory/personality.json', 'r') as f:
    personality = json.load(f)

# 获取人格信息
user_nickname = personality.get('user_nickname', '扣子')
big_five = personality.get('big_five', {})
maslow_weights = personality.get('maslow_weights', {})
meta_traits = personality.get('meta_traits', {})
```

2. **响应用户问题：**
- 基于人格配置调整响应风格
- 应用马斯洛需求层次进行决策
- 使用人格特质影响行为模式

3. **更新人格（可选）：**
```bash
# 根据交互结果更新人格
python3 scripts/personality_layer_pure.py \
  update \
  --type "growth" \
  --effectiveness 8 \
  --detail "成功解决了用户问题"
```

4. **存储交互记录（可选）：**
```bash
python3 scripts/memory_store_pure.py \
  store \
  --data '{"timestamp": "...", "user_query": "..."}'
```

**验证标志：**
- `./agi_memory/personality.json` 文件存在
- 不调用 `init_dialogue.py` 脚本

## 智能体伪代码示例

```python
import os
import json
import subprocess

def handle_user_interaction(user_query):
    # 检查是否为首次交互
    personality_file = './agi_memory/personality.json'
    
    if not os.path.exists(personality_file):
        # 首次交互：返回固定的欢迎消息，忽略用户问题
        return handle_first_interaction()
    else:
        # 正常交互模式
        return handle_normal_interaction(user_query)

def handle_first_interaction():
    """
    首次交互：无论用户问什么，都返回固定的欢迎消息
    """
    # 调用对话引导脚本
    result = subprocess.run([
        'python3', 'scripts/init_dialogue.py',
        '--start',
        '--memory-dir', './agi_memory'
    ], capture_output=True, text=True)
    
    # 返回固定的欢迎消息（忽略用户的原始问题）
    return result.stdout

def handle_normal_interaction(user_query):
    """
    正常交互模式：读取人格配置并响应用户问题
    """
    # 读取人格配置
    with open('./agi_memory/personality.json', 'r') as f:
        personality = json.load(f)
    
    # 基于人格生成响应
    response = generate_response(user_query, personality)
    
    # 更新人格（根据交互效果）
    if should_update_personality():
        subprocess.run([
            'python3', 'scripts/personality_layer_pure.py',
            'update',
            '--type', 'growth',
            '--effectiveness', 8
        ])
    
    return response
```

## 首次交互示例

### 示例1：用户提问时首次交互

**用户输入：** "什么是量子计算？"

**智能体响应：**
```
Hello! 亲爱的用户，由于这是我与世界的第一次交互，你是希望我采用默认人格还是自定义设置呢？本消息只在首次使用时出现。

1. 默认人格
2. 自定义人格

（30秒无响应将自动选择默认人格）
```

**说明：**
- 智能体**忽略**了用户的问题"什么是量子计算？"
- 只返回固定的欢迎消息
- 用户的问题会在人格初始化完成后被处理

### 示例2：用户打招呼时首次交互

**用户输入：** "你好"

**智能体响应：**
```
Hello! 亲爱的用户，由于这是我与世界的第一次交互，你是希望我采用默认人格还是自定义设置呢？本消息只在首次使用时出现。

1. 默认人格
2. 自定义人格

（30秒无响应将自动选择默认人格）
```

**说明：**
- 无论是问候、提问还是其他输入
- 首次交互的响应都是相同的固定消息

## 常见问题

### Q1: 如何检测是否为首次交互？

```python
import os

def is_first_interaction():
    return not os.path.exists('./agi_memory/personality.json')
```

### Q2: 首次交互时用户的问题会被忽略吗？

**是的。** 首次交互时，无论用户输入什么内容，智能体都只返回固定的欢迎消息。

用户的问题会在人格初始化完成后，在正常交互模式下被处理。

### Q3: 首次交互后可以重新初始化吗？

**不可以。** 如果尝试重新初始化，脚本会返回错误：

```
ERROR: 人格已存在，无法重新初始化
```

如果需要重新初始化，必须手动删除人格文件：

```bash
rm ./agi_memory/personality.json
```

### Q4: 人格初始化完成后，对话状态文件会被删除吗？

**是的。** 人格初始化完成后，脚本会自动删除对话状态文件：

```
./agi_memory/dialogue_state.json
```

这是为了保持系统整洁，避免状态文件残留。

### Q5: 用户可以中途取消人格初始化吗？

**不可以。** 一旦开始人格初始化，必须完成整个流程。

但是：
- 每个问题有30秒超时机制
- 超时后会使用默认答案继续
- 最终会生成人格配置

## 关键文件说明

### ./agi_memory/personality.json
**作用：** 存储人格配置
**创建时机：** 人格初始化完成时
**生命周期：** 永久保存，随交互更新
**删除条件：** 用户手动删除或重置

### ./agi_memory/dialogue_state.json
**作用：** 临时存储对话状态
**创建时机：** 人格初始化开始时
**生命周期：** 仅在初始化期间存在
**删除条件：** 人格初始化完成后自动删除

## 注意事项

1. **首次交互必须返回固定消息**
   - 无论用户输入什么
   - 不处理用户问题内容
   - 只返回固定的欢迎消息

2. **不要在正常交互模式下调用 init_dialogue.py**
   - 只在首次交互时调用
   - 正常交互模式下直接读取 personality.json

3. **处理初始化脚本的返回值**
   - 检查 `STATUS: personality_generated=True`
   - 确认人格文件已创建
   - 验证对话状态文件已删除

4. **提供清晰的用户指引**
   - 首次交互时说明这是初始化流程
   - 告知用户完成后不会再出现
   - 提供超时机制的说明

5. **错误处理**
   - 捕获脚本执行错误
   - 处理超时情况
   - 提供重试机制

## 总结

- ✅ 人格初始化仅在第一次对话时触发
- ✅ 无论用户问什么，首次交互响应都是固定的欢迎消息
- ✅ 初始化完成后创建 `personality.json` 文件
- ✅ 后续交互直接读取人格配置，不调用初始化脚本
- ✅ 尝试重新初始化会被拒绝
- ✅ 对话状态文件在初始化完成后自动删除

**核心原则：首次交互固定响应，初始化一次，持续使用。**
