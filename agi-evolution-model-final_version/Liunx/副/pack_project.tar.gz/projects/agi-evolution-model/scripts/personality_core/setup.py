#!/usr/bin/env python3
"""
Setup script for building personality_core C extension

Usage:
    python3 setup.py build_ext --inplace
    pip install -e .
"""

from setuptools import setup, Extension
from setuptools.command.build_ext import build_ext
import sys

# 定义C扩展模块
personality_core = Extension(
    'personality_core',
    sources=['personality_core.c'],
    include_dirs=[],
    extra_compile_args=['-O3', '-fPIC'],
    extra_link_args=['-lm']
)

# 编译优化类
class BuildExt(build_ext):
    def build_extensions(self):
        # 针对不同的编译器设置优化选项
        if sys.platform == 'darwin':
            # macOS
            for ext in self.extensions:
                ext.extra_compile_args = ['-O3', '-fPIC', '-arch', 'x86_64', '-arch', 'arm64']
        elif sys.platform.startswith('linux'):
            # Linux
            for ext in self.extensions:
                ext.extra_compile_args = ['-O3', '-fPIC', '-march=native']
        elif sys.platform == 'win32':
            # Windows
            for ext in self.extensions:
                ext.extra_compile_args = ['/O2', '/GL']
        super().build_extensions()

# 设置包信息
setup(
    name='personality_core',
    version='1.0.0',
    description='Core algorithms for AGI Evolution Model',
    ext_modules=[personality_core],
    cmdclass={'build_ext': BuildExt},
    python_requires='>=3.7',
)
