#!/bin/bash
# C 扩展构建脚本
# 用于编译 personality_core.so

set -e

echo "=== AGI Evolution Model - C Extension Build Script ==="
echo ""

# 进入 personality_core 目录
cd "$(dirname "$0")/personality_core"

echo "当前目录: $(pwd)"
echo ""

# 检查 Python 版本
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python 版本: $PYTHON_VERSION"

# 编译 C 扩展
echo ""
echo "正在编译 C 扩展..."
python3 setup.py build_ext --inplace

# 检查编译产物
echo ""
echo "编译产物:"
ls -lh *.so 2>/dev/null || ls -lh *.pyd 2>/dev/null || echo "未找到编译产物"

# 重命名为主文件名（如果需要）
if ls *.cpython-*.so 1> /dev/null 2>&1; then
    echo ""
    echo "重命名为主文件名..."
    cp *.cpython-*.so personality_core.so
    echo "✓ 已创建 personality_core.so"
fi

if ls *.cp*.pyd 1> /dev/null 2>&1; then
    echo ""
    echo "重命名为主文件名（Windows）..."
    cp *.cp*.pyd personality_core.so
    echo "✓ 已创建 personality_core.so"
fi

echo ""
echo "=== 编译完成 ==="
echo ""
echo "测试 C 扩展..."
python3 -c "
import personality_core
print('✓ C 扩展加载成功')
print('✓ 可用函数:', ', '.join([name for name in dir(personality_core) if not name.startswith('_')]))
"

echo ""
echo "=== 构建完成 ==="
