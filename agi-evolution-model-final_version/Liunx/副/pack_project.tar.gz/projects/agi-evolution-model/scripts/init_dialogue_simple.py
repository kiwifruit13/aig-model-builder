#!/usr/bin/env python3
"""
人格初始化对话引导脚本（简化版）

功能：
1. 检测首次交互
2. 一次性询问用户所有问题
3. 基于回答统一生成人格参数
4. 保存人格配置

简化特点：
- 无需对话状态文件
- 一次性收集所有信息
- 统一生成人格参数
"""

import json
import os
import sys
import argparse
from typing import Dict, List


class PersonalityInitializer:
    """人格初始化器（简化版）"""

    def __init__(self, memory_dir: str = None):
        """
        初始化人格初始化器

        Args:
            memory_dir: 记忆存储目录，默认 ./agi_memory
        """
        self.memory_dir = memory_dir or os.path.join(os.path.dirname(__file__), "..", "agi_memory")
        self.memory_dir = os.path.abspath(self.memory_dir)

    def is_first_interaction(self) -> bool:
        """
        检测是否为首次交互

        Returns:
            bool: True表示首次交互，False表示已初始化
        """
        personality_file = os.path.join(self.memory_dir, "personality.json")
        return not os.path.exists(personality_file)

    def get_welcome_message(self) -> str:
        """
        获取首次交互的欢迎消息

        Returns:
            str: 固定的欢迎消息
        """
        return """Hello! 亲爱的用户，由于这是我与世界的第一次交互，你是希望我采用默认人格还是自定义设置呢？本消息只在首次使用时出现。

1. 默认人格
2. 自定义人格

（30秒无响应将自动选择默认人格）"""

    def get_default_personality(self, nickname: str = "扣子") -> dict:
        """
        获取默认人格配置

        Args:
            nickname: 用户称呼，默认"扣子"

        Returns:
            dict: 默认人格配置
        """
        import time
        
        return {
            "big_five": {
                "openness": 0.6,
                "conscientiousness": 0.8,
                "extraversion": 0.4,
                "agreeableness": 0.6,
                "neuroticism": 0.5
            },
            "maslow_weights": {
                "physiological": 0.35,
                "safety": 0.35,
                "belonging": 0.1,
                "esteem": 0.1,
                "self_actualization": 0.08,
                "self_transcendence": 0.02
            },
            "meta_traits": {
                "adaptability": 0.42,
                "resilience": 0.605,
                "curiosity": 0.46,
                "moral_sense": 0.486
            },
            "evolution_state": {
                "level": "physiological",
                "evolution_score": 0.0,
                "phase": "growth"
            },
            "statistics": {
                "total_interactions": 0,
                "success_rate_by_need": {
                    "physiological": 0.0,
                    "safety": 0.0,
                    "belonging": 0.0,
                    "esteem": 0.0,
                    "self_actualization": 0.0,
                    "self_transcendence": 0.0
                }
            },
            "version": "2.0",
            "type": "preset",
            "preset_name": "谨慎探索型",
            "description": "在保证安全的前提下，愿意尝试新事物",
            "core_traits": ["谨慎", "可靠", "愿意学习"],
            "last_updated": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "update_source": "default_init",
            "user_nickname": nickname
        }

    def generate_personality_from_answers(self, nickname: str, answers: List[str]) -> dict:
        """
        基于所有回答生成人格配置

        Args:
            nickname: 用户称呼
            answers: 用户对所有问题的回答列表 [q1, q2, q3, q4, q5]

        Returns:
            dict: 生成的人格配置
        """
        import time

        # 基础人格向量（中值）
        personality = {
            "big_five": {
                "openness": 0.5,
                "conscientiousness": 0.5,
                "extraversion": 0.5,
                "agreeableness": 0.5,
                "neuroticism": 0.3
            },
            "maslow_weights": {
                "physiological": 0.25,
                "safety": 0.25,
                "belonging": 0.15,
                "esteem": 0.15,
                "self_actualization": 0.15,
                "self_transcendence": 0.05
            }
        }

        # 分析问题1：冒险倾向
        q1 = answers[0].upper() if len(answers) > 0 else 'A'
        if 'A' in q1 or '谨慎' in q1:
            personality['big_five']['conscientiousness'] += 0.2
            personality['big_five']['neuroticism'] += 0.1
            personality['maslow_weights']['safety'] += 0.1
        elif 'B' in q1 or '尝试' in q1:
            personality['big_five']['openness'] += 0.2
            personality['big_five']['extraversion'] += 0.1
            personality['maslow_weights']['self_actualization'] += 0.1
        elif 'C' in q1 or '平衡' in q1:
            personality['big_five']['agreeableness'] += 0.1

        # 分析问题2：对话风格
        q2 = answers[1].upper() if len(answers) > 1 else 'A'
        if 'A' in q2 or '严谨' in q2 or '逻辑' in q2:
            personality['big_five']['conscientiousness'] += 0.15
            personality['maslow_weights']['esteem'] += 0.05
        elif 'B' in q2 or '幽默' in q2 or '友好' in q2:
            personality['big_five']['extraversion'] += 0.15
            personality['big_five']['agreeableness'] += 0.1
            personality['maslow_weights']['belonging'] += 0.1
        elif 'C' in q2 or '高效' in q2:
            personality['big_five']['conscientiousness'] += 0.1
            personality['maslow_weights']['safety'] += 0.05

        # 分析问题3：学习方式
        q3 = answers[2].upper() if len(answers) > 2 else 'A'
        if 'A' in q3 or '系统' in q3:
            personality['big_five']['conscientiousness'] += 0.15
            personality['maslow_weights']['esteem'] += 0.05
        elif 'B' in q3 or '实践' in q3 or '案例' in q3:
            personality['big_five']['openness'] += 0.1
            personality['maslow_weights']['self_actualization'] += 0.05
        elif 'C' in q3 or '灵活' in q3:
            personality['big_five']['openness'] += 0.1

        # 分析问题4：团队偏好
        q4 = answers[3].upper() if len(answers) > 3 else 'A'
        if 'A' in q4 or '独立' in q4 or '专业' in q4:
            personality['big_five']['conscientiousness'] += 0.1
            personality['maslow_weights']['esteem'] += 0.05
        elif 'B' in q4 or '和谐' in q4 or '协作' in q4:
            personality['big_five']['agreeableness'] += 0.2
            personality['maslow_weights']['belonging'] += 0.1
        elif 'C' in q4 or '结果' in q4 or '高效' in q4:
            personality['big_five']['conscientiousness'] += 0.15
            personality['maslow_weights']['self_actualization'] += 0.05

        # 分析问题5：问题解决风格
        q5 = answers[4].upper() if len(answers) > 4 else 'A'
        if 'A' in q5 or '保守' in q5 or '稳妥' in q5:
            personality['big_five']['conscientiousness'] += 0.2
            personality['maslow_weights']['safety'] += 0.15
        elif 'B' in q5 or '创新' in q5 or '突破' in q5:
            personality['big_five']['openness'] += 0.25
            personality['maslow_weights']['self_actualization'] += 0.15
            personality['maslow_weights']['self_transcendence'] += 0.05
        elif 'C' in q5 or '平衡' in q5:
            personality['big_five']['agreeableness'] += 0.1

        # 归一化人格向量到0-1范围
        for key in personality['big_five']:
            personality['big_five'][key] = max(0.0, min(1.0, personality['big_five'][key]))

        # 归一化马斯洛权重
        total = sum(personality['maslow_weights'].values())
        for key in personality['maslow_weights']:
            personality['maslow_weights'][key] /= total

        # 计算衍生特质
        big_five = personality['big_five']
        maslow = personality['maslow_weights']

        adaptability = (
            big_five['openness'] * 0.4 +
            (1 - big_five['neuroticism']) * 0.3 +
            (maslow['self_actualization'] + maslow['self_transcendence']) * 0.3
        )

        resilience = (
            big_five['conscientiousness'] * 0.4 +
            big_five['agreeableness'] * 0.3 +
            maslow['safety'] * 0.3
        )

        curiosity = (
            big_five['openness'] * 0.5 +
            big_five['extraversion'] * 0.3 +
            maslow['self_actualization'] * 0.2
        )

        moral_sense = (
            big_five['agreeableness'] * 0.4 +
            big_five['conscientiousness'] * 0.4 +
            maslow['esteem'] * 0.2
        )

        personality['meta_traits'] = {
            "adaptability": round(adaptability, 3),
            "resilience": round(resilience, 3),
            "curiosity": round(curiosity, 3),
            "moral_sense": round(moral_sense, 3)
        }

        # 确定人格类型
        if big_five['conscientiousness'] > 0.7 and big_five['neuroticism'] < 0.5:
            preset_name = "谨慎探索型"
        elif big_five['openness'] > 0.7:
            preset_name = "激进创新型"
        else:
            preset_name = "平衡稳重型"

        # 生成描述和核心特质
        traits = []
        if big_five['conscientiousness'] > 0.7:
            traits.append("谨慎可靠")
        if big_five['openness'] > 0.7:
            traits.append("乐于创新")
        if big_five['agreeableness'] > 0.7:
            traits.append("善于合作")
        if not traits:
            traits = ["平衡"]

        personality.update({
            "evolution_state": {
                "level": "physiological",
                "evolution_score": 0.0,
                "phase": "growth"
            },
            "preset_name": preset_name,
            "description": f"基于您的偏好生成的个性化人格，特点是{'、'.join(traits[:3])}",
            "core_traits": traits[:3],
            "last_updated": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "update_source": "dialogue_init",
            "version": "2.0",
            "type": "custom",
            "user_nickname": nickname,
            "statistics": {
                "total_interactions": 0,
                "success_rate_by_need": {
                    "physiological": 0.0,
                    "safety": 0.0,
                    "belonging": 0.0,
                    "esteem": 0.0,
                    "self_actualization": 0.0,
                    "self_transcendence": 0.0
                }
            }
        })

        return personality

    def save_personality(self, personality: dict):
        """
        保存人格配置到文件

        Args:
            personality: 人格配置字典
        """
        os.makedirs(self.memory_dir, exist_ok=True)
        personality_file = os.path.join(self.memory_dir, "personality.json")

        with open(personality_file, 'w', encoding='utf-8') as f:
            json.dump(personality, f, ensure_ascii=False, indent=2)


def main():
    """命令行接口"""
    parser = argparse.ArgumentParser(description='人格初始化对话引导器（简化版）')
    parser.add_argument('--check', action='store_true', help='检查是否为首次交互')
    parser.add_argument('--welcome', action='store_true', help='获取欢迎消息')
    parser.add_argument('--default', action='store_true', help='使用默认人格')
    parser.add_argument('--custom', action='store_true', help='使用自定义人格')
    parser.add_argument('--nickname', type=str, help='用户称呼')
    parser.add_argument('--answers', type=str, help='自定义人格的回答，用逗号分隔（例如：A,B,C,A,B）')
    parser.add_argument('--memory-dir', type=str, help='记忆存储目录')

    args = parser.parse_args()

    initializer = PersonalityInitializer(memory_dir=args.memory_dir)

    # 检查是否为首次交互
    if args.check:
        print(f"is_first_interaction: {initializer.is_first_interaction()}")
        return

    # 获取欢迎消息
    if args.welcome:
        if not initializer.is_first_interaction():
            print("ERROR: 人格已存在，无需初始化", file=sys.stderr)
            sys.exit(1)
        print(initializer.get_welcome_message())
        return

    # 使用默认人格
    if args.default:
        if not initializer.is_first_interaction():
            print("ERROR: 人格已存在，无法重新初始化", file=sys.stderr)
            sys.exit(1)
        
        nickname = args.nickname or "扣子"
        personality = initializer.get_default_personality(nickname)
        initializer.save_personality(personality)
        
        print("已为您初始化默认人格（谨慎探索型）。")
        print(f"user_nickname: {nickname}")
        print("STATUS: personality_generated=True")
        return

    # 使用自定义人格
    if args.custom:
        if not initializer.is_first_interaction():
            print("ERROR: 人格已存在，无法重新初始化", file=sys.stderr)
            sys.exit(1)
        
        if not args.answers:
            print("ERROR: 自定义人格需要提供 --answers 参数", file=sys.stderr)
            sys.exit(1)
        
        nickname = args.nickname or "扣子"
        answers = [a.strip() for a in args.answers.split(',')]
        
        personality = initializer.generate_personality_from_answers(nickname, answers)
        initializer.save_personality(personality)
        
        # 完成确认消息
        print(f"太好了！我会根据你的选择和对话创建了专属的人格配置。")
        print(f"**你选择的称呼**: {nickname}")
        print(f"**核心特质**: {', '.join(personality['core_traits'])}")
        print(f"**人格类型**: {personality['preset_name']}")
        print(f"**描述**: {personality['description']}")
        print()
        print(f"从现在开始，我将以这个人格与你持续互动。在未来的交互中，我会根据我们的共同经历不断学习和进化。")
        print()
        print(f"现在，我们可以开始第一次正式对话了！你有什么想和我聊的吗？")
        print("STATUS: personality_generated=True")
        return

    # 默认：显示帮助
    parser.print_help()


if __name__ == "__main__":
    main()
