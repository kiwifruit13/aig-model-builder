# 元认知检测模块的非侵入式并行设计

## 核心设计原则

元认知检测模块是一个**独立的并行分支**，不参与主循环推理，只在推理完成后激活，确保不打断主循环的正常执行。

## 设计动机

### 1. 主循环的完整性保障

主循环（三角形顶点循环）是智能体的核心认知系统，必须保持其独立性和完整性：

```
用户输入
  ↓
得不到顶点（动力源）
  ↓
数学顶点（逻辑推理）
  ↓
自我迭代顶点（进化）
  ↓
用户响应 ← 【主循环输出点】
```

**关键要求**：
- ✅ 主循环必须能够独立完成推理并输出响应
- ✅ 主循环不应被任何外部模块中断或阻塞
- ✅ 主循环的执行时间应当可预测且稳定

### 2. 非侵入式设计的好处

**避免主循环延迟**：
- 如果元认知检测作为主循环的一部分，会增加每次推理的延迟
- 独立分支设计允许主循环快速输出响应
- 元认知检测可以异步执行

**保证响应优先性**：
- 用户的首要需求是获得响应
- 自我纠错是优化而非必需
- 独立分支确保响应不被阻断

**支持异步优化**：
- 纠错可以在响应输出后进行
- 纠错结果可以用于后续学习
- 不影响当前交互体验

## 架构实现

### 时序设计

```
时间轴
  ↓
[T0] 用户输入到达
  ↓
[T1] 主循环开始
     ├─ 得不到顶点：识别动力源
     ├─ 数学顶点：执行逻辑推理
     └─ 自我迭代顶点：学习优化
  ↓
[T2] 数学顶点推理完成 ← 触发点
     ↓
     【分支1：主循环继续】（主路径）
     ├─ 自我迭代顶点继续处理
     ├─ 生成最终响应
     └─ [T3] 输出响应给用户 ← 主循环完成
     ↓
     【分支2：元认知检测启动】（并行分支，异步）
     ├─ 客观性评估器评估响应
     ├─ 生成客观特征标注
     ├─ 映射层决策
     ├─ 若需要：自我迭代顶点执行自我纠错
     └─ 记录层存储
  ↓
[T4] 记录层反馈（可选）
     ├─ 反馈给映射层（哲学洞察）
     └─ 反馈给自我迭代顶点（学习数据）
```

### 关键特性

#### 1. 不参与主循环推理

元认知检测模块：
- ❌ 不参与"得不到 → 数学 → 自我迭代"的循环过程
- ❌ 不影响主循环的逻辑推理
- ❌ 不修改主循环的推理结果
- ✅ 只在主循环完成后启动

#### 2. 仅在推理后激活

触发条件：
```python
# 数学顶点推理完成后的回调
def math_vertex_callback(reasoning_result):
    # 1. 输出响应（主循环继续）
    output_response(reasoning_result)

    # 2. 异步触发元认知检测（独立分支）
    if config.metacognition_enabled:
        trigger_metacognition_detection(reasoning_result)
```

#### 3. 仅生成客观特征标注

客观性评估器的职责：
```python
class ObjectivityEvaluator:
    def evaluate(self, response):
        """
        仅评估并生成客观特征标注
        不执行任何纠错操作
        """
        # 检测主观性特征
        subjectivity_metrics = self.detect_subjectivity(response)

        # 计算客观性评分
        objectivity_score = 1.0 - subjectivity_metrics.total

        # 判断场景适切性
        is_appropriate = self.check_appropriateness(
            objectivity_score,
            current_scene_type
        )

        # 生成客观特征标注（仅标注，不修改）
        return {
            'subjectivity_score': subjectivity_metrics.total,
            'objectivity_score': objectivity_score,
            'required_objectivity': self.get_required_objectivity(current_scene_type),
            'is_appropriate': is_appropriate,
            'subjectivity_dimensions': subjectivity_metrics.dimensions,
            'scene_type': current_scene_type
        }
```

## 代码实现示例

### 主循环流程

```python
class MainLoop:
    def process_user_input(self, user_input):
        """主循环处理流程"""
        # 1. 三角形顶点循环
        drive_signal = self.drive_vertex.process(user_input)
        reasoning_result = self.math_vertex.process(drive_signal)
        iteration_result = self.iteration_vertex.process(reasoning_result)

        # 2. 输出响应（主循环完成，不等待元认知检测）
        response = self.generate_response(reasoning_result)
        self.output_to_user(response)

        # 3. 异步触发元认知检测（独立分支）
        if self.metacognition_enabled:
            # 不阻塞主循环，异步执行
            self.async_trigger_metacognition(reasoning_result, response)

        return response
```

### 元认知检测独立分支

```python
class MetacognitionDetectionBranch:
    def __init__(self, mapping_layer, self_iteration, memory_layer):
        self.objectivity_evaluator = ObjectivityEvaluator()
        self.mapping_layer = mapping_layer
        self.self_iteration = self_iteration
        self.memory_layer = memory_layer

    async def detect_and_correct(self, reasoning_result, response):
        """
        元认知检测分支（异步执行）
        不阻塞主循环
        """
        try:
            # 步骤1：客观性评估器生成标注
            objectivity_metrics = self.objectivity_evaluator.evaluate(response)

            # 步骤2：映射层决策
            decision = await self.mapping_layer.make_metacognition_decision(objectivity_metrics)

            # 步骤3：记录客观性标注（无论是否纠错）
            self.memory_layer.record_objectivity_metrics(objectivity_metrics)

            # 步骤4：若需要纠错，自我迭代顶点执行
            if decision.trigger_reflection:
                correction_result = await self.self_iteration.reflect_and_correct(
                    response,
                    objectivity_metrics,
                    decision
                )

                # 步骤5：记录纠错过程
                self.memory_layer.record_correction(
                    objectivity_metrics,
                    decision,
                    correction_result
                )

            # 步骤6：反馈（异步，不阻塞）
            await self.feedback_to_components(objectivity_metrics, decision)

        except Exception as e:
            # 元认知检测失败不影响主循环
            logger.warning(f"Metacognition detection failed: {e}")

    async def feedback_to_components(self, objectivity_metrics, decision):
        """
        反馈给映射层和自我迭代顶点
        异步执行，不阻塞主循环
        """
        # 反馈哲学洞察给映射层
        insights = self.memory_layer.extract_insights('meta_cognition')
        await self.mapping_layer.receive_insights(insights)

        # 反馈学习数据给自我迭代顶点
        learning_data = self.memory_layer.extract_learning_data('meta_cognition')
        await self.self_iteration.receive_learning_data(learning_data)
```

## 关键约束

### 1. 时间约束

```
主循环执行时间：T_main_loop
元认知检测执行时间：T_metacognition

约束条件：
T_main_loop << T_metacognition
```

- 主循环应当快速完成（通常 < 1s）
- 元认知检测可以更慢（允许 1-3s）
- 用户响应时间由主循环决定

### 2. 数据约束

元认知检测只能**读取**主循环的输出，不能**修改**：

```python
# ✅ 允许：读取主循环输出
response = main_loop.get_output()
objectivity_metrics = evaluator.evaluate(response)

# ❌ 禁止：修改主循环输出
response.text = "modified text"  # 严禁！
```

### 3. 流程约束

元认知检测不能影响主循环的流程：

```python
# ✅ 正确：主循环独立完成
response = main_loop.process(user_input)
output(response)
# 主循环已完成，元认知检测开始
metacognition.detect(response)

# ❌ 错误：元认知检测阻塞主循环
objectivity_metrics = evaluator.evaluate(response)
if objectivity_metrics.is_inappropriate:
    # 严禁：阻塞主循环
    response = metacognition.correct(response)
output(response)
```

## 设计优势

### 1. 用户体验优先

- ✅ 响应速度快，不因元认知检测而延迟
- ✅ 交互流畅，不被纠错过程打断
- ✅ 用户感知不到元认知检测的存在

### 2. 系统稳定性

- ✅ 主循环独立运行，不受元认知检测失败影响
- ✅ 元认知检测失败不会导致系统崩溃
- ✅ 可以独立优化和调试元认知检测模块

### 3. 可扩展性

- ✅ 可以添加更多元认知维度（如逻辑一致性、伦理边界）
- ✅ 可以集成其他类型的自我监控机制
- ✅ 可以灵活调整元认知检测的频率和深度

## 对比分析

| 特性 | 侵入式设计 | 非侵入式设计 |
|------|-----------|-------------|
| **主循环延迟** | 增加延迟 | 不增加延迟 |
| **响应时间** | 不可预测 | 可预测且稳定 |
| **用户体验** | 可能卡顿 | 流畅 |
| **系统稳定性** | 元认知失败影响主循环 | 主循环独立运行 |
| **可扩展性** | 受主循环限制 | 灵活扩展 |
| **调试难度** | 难以定位问题 | 模块独立易调试 |

## 实现建议

### 1. 异步执行

```python
import asyncio

class MainLoop:
    async def process_user_input(self, user_input):
        # 主循环同步执行
        response = self.main_loop_execution(user_input)

        # 元认知检测异步执行（不等待）
        asyncio.create_task(self.metacognition.detect(response))

        return response
```

### 2. 独立线程/进程

```python
import threading

class MainLoop:
    def process_user_input(self, user_input):
        # 主循环在主线程执行
        response = self.main_loop_execution(user_input)

        # 元认知检测在独立线程执行
        metacognition_thread = threading.Thread(
            target=self.metacognition.detect,
            args=(response,)
        )
        metacognition_thread.start()

        return response
```

### 3. 事件驱动

```python
class MainLoop:
    def __init__(self):
        self.event_bus = EventBus()

    def process_user_input(self, user_input):
        response = self.main_loop_execution(user_input)

        # 发布事件，不等待处理完成
        self.event_bus.publish('response_generated', response)

        return response

class MetacognitionBranch:
    def __init__(self, event_bus):
        event_bus.subscribe('response_generated', self.on_response_generated)

    def on_response_generated(self, response):
        self.detect_and_correct(response)
```

## 总结

元认知检测模块的**非侵入式并行设计**是架构的核心原则：

1. ✅ 不参与主循环推理
2. ✅ 只在推理后激活
3. ✅ 仅生成客观特征标注
4. ✅ 异步执行，不阻塞主循环
5. ✅ 不修改主循环输出
6. ✅ 失败不影响主循环

这种设计确保了主循环的完整性、稳定性和用户体验，同时为智能体提供了强大的自我监控和自我纠错能力。
