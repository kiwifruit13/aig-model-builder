#!/usr/bin/env python3
"""
意向性守护协程测试用例

测试外环的独立性和零阻塞特性。
"""

import asyncio
import pytest
import tempfile
import shutil
from pathlib import Path

# 添加scripts目录到路径
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from intentionality_daemon import IntentionalityDaemon, AsyncAdvicePool


@pytest.fixture
def temp_memory_dir():
    """临时测试目录"""
    temp_dir = tempfile.mkdtemp(prefix="test_daemon_")
    yield temp_dir
    shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.mark.asyncio
async def test_daemon_initialization(temp_memory_dir):
    """测试守护协程初始化"""
    advice_pool = AsyncAdvicePool(temp_memory_dir)
    daemon = IntentionalityDaemon(temp_memory_dir, advice_pool)

    assert daemon.running is False
    assert daemon.collector is not None
    assert daemon.classifier is not None
    assert daemon.analyzer is not None
    assert daemon.regulator is not None
    assert daemon.trigger is not None


@pytest.mark.asyncio
async def test_daemon_start_stop(temp_memory_dir):
    """测试守护协程启动和停止"""
    advice_pool = AsyncAdvicePool(temp_memory_dir)
    daemon = IntentionalityDaemon(temp_memory_dir, advice_pool)

    # 启动守护协程
    start_task = asyncio.create_task(daemon.start())
    await asyncio.sleep(0.2)  # 等待启动

    assert daemon.running is True

    # 停止守护协程
    await daemon.stop()
    assert daemon.running is False


@pytest.mark.asyncio
async def test_daemon_independence(temp_memory_dir):
    """测试守护协程独立性"""
    advice_pool = AsyncAdvicePool(temp_memory_dir)
    daemon = IntentionalityDaemon(temp_memory_dir, advice_pool)

    # 启动守护协程
    asyncio.create_task(daemon.start())
    await asyncio.sleep(0.2)

    # 守护协程应该独立运行
    assert daemon.running is True

    # 主循环可以执行其他任务
    main_loop_completed = False

    async def main_loop_task():
        """模拟主循环任务"""
        await asyncio.sleep(0.1)
        nonlocal main_loop_completed
        main_loop_completed = True

    # 主循环任务应该正常执行
    await main_loop_task()
    assert main_loop_completed is True

    # 守护协程仍在运行
    assert daemon.running is True

    await daemon.stop()


@pytest.mark.asyncio
async def test_daemon_statistics(temp_memory_dir):
    """测试守护协程统计信息"""
    advice_pool = AsyncAdvicePool(temp_memory_dir)
    daemon = IntentionalityDaemon(temp_memory_dir, advice_pool)

    # 启动守护协程
    asyncio.create_task(daemon.start())
    await asyncio.sleep(0.3)  # 运行一段时间

    # 获取统计信息
    stats = await daemon.get_stats()

    assert 'total_iterations' in stats
    assert 'total_collected' in stats
    assert 'total_classified' in stats
    assert 'total_analyzed' in stats
    assert 'total_regulations' in stats
    assert 'errors' in stats

    # 至少应该有一些迭代
    assert stats['total_iterations'] >= 1

    await daemon.stop()


@pytest.mark.asyncio
async def test_advice_pool_add_and_pull(temp_memory_dir):
    """测试建议池添加和拉取"""
    advice_pool = AsyncAdvicePool(temp_memory_dir)

    # 添加建议
    advice_id = await advice_pool.add_advice_async(
        vertex="iteration",
        suggestion={
            "content": "测试建议",
            "priority": 0.8,
            "confidence": 0.9
        }
    )

    assert advice_id is not None

    # 拉取建议
    advice = await advice_pool.pull_advice_async(timeout=0.1)
    assert advice is not None
    assert advice['content'] == "测试建议"
    assert advice['priority'] == 0.8


@pytest.mark.asyncio
async def test_advice_pool_priority(temp_memory_dir):
    """测试建议池优先级"""
    advice_pool = AsyncAdvicePool(temp_memory_dir)

    # 添加多个不同优先级的建议
    await advice_pool.add_advice_async("iteration", {"content": "低优先级", "priority": 0.3})
    await advice_pool.add_advice_async("iteration", {"content": "高优先级", "priority": 0.9})
    await advice_pool.add_advice_async("iteration", {"content": "中优先级", "priority": 0.6})

    # 应该先拉取到高优先级的建议
    advice = await advice_pool.pull_advice_async(timeout=0.1)
    assert advice is not None
    assert advice['content'] == "高优先级"


@pytest.mark.asyncio
async def test_advice_pool_pull_timeout(temp_memory_dir):
    """测试建议池拉取超时"""
    advice_pool = AsyncAdvicePool(temp_memory_dir)

    # 队列为空，应该超时返回None
    advice = await advice_pool.pull_advice_async(timeout=0.1)
    assert advice is None


@pytest.mark.asyncio
async def test_advice_pool_vertex_filter(temp_memory_dir):
    """测试建议池顶点过滤"""
    advice_pool = AsyncAdvicePool(temp_memory_dir)

    # 添加不同顶点的建议
    await advice_pool.add_advice_async("drive", {"content": "驱动建议", "priority": 0.8})
    await advice_pool.add_advice_async("math", {"content": "数学建议", "priority": 0.8})
    await advice_pool.add_advice_async("iteration", {"content": "迭代建议", "priority": 0.8})

    # 只拉取math顶点的建议
    advice = await advice_pool.pull_advice_async(vertex="math", timeout=0.1)
    assert advice is not None
    assert advice['vertex'] == "math"


@pytest.mark.asyncio
async def test_main_loop_zero_blocking(temp_memory_dir):
    """测试主循环零阻塞"""
    advice_pool = AsyncAdvicePool(temp_memory_dir)
    daemon = IntentionalityDaemon(temp_memory_dir, advice_pool)

    # 启动守护协程
    asyncio.create_task(daemon.start())
    await asyncio.sleep(0.2)

    # 模拟主循环
    main_loop_latencies = []

    async def main_loop_iteration():
        """模拟主循环迭代"""
        start = asyncio.get_event_loop().time()
        
        # 拉取建议（应该快速返回）
        advice = await advice_pool.pull_advice_async(timeout=0.05)
        
        latency = asyncio.get_event_loop().time() - start
        main_loop_latencies.append(latency)
        
        return advice

    # 执行多次主循环迭代
    for _ in range(10):
        await main_loop_iteration()

    # 所有迭代都应该快速完成（<100ms）
    for latency in main_loop_latencies:
        assert latency < 0.1, f"主循环迭代耗时过长: {latency:.3f}s"

    # 平均延迟应该很低（<60ms，放宽一点）
    avg_latency = sum(main_loop_latencies) / len(main_loop_latencies)
    assert avg_latency < 0.06, f"平均延迟过高: {avg_latency:.3f}s"

    await daemon.stop()


@pytest.mark.asyncio
async def test_concurrent_operations(temp_memory_dir):
    """测试并发操作"""
    advice_pool = AsyncAdvicePool(temp_memory_dir)
    daemon = IntentionalityDaemon(temp_memory_dir, advice_pool)

    # 启动守护协程
    asyncio.create_task(daemon.start())
    await asyncio.sleep(0.2)

    # 并发添加建议
    add_tasks = [
        advice_pool.add_advice_async("iteration", {"content": f"建议{i}", "priority": 0.5})
        for i in range(10)
    ]
    results = await asyncio.gather(*add_tasks, return_exceptions=True)

    # 所有添加操作都应该成功
    assert all(isinstance(r, str) for r in results)
    assert len([r for r in results if isinstance(r, str)]) == 10

    # 并发拉取建议
    pull_tasks = [
        advice_pool.pull_advice_async(timeout=0.05)
        for _ in range(5)
    ]
    results = await asyncio.gather(*pull_tasks, return_exceptions=True)

    # 所有拉取操作都应该成功（返回建议或None）
    assert all(r is None or isinstance(r, dict) for r in results)

    await daemon.stop()


@pytest.mark.asyncio
async def test_daemon_error_isolation(temp_memory_dir):
    """测试守护协程错误隔离"""
    advice_pool = AsyncAdvicePool(temp_memory_dir)
    daemon = IntentionalityDaemon(temp_memory_dir, advice_pool)

    # 启动守护协程
    asyncio.create_task(daemon.start())
    await asyncio.sleep(0.2)

    # 获取初始错误计数
    initial_stats = await daemon.get_stats()
    initial_errors = initial_stats['errors']

    # 模拟错误（添加无效数据）
    try:
        await daemon.add_intentionality_data({"invalid": "data"})
    except Exception:
        pass

    # 等待一段时间
    await asyncio.sleep(0.2)

    # 获取最终错误计数
    final_stats = await daemon.get_stats()
    final_errors = final_stats['errors']

    # 守护协程应该仍在运行
    assert daemon.running is True

    await daemon.stop()


if __name__ == "__main__":
    # 直接运行测试
    print("运行意向性守护协程测试...\n")

    import sys

    # 运行pytest
    sys.exit(pytest.main([__file__, "-v", "-s"]))
