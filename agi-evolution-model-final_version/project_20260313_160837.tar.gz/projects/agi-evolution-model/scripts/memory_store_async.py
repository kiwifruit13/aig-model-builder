#!/usr/bin/env python3
"""
记忆存储异步实现

基于asyncio和aiofiles的异步I/O实现，提供非阻塞的记录存储、检索和分析功能。
性能优化：批量操作、并行读取、超时保护。
"""

import asyncio
import json
import os
import time
from typing import Dict, Optional, List
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path

# 异步文件I/O依赖
try:
    import aiofiles
    AIOFILES_AVAILABLE = True
except ImportError:
    AIOFILES_AVAILABLE = False
    print("警告: aiofiles未安装，将使用同步I/O（性能较差）")


@dataclass
class Record:
    """交互记录"""
    timestamp: str
    user_query: str
    intent_type: str
    reasoning_quality: float = 8.0
    solution_effectiveness: float = 8.0
    innovation_score: float = 7.0
    new_insights: List[str] = None
    feedback: Dict[str, str] = None
    overall_rating: str = "good"
    response: str = ""
    objectivity_metric: Dict = None
    self_correction: Dict = None

    def __post_init__(self):
        if self.new_insights is None:
            self.new_insights = []
        if self.feedback is None:
            self.feedback = {
                "drive": "",
                "math": "",
                "iteration": ""
            }
        if self.objectivity_metric is None:
            self.objectivity_metric = {}
        if self.self_correction is None:
            self.self_correction = {}

    def to_dict(self) -> dict:
        return asdict(self)

    def get_value_weight(self) -> float:
        """计算价值权重"""
        return (
            self.reasoning_quality * 0.4 +
            self.solution_effectiveness * 0.3 +
            self.innovation_score * 0.3
        ) / 10.0


@dataclass
class AnalysisResult:
    """分析结果"""
    total_records: int
    rating_distribution: Dict[str, int]
    intent_type_distribution: Dict[str, int]
    average_scores: Dict[str, float]
    recent_insights: List[str]

    def to_dict(self) -> dict:
        return asdict(self)


class AsyncMemoryStore:
    """记忆存储管理器（异步实现）"""

    def __init__(self, memory_dir: str = "./agi_memory", batch_size: int = 100):
        """
        初始化记忆存储

        Args:
            memory_dir: 记忆存储目录
            batch_size: 批量写入大小
        """
        self.memory_dir = Path(memory_dir)
        self.records_file = self.memory_dir / "records.json"
        self.narrative_file = self.memory_dir / "narrative.md"
        
        self._records: List[Record] = []
        self._batch: List[Record] = []  # 待批量写入的记录
        self.batch_size = batch_size
        self.lock = asyncio.Lock()  # 保护共享数据
        
        # 性能统计
        self.stats = {
            'total_stores': 0,
            'total_retrieves': 0,
            'total_analyzes': 0,
            'batch_writes': 0
        }

    async def initialize(self):
        """异步初始化"""
        await self._load_records()

    async def _load_records(self):
        """异步加载记录"""
        if not self.records_file.exists():
            self._records = []
            return

        try:
            if AIOFILES_AVAILABLE:
                # 使用aiofiles异步读取
                async with aiofiles.open(self.records_file, 'r', encoding='utf-8') as f:
                    content = await f.read()
            else:
                # 降级到同步读取
                with open(self.records_file, 'r', encoding='utf-8') as f:
                    content = f.read()

            data = json.loads(content)
            self._records = [Record(**item) for item in data]
        except Exception as e:
            print(f"加载记录失败: {e}")
            self._records = []

    async def _save_records(self):
        """异步保存记录"""
        try:
            self.memory_dir.mkdir(parents=True, exist_ok=True)

            # 序列化数据
            data = [r.to_dict() for r in self._records]

            if AIOFILES_AVAILABLE:
                # 使用aiofiles异步写入
                async with aiofiles.open(self.records_file, 'w', encoding='utf-8') as f:
                    await f.write(json.dumps(data, ensure_ascii=False, indent=2))
            else:
                # 降级到同步写入
                with open(self.records_file, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)

            self.stats['batch_writes'] += 1
        except Exception as e:
            print(f"保存记录失败: {e}")

    async def store(self, data: dict, flush: bool = False) -> bool:
        """
        异步存储记录

        Args:
            data: 记录数据
            flush: 是否立即刷新到磁盘

        Returns:
            bool: 是否成功
        """
        try:
            async with self.lock:
                record = Record(
                    timestamp=data.get("timestamp", time.strftime("%Y-%m-%dT%H:%M:%SZ")),
                    user_query=data.get("user_query", ""),
                    intent_type=data.get("intent_type", ""),
                    reasoning_quality=data.get("reasoning_quality", 8.0),
                    solution_effectiveness=data.get("solution_effectiveness", 8.0),
                    innovation_score=data.get("innovation_score", 7.0),
                    new_insights=data.get("new_insights", []),
                    feedback=data.get("feedback", {}),
                    overall_rating=data.get("overall_rating", "good"),
                    response=data.get("response", ""),
                    objectivity_metric=data.get("objectivity_metric", {}),
                    self_correction=data.get("self_correction", {})
                )

                self._records.append(record)
                self._batch.append(record)
                self.stats['total_stores'] += 1

                # 批量写入或立即刷新
                if flush or len(self._batch) >= self.batch_size:
                    await self._save_records()
                    self._batch.clear()

            return True
        except Exception as e:
            print(f"存储记录失败: {e}")
            return False

    async def flush(self):
        """立即刷新批量缓冲区"""
        async with self.lock:
            if self._batch:
                await self._save_records()
                self._batch.clear()

    async def retrieve(self, query_type: str, limit: int = 5, timeout: float = 0.1) -> List[Dict]:
        """
        异步检索记录

        Args:
            query_type: 查询类型
            limit: 返回数量限制
            timeout: 超时时间（秒）

        Returns:
            List[Dict]: 匹配的记录
        """
        try:
            # 设置超时保护
            return await asyncio.wait_for(
                self._retrieve_impl(query_type, limit),
                timeout=timeout
            )
        except asyncio.TimeoutError:
            print(f"检索超时: query_type={query_type}")
            return []
        except Exception as e:
            print(f"检索失败: {e}")
            return []

    async def _retrieve_impl(self, query_type: str, limit: int) -> List[Dict]:
        """检索实现"""
        async with self.lock:
            matched = []

            for record in reversed(self._records):
                if query_type.lower() in record.intent_type.lower():
                    matched.append(record.to_dict())
                    if len(matched) >= limit:
                        break

            self.stats['total_retrieves'] += 1
            return matched

    async def analyze(self, timeout: float = 0.5) -> AnalysisResult:
        """
        异步分析记录

        Args:
            timeout: 超时时间（秒）

        Returns:
            AnalysisResult: 分析结果
        """
        try:
            return await asyncio.wait_for(
                self._analyze_impl(),
                timeout=timeout
            )
        except asyncio.TimeoutError:
            print("分析超时")
            return AnalysisResult(
                total_records=0,
                rating_distribution={},
                intent_type_distribution={},
                average_scores={},
                recent_insights=[]
            )
        except Exception as e:
            print(f"分析失败: {e}")
            return AnalysisResult(
                total_records=0,
                rating_distribution={},
                intent_type_distribution={},
                average_scores={},
                recent_insights=[]
            )

    async def _analyze_impl(self) -> AnalysisResult:
        """分析实现"""
        async with self.lock:
            if not self._records:
                return AnalysisResult(
                    total_records=0,
                    rating_distribution={},
                    intent_type_distribution={},
                    average_scores={},
                    recent_insights=[]
                )

            total = len(self._records)

            # 评分分布
            rating_dist = {}
            for record in self._records:
                rating = record.overall_rating
                rating_dist[rating] = rating_dist.get(rating, 0) + 1

            # 意图类型分布
            intent_dist = {}
            for record in self._records:
                intent = record.intent_type
                intent_dist[intent] = intent_dist.get(intent, 0) + 1

            # 平均分
            avg_reasoning = sum(r.reasoning_quality for r in self._records) / total
            avg_effectiveness = sum(r.solution_effectiveness for r in self._records) / total
            avg_innovation = sum(r.innovation_score for r in self._records) / total

            # 最近洞察
            recent_insights = []
            for record in reversed(self._records[-10:]):
                recent_insights.extend(record.new_insights)

            self.stats['total_analyzes'] += 1

            return AnalysisResult(
                total_records=total,
                rating_distribution=rating_dist,
                intent_type_distribution=intent_dist,
                average_scores={
                    'reasoning_quality': avg_reasoning,
                    'solution_effectiveness': avg_effectiveness,
                    'innovation_score': avg_innovation
                },
                recent_insights=recent_insights
            )

    async def get_stats(self) -> Dict:
        """获取统计信息"""
        return self.stats.copy()

    async def close(self):
        """关闭存储，刷新缓冲区"""
        await self.flush()


# 兼容性接口：提供同步调用方式
class SyncMemoryStoreWrapper:
    """同步包装器，用于兼容旧代码"""

    def __init__(self, memory_dir: str = "./agi_memory"):
        self._async_store = AsyncMemoryStore(memory_dir)
        self._loop = None

    def _ensure_loop(self):
        """确保事件循环存在"""
        if self._loop is None or self._loop.is_closed():
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
        return self._loop

    def initialize(self):
        """同步初始化"""
        loop = self._ensure_loop()
        loop.run_until_complete(self._async_store.initialize())

    def store(self, data: dict, flush: bool = False) -> bool:
        """同步存储"""
        loop = self._ensure_loop()
        return loop.run_until_complete(self._async_store.store(data, flush))

    def retrieve(self, query_type: str, limit: int = 5) -> List[Dict]:
        """同步检索"""
        loop = self._ensure_loop()
        return loop.run_until_complete(self._async_store.retrieve(query_type, limit))

    def analyze(self) -> AnalysisResult:
        """同步分析"""
        loop = self._ensure_loop()
        return loop.run_until_complete(self._async_store.analyze())

    def flush(self):
        """同步刷新"""
        loop = self._ensure_loop()
        loop.run_until_complete(self._async_store.flush())

    def close(self):
        """同步关闭"""
        loop = self._ensure_loop()
        loop.run_until_complete(self._async_store.close())


# 便捷函数：根据环境选择实现
def create_memory_store(memory_dir: str = "./agi_memory", use_async: bool = True):
    """
    创建记忆存储实例

    Args:
        memory_dir: 记忆存储目录
        use_async: 是否使用异步实现

    Returns:
        记忆存储实例
    """
    if use_async and AIOFILES_AVAILABLE:
        return AsyncMemoryStore(memory_dir)
    else:
        return SyncMemoryStoreWrapper(memory_dir)


if __name__ == "__main__":
    # 简单测试
    import argparse

    parser = argparse.ArgumentParser(description="异步记忆存储测试")
    parser.add_argument("--memory-dir", default="./agi_memory", help="记忆存储目录")
    parser.add_argument("--test-sync", action="store_true", help="测试同步接口")
    args = parser.parse_args()

    if args.test_sync:
        # 测试同步接口
        print("测试同步接口...")
        store = SyncMemoryStoreWrapper(args.memory_dir)
        store.initialize()

        # 存储测试
        store.store({
            "user_query": "测试查询",
            "intent_type": "test",
            "reasoning_quality": 9.0
        })

        # 检索测试
        results = store.retrieve("test")
        print(f"检索结果: {len(results)} 条")

        # 分析测试
        analysis = store.analyze()
        print(f"分析结果: {analysis.total_records} 条记录")

        store.close()
    else:
        # 测试异步接口
        print("测试异步接口...")
        async def test_async():
            store = AsyncMemoryStore(args.memory_dir)
            await store.initialize()

            # 存储测试
            await store.store({
                "user_query": "测试查询",
                "intent_type": "test",
                "reasoning_quality": 9.0
            })

            # 检索测试
            results = await store.retrieve("test")
            print(f"检索结果: {len(results)} 条")

            # 分析测试
            analysis = await store.analyze()
            print(f"分析结果: {analysis.total_records} 条记录")

            # 统计信息
            stats = await store.get_stats()
            print(f"统计信息: {stats}")

            await store.close()

        asyncio.run(test_async())
