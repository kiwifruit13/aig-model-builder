#!/usr/bin/env python3
"""
异步记忆存储测试用例

使用pytest-asyncio框架进行异步单元测试和集成测试。
"""

import asyncio
import pytest
import tempfile
import shutil
import json
from pathlib import Path

# 添加scripts目录到路径
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from memory_store_async import AsyncMemoryStore, SyncMemoryStoreWrapper, create_memory_store


@pytest.fixture
def temp_memory_dir():
    """临时测试目录"""
    temp_dir = tempfile.mkdtemp(prefix="test_memory_")
    yield temp_dir
    shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.mark.asyncio
async def test_async_initialize(temp_memory_dir):
    """测试异步初始化"""
    store = AsyncMemoryStore(temp_memory_dir)
    await store.initialize()

    assert len(store._records) == 0
    assert Path(temp_memory_dir).exists()


@pytest.mark.asyncio
async def test_async_store_single(temp_memory_dir):
    """测试异步存储单条记录"""
    store = AsyncMemoryStore(temp_memory_dir)
    await store.initialize()

    data = {
        "user_query": "测试查询",
        "intent_type": "test",
        "reasoning_quality": 9.0,
        "solution_effectiveness": 8.5,
        "innovation_score": 8.0
    }

    result = await store.store(data, flush=True)
    assert result is True
    assert len(store._records) == 1

    await store.close()


@pytest.mark.asyncio
async def test_async_store_batch(temp_memory_dir):
    """测试异步批量存储"""
    store = AsyncMemoryStore(temp_memory_dir, batch_size=10)
    await store.initialize()

    # 存储9条记录（不触发批量写入）
    for i in range(9):
        await store.store({
            "user_query": f"查询 #{i}",
            "intent_type": "test"
        })

    assert len(store._batch) == 9
    assert len(store._records) == 9

    # 存储第10条记录（触发批量写入）
    await store.store({
        "user_query": "查询 #10",
        "intent_type": "test"
    })

    assert len(store._batch) == 0
    assert len(store._records) == 10

    await store.close()


@pytest.mark.asyncio
async def test_async_store_persistence(temp_memory_dir):
    """测试数据持久化"""
    store = AsyncMemoryStore(temp_memory_dir)
    await store.initialize()

    # 存储数据
    await store.store({
        "user_query": "持久化测试",
        "intent_type": "persistence_test"
    }, flush=True)

    await store.close()

    # 重新加载
    store2 = AsyncMemoryStore(temp_memory_dir)
    await store2.initialize()

    assert len(store2._records) == 1
    assert store2._records[0].user_query == "持久化测试"

    await store2.close()


@pytest.mark.asyncio
async def test_async_retrieve(temp_memory_dir):
    """测试异步检索"""
    store = AsyncMemoryStore(temp_memory_dir)
    await store.initialize()

    # 存储测试数据
    await store.store({"user_query": "数学查询", "intent_type": "math"}, flush=True)
    await store.store({"user_query": "驱动查询", "intent_type": "drive"}, flush=True)
    await store.store({"user_query": "另一个数学查询", "intent_type": "math"}, flush=True)

    # 检索数学类型的记录
    results = await store.retrieve("math", limit=5)

    assert len(results) == 2
    assert results[0]["intent_type"] == "math"

    await store.close()


@pytest.mark.asyncio
async def test_async_retrieve_timeout(temp_memory_dir):
    """测试检索超时保护"""
    store = AsyncMemoryStore(temp_memory_dir)
    await store.initialize()

    # 设置很短的超时时间
    results = await store.retrieve("test", timeout=0.001)

    # 应该返回空列表而不是抛出异常
    assert results == []

    await store.close()


@pytest.mark.asyncio
async def test_async_analyze(temp_memory_dir):
    """测试异步分析"""
    store = AsyncMemoryStore(temp_memory_dir)
    await store.initialize()

    # 存储测试数据
    for i in range(10):
        await store.store({
            "user_query": f"查询 #{i}",
            "intent_type": "test" if i % 2 == 0 else "math",
            "reasoning_quality": 7.0 + (i % 4),
            "solution_effectiveness": 8.0,
            "innovation_score": 7.5,
            "overall_rating": "good" if i % 3 == 0 else "excellent"
        }, flush=True)

    # 分析记录
    analysis = await store.analyze()

    assert analysis.total_records == 10
    assert "test" in analysis.intent_type_distribution
    assert "math" in analysis.intent_type_distribution
    assert analysis.average_scores['reasoning_quality'] > 0

    await store.close()


@pytest.mark.asyncio
async def test_async_concurrent_stores(temp_memory_dir):
    """测试并发存储"""
    store = AsyncMemoryStore(temp_memory_dir)
    await store.initialize()

    # 并发存储100条记录
    tasks = [
        store.store({
            "user_query": f"并发查询 #{i}",
            "intent_type": "test"
        }) for i in range(100)
    ]

    results = await asyncio.gather(*tasks, return_exceptions=True)

    # 检查所有操作都成功
    assert all(r is True for r in results)
    assert len(store._records) == 100

    await store.flush()
    await store.close()


@pytest.mark.asyncio
async def test_async_concurrent_retrieves(temp_memory_dir):
    """测试并发检索"""
    store = AsyncMemoryStore(temp_memory_dir)
    await store.initialize()

    # 准备测试数据
    for i in range(50):
        await store.store({
            "user_query": f"查询 #{i}",
            "intent_type": "test" if i % 2 == 0 else "math"
        }, flush=True)

    # 并发检索
    tasks = [store.retrieve("test", limit=100) for _ in range(20)]  # 增加limit以获取所有匹配项

    results = await asyncio.gather(*tasks, return_exceptions=True)

    # 检查所有检索都成功
    assert all(isinstance(r, list) for r in results)
    # 应该返回所有匹配的记录（25条）
    assert all(len(r) == 25 for r in results)  # 25条记录是test类型（50条记录的50%）

    await store.close()


def test_sync_wrapper(temp_memory_dir):
    """测试同步包装器"""
    store = SyncMemoryStoreWrapper(temp_memory_dir)
    store.initialize()

    # 同步存储
    result = store.store({
        "user_query": "同步测试",
        "intent_type": "sync_test"
    })
    assert result is True

    # 同步检索
    results = store.retrieve("sync_test")
    assert len(results) == 1

    # 同步分析
    analysis = store.analyze()
    assert analysis.total_records == 1

    store.close()


@pytest.mark.asyncio
async def test_async_get_stats(temp_memory_dir):
    """测试统计信息"""
    store = AsyncMemoryStore(temp_memory_dir)
    await store.initialize()

    # 存储一些数据
    for i in range(10):
        await store.store({
            "user_query": f"查询 #{i}",
            "intent_type": "test"
        })

    await store.flush()

    # 获取统计信息
    stats = await store.get_stats()

    assert stats['total_stores'] == 10
    assert stats['batch_writes'] > 0

    # 检索和分析
    await store.retrieve("test")
    await store.analyze()

    stats = await store.get_stats()
    assert stats['total_retrieves'] == 1
    assert stats['total_analyzes'] == 1

    await store.close()


@pytest.mark.asyncio
async def test_async_error_handling(temp_memory_dir):
    """测试错误处理"""
    store = AsyncMemoryStore(temp_memory_dir)
    await store.initialize()

    # 存储无效数据（应该被捕获）
    result = await store.store({
        # 缺少必需字段
        "user_query": "无效数据"
    })
    # 应该成功（有默认值）
    assert result is True

    await store.close()


@pytest.mark.asyncio
async def test_async_large_dataset(temp_memory_dir):
    """测试大数据集"""
    store = AsyncMemoryStore(temp_memory_dir)
    await store.initialize()

    # 存储1000条记录
    for i in range(1000):
        await store.store({
            "user_query": f"大数据集查询 #{i}",
            "intent_type": "test" if i % 3 == 0 else "math" if i % 3 == 1 else "drive"
        })

    await store.flush()

    assert len(store._records) == 1000

    # 测试检索性能
    results = await store.retrieve("test", limit=500)  # 修改limit以获取所有匹配项
    assert len(results) == 334  # 1000 / 3

    # 测试分析性能
    analysis = await store.analyze()
    assert analysis.total_records == 1000

    await store.close()


if __name__ == "__main__":
    # 直接运行测试
    print("运行异步记忆存储测试...\n")

    import sys

    # 运行pytest
    sys.exit(pytest.main([__file__, "-v", "-s"]))
